
import 'package:flutter/material.dart';

class BottomAppBarWidget extends StatelessWidget {

    final List<BottomNavigationBarItem> items;
    final ValueChanged<int> onTap;
    final int currentIndex;// = 0;
    final double elevation;// = 8.0;
    final BottomNavigationBarType type;
    final Color fixedColor;
    final Color backgroundColor;
    final double iconSize;// = 24.0;
    final Color selectedItemColor;
    final Color unselectedItemColor;
    final IconThemeData selectedIconTheme;// = const IconThemeData();
    final IconThemeData unselectedIconTheme; //= const IconThemeData();
    final double selectedFontSize;// = 14.0;
    final double unselectedFontSize;// = 12.0;
    final TextStyle selectedLabelStyle;
    final TextStyle unselectedLabelStyle;
    final bool showSelectedLabels;// = true;
    final bool showUnselectedLabels;

  BottomAppBarWidget({
    Key key,
    @required this.items,
    this.onTap,
    this.currentIndex = 0,
    this.elevation = 8.0,
    this.type,
    this.fixedColor,
    this.backgroundColor,
    this.iconSize = 24.0,
    this. selectedItemColor,
    this.unselectedItemColor,
    this.selectedIconTheme = const IconThemeData(),
    this.unselectedIconTheme = const IconThemeData(),
    this.selectedFontSize = 14.0,
    this.unselectedFontSize = 12.0,
    this.selectedLabelStyle,
    this.unselectedLabelStyle,
    this.showSelectedLabels = true,
    this. showUnselectedLabels,
  }): super( key: key,);

  @override
  Widget build(BuildContext context) {
    final data = Theme.of(context).copyWith(
      // sets the background color of the `BottomNavigationBar`
      canvasColor: Theme.of(context).canvasColor,// Colors.green,
      // sets the active color of the `BottomNavigationBar` if `Brightness` is light
      primaryColor: Theme.of(context).primaryColor, //Colors.red,
      textTheme: Theme.of(context).textTheme
    );
    return Theme(
      data: data,
      child: BottomNavigationBar(
        key: Key("BottomNavigationBar"),
        items: items,
        onTap: onTap,
        currentIndex: currentIndex,
        elevation: elevation,
        type: type,
        fixedColor: fixedColor,
        backgroundColor: backgroundColor,
        iconSize: iconSize,
        selectedItemColor: selectedItemColor,
        unselectedItemColor: unselectedItemColor,
        selectedIconTheme: selectedIconTheme,
        unselectedIconTheme: unselectedIconTheme,
        selectedFontSize: selectedFontSize,
        unselectedFontSize: unselectedFontSize,
        selectedLabelStyle: selectedLabelStyle,
        unselectedLabelStyle: unselectedLabelStyle,
        showSelectedLabels: showSelectedLabels,
        showUnselectedLabels: showUnselectedLabels
      ),
    );
  }
}

// class BottomAppBarWidget extends StatelessWidget {

//   final Color selectedColor;
//   final Color buttonColor;
//   final Color color;
//   final double _height = 55.0;
//   final double _iconSize = 24.0;

//   final List<FABBottomAppBar> items;
//   final ValueChanged<int> onSelect;
//   final int selectedIndex;

//   const BottomAppBarWidget({
//     Key key,
//     this.items,
//     this.onSelect,
//     this.selectedIndex,
//     this.buttonColor = Colors.grey,
//     this.selectedColor = secondaryColor,
//     this.color = Colors.white,
//   }) : super(key: key);


//   List<Widget> _buildMenuItems(){
//     final buttons = List.generate(items.length, (index){
//       return _buildTabItem(items[index],index,onSelect);
//     });
//     return buttons;
//   }

//   Widget _buildTabItem(
//     FABBottomAppBar fabBottomAppBar,
//     int index,
//     ValueChanged<int> onPressed,
//   ) {

//     if(fabBottomAppBar is FABBottomAppBarItemEmpty){
//       return SizedBox(
//         height: _height,
//         width: _height,
//       );
//     }
//     final Color color = selectedIndex == index ? selectedColor : buttonColor;
//     final item = fabBottomAppBar as FABBottomAppBarItem;

//     final button = <Widget>[
//       SizedBox.fromSize(
//         size: Size(_iconSize, _iconSize),
//         child: Theme(
//           child: item.icon,
//         ),
//       ),
//       item.title,
//     ];

//     return Expanded(
//       child: SizedBox(
//         height: _height,
//         child: Material(
//           type: MaterialType.transparency,
//           child: InkWell(
//             onTap: () => onPressed(index),
//             child:  Column(
//               mainAxisSize: MainAxisSize.min,
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: button
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return BottomAppBar(
//       shape: CircularNotchedRectangle(),
//       color: color,
//       child: Row(
//         mainAxisSize: MainAxisSize.max,
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: _buildMenuItems(),
//       ),
//     );
//   }
// }

// class FABBottomAppBar{}

// class FABBottomAppBarItem extends FABBottomAppBar{
//   final Widget title;
//   final Widget icon;

//   FABBottomAppBarItem(this.title, this.icon);
// }

// class FABBottomAppBarItemEmpty extends FABBottomAppBar{
//   FABBottomAppBarItemEmpty();
// }
