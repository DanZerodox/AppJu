import 'package:animate_do/animate_do.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ButtonNotificationWidget extends StatelessWidget {
  final IconData icon;

  const ButtonNotificationWidget({Key key,
   @required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Stack(
      children: <Widget>[
        Center(
          child: Icon(icon),
        ),
        Positioned(
          top: 0,
          right: 25,
          child: Center(
            child: Consumer<NotificacionModel>(
              builder: (context, value, child){
                return _AnimatedItemWidget(
                  animate: value != null,
                  child: Icon(Icons.brightness_1,size: 8.0, color: Colors.red),
                );
              },
            )
          )
        )
      ],
    );
  }
}

class _AnimatedItemWidget extends StatefulWidget {
  final bool animate;
  final Widget child;
  _AnimatedItemWidget({Key key, this.animate = true, @required this.child}) : super(key: key);

  @override
  _AnimatedItemWidgetState createState() => _AnimatedItemWidgetState();
}

class _AnimatedItemWidgetState extends State<_AnimatedItemWidget> {
  AnimationController _animationControllerBouce;
  AnimationController _animationControllerBouceIn;

  @override
  void didUpdateWidget(_AnimatedItemWidget oldWidget) {
    _animationControllerBouce?.reset();

    if(widget.animate)
      _animationControllerBouce?.forward();

    else
      _animationControllerBouceIn.reset();
    
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return BounceInDown(
      from: 10.0,
      animate: widget.animate,
      controller: (c) => _animationControllerBouceIn = c,
      child: Bounce(
        from: 10.0,
        animate: widget.animate,
        controller: (c)=>_animationControllerBouce = c,
        child: widget.child,
      ),
    );
  }
}