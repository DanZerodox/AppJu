import 'package:flutter/material.dart';

class SubmitButtonWidget extends StatelessWidget {
  final VoidCallback _onSubmit;
  final String _title;
  final double _radio = 30;

  const SubmitButtonWidget({Key key,
    VoidCallback onSubmit,
    @required String title
   }):
   assert(title != null),
   _onSubmit = onSubmit,
   _title = title,
    super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50.0,
      child: RaisedButton(
        shape: new RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(_radio),
        ),
        padding: EdgeInsets.all(0.0),
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(_radio),
          ),
          child: Container(
            constraints: BoxConstraints(
              maxWidth: 200.0, minHeight: 50.0
            ),
            alignment: Alignment.center,
            child: Text(_title, textScaleFactor: 1.3),
          ),
        ),
        onPressed:_onSubmit,
      ),
    );
  }
}