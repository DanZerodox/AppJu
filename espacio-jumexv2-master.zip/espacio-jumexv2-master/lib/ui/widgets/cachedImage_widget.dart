import 'package:cached_network_image/cached_network_image.dart';
import 'package:espacio_jumex/core/infrastructure/customCacheManager.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CachedImageWidget extends StatelessWidget {
  final String _url;
  final BoxFit _fit;
  final ImageWidgetBuilder _imageBuilder;
  final LoadingErrorWidgetBuilder _errorWidget;
  final PlaceholderWidgetBuilder _placeholder;
  final Map<String, String> _headers;

  const CachedImageWidget({Key key,
    String url, 
    BoxFit fit = BoxFit.contain, 
    ImageWidgetBuilder imageBuider,
    LoadingErrorWidgetBuilder errorWidget,
    PlaceholderWidgetBuilder placeholder,
    Map<String, String> headers
  }):
    _url = url,_fit= fit,
    _imageBuilder = imageBuider,
    _errorWidget =  errorWidget,
    _placeholder = placeholder,
    _headers = headers,
    assert( url != null  ),
    super(key: key);

  @override
  Widget build(BuildContext context) {
    final cacheManager = Provider.of<CustomCacheManager>(context, listen: false);

    return CachedNetworkImage(
      imageUrl: _url,
      fit: _fit,
      cacheManager: cacheManager,
      placeholder: _placeholder ??(_,__)=>UiHelper.progressIndicator,
      errorWidget:  _errorWidget,
      imageBuilder: _imageBuilder,
      httpHeaders: _headers,
    );
  }
}