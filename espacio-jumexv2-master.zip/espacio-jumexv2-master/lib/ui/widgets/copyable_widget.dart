import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


class CopyableWidget extends StatelessWidget {
  final _text;
  final Widget _child;
  final VoidCallback _onCopy;
  const CopyableWidget({Key key,String text, VoidCallback onCopy, Widget child}) :
    assert (text != null),
    _text = text, _onCopy = onCopy, _child = child,
    super(key: key);

  @override
  Widget build(BuildContext context) {
    return new GestureDetector(
      child: _child,
      onTap: () {
        Clipboard.setData(new ClipboardData(text: _text));
        _onCopy?.call();
      },
    );
  }
}