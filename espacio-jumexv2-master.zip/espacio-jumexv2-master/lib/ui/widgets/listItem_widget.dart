import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';

class ListItemWidget extends StatelessWidget {
  final Widget child;
  final VoidCallback onTap;
  final EdgeInsetsGeometry margin;
  final BorderRadius borderRadius;
  final bool hasShadow;
  final BoxConstraints constraints;

  final BoxDecoration boxDecoration;
  final Color backgroundColor;

  static final _defaultRadius = BorderRadius.circular(8.0);
  static final _defaultConstraints = UiHelper.listItemConstraintsLarge.copyWith(minHeight: 50.0); 

  ListItemWidget({Key key, this.child, this.onTap,
    this.hasShadow = false,
    EdgeInsetsGeometry margin,
    BorderRadius borderRadius,
    BoxConstraints constraints, 
    BoxDecoration boxDecoration,
    Color backgroundColor,
  }) :
    this.margin = margin ?? UiHelper.listItemMarginLarge,
    this.borderRadius = borderRadius ?? _defaultRadius,
    this.constraints = _defaultConstraints,
    this.boxDecoration = boxDecoration ?? _defaultDecoration,
    this.backgroundColor = backgroundColor ?? Colors.white,
    super(key: key);

  final shadowDecoration = BoxDecoration(
    shape: BoxShape.rectangle,
    boxShadow: <BoxShadow>[
      BoxShadow(  
        color: Colors.black12,
        blurRadius: 10.0,
        offset: Offset(0.0, 5.0),
      ),
    ],
  );

  static final _defaultDecoration = BoxDecoration(
    color: Colors.white,
    border: Border(
      bottom: BorderSide(
        color: UiHelper.colorHorizontalDivider,
      )
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: constraints ,
      padding: EdgeInsets.all(0.0),
      margin: margin,
      decoration: hasShadow ? shadowDecoration : boxDecoration,
      child: Material(
        borderRadius: borderRadius,
        color: backgroundColor,
        child: InkWell(
          borderRadius: borderRadius,
          onTap: onTap,
          child: child,
        ),
      )
    );
  }
}