
import 'package:espacio_jumex/ui/shared/theme.dart';
import 'package:flutter/widgets.dart';

class LoadingWidget extends StatelessWidget {
  final Size size;
  const LoadingWidget({Key key, this.size}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      width: size.width,
      height: size.height,
      decoration: new BoxDecoration(
        gradient: new LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            primaryColor,
            secondaryColor ,
          ],
        ),
      ),
      child: Image.asset("assets/images/espaciojumex.png"),
    );
  }
}