import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';

class MenuGridWidget extends StatelessWidget{
  final int _crossAxisCountLandscape;
  final List<MenuGridItem> items;
  final void Function(int index) _onTap;
  final void Function(int index, bool visible) _onTapVisible;

  final bool editing;

  const MenuGridWidget({Key key,
    int crossAxisCountLandscape = 2,
    this.items,
    Function(int index) onTap,
    Function(int index, bool visible) onChangeVisible,
    this.editing = false,
  }) :assert(items != null),
  _crossAxisCountLandscape = crossAxisCountLandscape,
  _onTap =  onTap,
  _onTapVisible =  onChangeVisible;

  Widget _buildPortraitMenu(BuildContext context){
    return GridView.builder(
      itemCount: items.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _crossAxisCountLandscape,
        childAspectRatio: 4/3
      ),
      padding: UiHelper.listItemPadding,
      itemBuilder: (context,index){

        return _GridItemMenu(
          onTap: ()=>_onTap?.call(index),
          onTapVisible: (visible)=>_onTapVisible?.call(index, visible),
          visible: items[index].visible,
          child: items[index].widget,
          color: items[index].backgroundColor,
          editing: editing,
        );
      }
    );
  }

  Widget _buildLandscapeMenu(BuildContext context){
    return GridView.builder(
      itemCount: items.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _crossAxisCountLandscape + 1,
        childAspectRatio: 16/10
      ),
      padding: UiHelper.listItemPadding,
      itemBuilder: (context,index){
         return _GridItemMenu(
          onTap: ()=>_onTap?.call(index),
          onTapVisible: (visible)=>_onTapVisible?.call(index, visible),
          visible: items[index].visible,
          child: items[index].widget,
          color: items[index].backgroundColor,
          editing: editing,
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (ctx,constraints){
        if(constraints.maxWidth >= BreakpointLayout.breakPointWidth500){
          return _buildLandscapeMenu(context);
        }else{
          return _buildPortraitMenu(context);
        }
      }
    );
  }
}

class _GridItemMenu extends StatelessWidget{
  final VoidCallback onTap;
  final void Function(bool visible) onTapVisible;
  final bool editing;
  final bool visible;
  final Color color;
  final Widget child;

  _GridItemMenu({
    Key key,
    this.editing,
    this.visible,
    this.color,
    this.child,
    this.onTap,
    this.onTapVisible,
  }): super(key: key);

  final borderRadius = BorderRadius.circular(8.0);

  @override
  Widget build(BuildContext context) {
    
    return Container(
      height: 120.0,
      margin: const EdgeInsets.only(
        bottom: 10.0, left: 5.0, right: 5.0
      ),
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
        boxShadow: <BoxShadow>[
          BoxShadow(  
            color: Colors.black12,
            blurRadius: 10.0,
            offset: Offset(0.0, 5.0),
          ),
        ],
      ),
      child: Material(
        borderRadius: borderRadius,
        color: color,
        child: InkWell(
          borderRadius: borderRadius,
          onTap: !editing ? onTap : null,
          child: Stack(
            children: <Widget>[
              this.child,
              Positioned(child: _GridItemEditButton(visibilityIndicator: visible, editing: editing, onTapVisible: onTapVisible),right: 0,)
            ],
          ),
        )
      )
    );
  }
}

class _GridItemEditButton extends StatefulWidget{
  final void Function(bool visible) onTapVisible;
  final bool visibilityIndicator;
  final bool editing;

  const _GridItemEditButton({Key key, this.visibilityIndicator, this.editing, this.onTapVisible}): super(key: key);

  @override
  _GridItemEditButtonState createState() => _GridItemEditButtonState();
}

class _GridItemEditButtonState extends State<_GridItemEditButton> {
  bool visibilityIndicator = false;

  @override
  void initState() {
    visibilityIndicator = widget.visibilityIndicator;
    super.initState();
  }

  @override
  void didUpdateWidget(_GridItemEditButton oldWidget) {
    visibilityIndicator = widget.visibilityIndicator;
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: widget.editing ? 1.0 : 0.0,
      duration: Duration(milliseconds: 800),
      curve: Curves.easeOut,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.transparent
          ),
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(20),
            topRight: Radius.circular(5)
          ),
          color: Colors.white54,
          boxShadow: <BoxShadow>[
            BoxShadow(  
              color: Colors.black12,
              blurRadius: 10.0,
              offset: Offset(0.0, 10.0),
            ),
          ],
        ),
        width: 50,
        height: 50,
        alignment: FractionalOffset.topRight,
        child: IconButton(
          icon: visibilityIndicator ? Icon(Icons.visibility, color: Colors.green[800],) : Icon(Icons.visibility_off, color: Colors.green[800]), 
          onPressed: !widget.editing ? null : (){
            setState(() {
              visibilityIndicator = !visibilityIndicator;
            });
            widget.onTapVisible(visibilityIndicator);
          }
        ),
      ),
    );
  } 
}

class MenuItemWidget extends StatelessWidget{
  final Widget title;
  final Widget icon;

  const MenuItemWidget({
    Key key,
    this.title,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    final _thumbnail = Container(
      margin: const EdgeInsets.only(
        top: 16.0, left: 16.0
      ),
      alignment: FractionalOffset.topLeft,
      child: SizedBox.fromSize(
        size: Size.square(54.0),
        child: icon,
      )
    );

    return Container(
      child: Stack(
        children: <Widget>[
          _thumbnail,
          Container(
            alignment: FractionalOffset.centerLeft,
            margin: new EdgeInsets.fromLTRB(16.0, 70.0, 0.0, 16.0),
            constraints: BoxConstraints.expand(),
            child: title,
          )
        ],
      )
    );
  }
}


class MenuItemWidgetFit extends StatelessWidget{
  final Widget icon;

  const MenuItemWidgetFit({
    Key key,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Container(
      margin: const EdgeInsets.all( 1.5 ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: SizedBox.expand(
          child: icon,
        ),
      )
    );
  }
}

class MenuGridItem{
  final Color backgroundColor;
  final bool visible;
  final Widget widget;

  const MenuGridItem({
    this.backgroundColor,
    this.visible = true,
    this.widget
  });
}