import 'package:espacio_jumex/core/models/photoItem_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/slideRightRoute.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/photoGalery_view.dart';
import 'package:espacio_jumex/ui/widgets/cachedImage_widget.dart';
import 'package:flutter/material.dart';

class ThumbnailWidget extends StatelessWidget {
  final List<PhotoItemModel> items;
  final double width;
  final double maxHeight;

  const ThumbnailWidget({Key key, @required this.items, this.width = 280.0, this.maxHeight = 200}) : super(key: key);

  Widget _buildMedia(BuildContext context, List<PhotoItemModel> list) {
    var item;
    switch (list.length) {
      case 1:
        item = _buildImage(context, list[0], 0);
        break;
      case 2:
        item = Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Expanded(
              child: _buildImage(context, list[0], 0),
            ),
            UiHelper.horizontalSpaceXSmall,
            Expanded(
              child: _buildImage(context, list[1], 1),
            )
          ],
        );
        break;
      default:
        item = Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
              child: _buildImage(context, list[0], 0),
            ),
            UiHelper.horizontalSpaceXSmall,
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Container(
                    height: 120,
                    width: 120,
                    child: _buildImage(context, list[1], 1),
                  ),
                ),
                UiHelper.verticalSpaceXSmall,
                Expanded(
                    child: Container(
                  height: 120,
                  width: 120,
                  child: _buildLastItem(context, list[2], list.length, 2),
                ))
              ],
            ),
          ],
        );
    }
    return item;
  }

  Widget _buildLastItem(BuildContext context, PhotoItemModel media, int length, int index) {
    if (length == 3) {
      return _buildImage(context, media, index);
    } else {
      return InkWell(
        onTap: () {
          imageOnTap(context, index);
        },
        child: Hero(
          tag: media.id,
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              CachedImageWidget(
                fit: BoxFit.scaleDown,
                url: media.thumbnail,
                errorWidget: (_, __, ___) => FittedBox(
                  child: Container(
                    constraints: BoxConstraints(),
                    color: Colors.grey,
                  ),
                  fit: BoxFit.cover,
                ),
              ),
              Opacity(
                opacity: 0.50,
                child: Container(
                  color: Colors.black,
                ),
              ),
              Center(
                child: Text(
                  "+${length - 3}",
                  textScaleFactor: 2.0,
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              )
            ],
          ),
        ),
      );
    }
  }

  Widget _buildImage(BuildContext context, PhotoItemModel media, int index) {
    final child = CachedImageWidget(
      fit: BoxFit.scaleDown,
      url: media.thumbnail,
      errorWidget: (_, __, ___) => FittedBox(
        child: Container(
          height: maxHeight,
          width: width,
          constraints: BoxConstraints(),
          color: Colors.grey,
        ),
        fit: BoxFit.cover,
      ),
    );

    if (media.type == MediaType.image) {
      return InkWell(
        child: Hero(
          tag: media.id,
          child: child,
        ),
        onTap: () {
          imageOnTap(context, index);
        },
      );
    } else {
      return InkWell(
        child: child,
        onTap: () {
          imageOnTap(context, index);
        },
      );
    }
  }

  void imageOnTap(BuildContext context, int index) {
    Navigator.of(context).push(SlideRightRoute(
        settings: RouteSettings(name: "Gallery"),
        widget: PhotoGaleryView(
          backgroundColor: Colors.transparent,
          initialIndex: index,
          photos: items,
        )));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: width,
        margin: UiHelper.listItemMarginLarge,
        constraints: BoxConstraints(minHeight: 50.0, maxHeight: maxHeight),
        padding: EdgeInsets.symmetric(vertical: 5.0),
        child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(15.0)),
          child: Container(
            child: _buildMedia(context, items),
          ),
        ));
  }
}
