import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/yammerView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

class VideoPlayerWidgetWrap extends StatelessWidget {
  final String url;
  final ValueChanged<VideoPlayerStatus> listenPlayer;
  const VideoPlayerWidgetWrap({Key key, this.url, this.listenPlayer}) : super(key: key);

  Widget _buildBody(YammerViewModel viewModel){
    if(viewModel.status == Status.busy) return UiHelper.progressIndicator;
    else if(viewModel.status == Status.error) return Center(
      child: Text(viewModel.message, style: TextStyle(color: Colors.white),),
    );
    return VideoPlayerWidget(url: viewModel.urlVideo, listenPlayer: this.listenPlayer,);
  }

  @override
  Widget build(BuildContext context) {
    return  BaseWidget<YammerViewModel>(
      model: new YammerViewModel(yammerService: Provider.of(context)),
      onModelReady: (model) async{
        await model.consultarUrlVideo(url);
        util.unathorized(context, model.status, ()=>null);
      },
      builder: (context, model, child) => _buildBody(model)
    );
  }
}

class VideoPlayerWidget extends StatefulWidget {
  final String url;
  final ValueChanged<VideoPlayerStatus> listenPlayer;

  const VideoPlayerWidget({Key key,this.url, this.listenPlayer}) : super(key: key);

  @override
  _VideoPlayerWidgetState createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  VideoPlayerController _controller;
  VideoPlayerStatus _status = VideoPlayerStatus.stopped;

  @override
  void initState() { 
    _controller = VideoPlayerController.network(widget.url);
    _controller.addListener(() {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        if(!_controller.value.hasError){
          var duration = _controller.value.duration.inSeconds;
          var position = _controller.value.position.inSeconds;

          _status = _controller.value.isPlaying  ? VideoPlayerStatus.play : position == 0 || position < duration ? VideoPlayerStatus.stopped : VideoPlayerStatus.replay;
                  
        }else{
          _status = VideoPlayerStatus.error;
        }
        widget?.listenPlayer?.call(_status);
    });
    Future.delayed(Duration(milliseconds: 1200),()=>_controller.initialize());

    super.initState();
  }

  @override
  void dispose() { 
    _controller?.pause();
    _controller?.dispose();
    super.dispose();
  }

  void _onTap() async{
    if(_status == VideoPlayerStatus.replay){
      await _controller.seekTo(new Duration(seconds: 0));
      await _controller.play();
    }
    else if(_status != VideoPlayerStatus.error){
      _controller.value.isPlaying ? _controller.pause() : _controller.play();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Center(
        child: AspectRatio(
          aspectRatio: _controller.value.aspectRatio,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: <Widget>[
              VideoPlayer(_controller),
              _PlayPauseOverlay(onTap:_onTap,status: _status,),
              _status != VideoPlayerStatus.error ?  VideoProgressIndicator(_controller, allowScrubbing: true) : SizedBox.shrink() ,
            ],
          ),
        )
      ),
    );
  }
}

class _PlayPauseOverlay extends StatefulWidget {
  final VideoPlayerStatus status;
  final VoidCallback onTap;

  const _PlayPauseOverlay({Key key, this.status = VideoPlayerStatus.stopped, @required this.onTap}): super(key: key);

  @override
  _PlayPauseOverlayState createState() => _PlayPauseOverlayState();
}

class _PlayPauseOverlayState extends State<_PlayPauseOverlay> {
  final _size = 100.0;

  Widget _buildState(){
    switch (widget.status) {
      case VideoPlayerStatus.stopped:
        return Container(
          color: Colors.black26,
          child: Center(
            child: Icon(
              Icons.play_arrow,
              color: Colors.white,
              size: _size,
            ),
          ),
        );
        break;
      case VideoPlayerStatus.error:
        return Container(
          color: Colors.black26,
          child: Center(
            child: Icon(
              Icons.error_outline,
              color: Colors.white,
              size: _size,
            ),
          ),
        );
        break;
      case VideoPlayerStatus.replay:
        return Container(
          color: Colors.black26,
          child: Center(
            child: Icon(
              Icons.replay,
              color: Colors.white,
              size: _size,
            ),
          ),
        );
        break;
      default:
        return SizedBox.shrink();
          break;
    }

  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        AnimatedSwitcher(
          duration: Duration(milliseconds: 50),
          reverseDuration: Duration(milliseconds: 200),
          child: _buildState(),
        ),
        GestureDetector(
          onTap: widget.onTap
        ),
      ],
    );
  }
}

enum VideoPlayerStatus { 
   play, 
   stopped,
   replay,
   error
}