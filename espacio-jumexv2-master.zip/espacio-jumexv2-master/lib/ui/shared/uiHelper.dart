import 'package:flutter/material.dart';

class UiHelper {
  static const formItemsPadding = const EdgeInsets.symmetric(vertical: 15.0, horizontal: 30.0);
  static const formItemsMargin = const EdgeInsets.only(top: 12.0);
  static const compactFormItemsPadding = const EdgeInsets.symmetric(vertical: 5.0, horizontal: 30.0);

  static const listItemPadding = const EdgeInsets.all(10.0);
  static const compactListItemPadding = const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0);
  static const listItemMarginLarge = const EdgeInsets.only(bottom: 5.0);
  static const listItemConstraintsLarge = const BoxConstraints(minHeight: 75.0);
  static const listItemConstraintsSmall = const BoxConstraints(minHeight: 40.0);

  static const listFirstInternalItemPadding = const EdgeInsets.only(left: 20.0);
  static const listInternalItemPadding = const EdgeInsets.only(left: 20.0,top: 10.0);
  static const listLastInternalItemPadding = const EdgeInsets.only(left: 20.0,top: 10.0,bottom: 10.0);
  static const listHeaderItemPaddingLarge = const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0);

  static const double _verticalSpaceXSmall = 5.0;
  static const double _verticalSpaceSmall = 10.0;
  static const double _verticalSpaceMedium = 20.0;
  static const double _verticalSpaceLarge = 60.0;
  static const double _verticalSpaceXLarge = 120.0;

  static const double _horizontalSpaceXSmall = 5.0;
  static const double _horizontalSpaceSmall = 10.0;
  static const double _horizontalSpaceMedium = 20.0;
  static const double _horizontalSpaceLarge = 60.0;

  static const Widget verticalSpaceXSmall = SizedBox(height: _verticalSpaceXSmall);
  static const Widget verticalSpaceSmall = SizedBox(height: _verticalSpaceSmall);
  static const Widget verticalSpaceMedium = SizedBox(height: _verticalSpaceMedium);
  static const Widget verticalSpaceLarge = SizedBox(height: _verticalSpaceLarge);
  static const Widget verticalSpaceXLarge = SizedBox(height: _verticalSpaceXLarge);

  static const Widget horizontalSpaceXSmall = SizedBox(width: _horizontalSpaceXSmall);
  static const Widget horizontalSpaceSmall = SizedBox(width: _horizontalSpaceSmall);
  static const Widget horizontalSpaceMedium = SizedBox(width: _horizontalSpaceMedium);
  static const Widget horizontalSpaceLarge = SizedBox(width: _horizontalSpaceLarge);

  static const Color colorHorizontalDivider = const Color(0xFFBDBDBD);
  static const Widget horizontalDivider = const Divider( color: colorHorizontalDivider, );

  static const Widget progressIndicator = Center( child: CircularProgressIndicator(), );
  static const Widget linearProgressIndicator = Center( child: LinearProgressIndicator(), );
}