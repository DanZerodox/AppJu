import 'package:flutter/material.dart';

const primaryColor        = const Color(0xff4744a4); //71 68 164
const primaryLightColor   = const Color(0xff7a6fd6);
const primaryDarkColor    = const Color(0xff041d74);
const secondaryColor      = const Color(0xff36b147);
const secondaryLightColor = const Color(0xff6fe475);
const secondaryDarkColor  = const Color(0xff008018);
const bodytextColor       = const Color(0xff4F4E4D);

final ThemeData companyThemeData = _buildShrineTheme();

ThemeData _buildShrineTheme() {
  ThemeData base = ThemeData.light();

  return base.copyWith(
      primaryColor: primaryColor,
      primaryColorDark: primaryDarkColor,
      primaryColorLight: primaryLightColor,
      accentColor: secondaryColor,
      bottomAppBarColor: secondaryDarkColor,
      buttonColor: secondaryLightColor,
      textTheme: _buildTextTheme(base.textTheme),
      primaryTextTheme: _buildTextTheme(base.primaryTextTheme),
      accentTextTheme: _buildTextTheme(base.accentTextTheme),
      inputDecorationTheme: InputDecorationTheme(
        border: UnderlineInputBorder(
          borderSide: BorderSide(
            color: primaryColor
          )
        )
      ),
      sliderTheme: SliderThemeData.fromPrimaryColors(
        primaryColor: primaryColor,
        primaryColorDark: primaryDarkColor,
        primaryColorLight: primaryLightColor,
        valueIndicatorTextStyle: TextStyle()
      ),
      buttonTheme: ButtonThemeData(
        textTheme: ButtonTextTheme.primary
      )
    // TODO: Add the icon themes (103)
    // TODO: Decorate the inputs (103)
  );
}

TextTheme _buildTextTheme(TextTheme base) {
  return base.copyWith(
    headline5: base.headline5.copyWith(
      fontWeight: FontWeight.w500,
    ),
    headline6: base.headline6.copyWith(
      fontSize: 18.0,
      fontWeight: FontWeight.w800,
      //color: Colors.white
    ),
    caption: base.caption.copyWith(
      fontWeight: FontWeight.w400,
      fontSize: 14.0,
    ),
    bodyText2: base.bodyText2.copyWith(
      color: bodytextColor
    )
  ).apply(
    fontFamily: "Lucida",
  );
}

//4F4E4D