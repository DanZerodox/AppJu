
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';

class CumpleaniosItemWidget extends StatelessWidget {
  final String nombre;
  final String fecha;
  final String localidad;
  final VoidCallback onTap;
  final int hasMobile;

  CumpleaniosItemWidget({Key key,
    @required this.fecha, 
    @required this.localidad, 
    @required this.nombre,
    @required this.onTap,
    @required this.hasMobile,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListItemWidget(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(10),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(right: 10),
              child: CircleAvatar(
                key: GlobalKey(),
                radius: 25.0,
                child: ClipOval(
                  child: Text(nombre[0])
                ),
              ),
            ),
            Flexible(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(nombre,style: TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.left,),
                  UiHelper.verticalSpaceSmall,
                  Text(fecha ?? "--",textScaleFactor: 0.8,style: TextStyle(fontStyle: FontStyle.italic)),
                  UiHelper.verticalSpaceSmall,
                  Text(localidad ?? "--",textScaleFactor: 0.8,style: TextStyle(fontStyle: FontStyle.italic)),
                ],
              )
            )
          ],
        )
      )
    );
  }
}