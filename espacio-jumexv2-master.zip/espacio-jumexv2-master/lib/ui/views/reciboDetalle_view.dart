import 'package:espacio_jumex/core/models/recibo_model.dart';
import 'package:espacio_jumex/ui/views/reciboDetalle_widget.dart';
import 'package:flutter/material.dart';

class ReciboDetalleView extends StatelessWidget {
  final ReciboModel reciboModel;
  const ReciboDetalleView({Key key,this.reciboModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView(
        children: <Widget>[
          ReciboDetalleWidget(reciboModel: reciboModel,)
        ],
      ),
    );
  }
}