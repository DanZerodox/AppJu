import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';

part 'helpers/messageAction.dart';

class MessageListWidget extends StatefulWidget {

  final Widget Function(BuildContext context, int index) itemBuilder;
  final Future<void> Function(MessageAction action) onRefresh;
  final List<Widget> Function(BuildContext context) buildSlivers;
  final Widget Function(BuildContext context) errorWidget;

  final Status status;
  final bool pullMore;
  final int itemCount;

  MessageListWidget({
    Key key,
    this.itemBuilder,
    @required this.onRefresh,
    this.buildSlivers,
    this.status,
    this.pullMore,
    this.itemCount,
    this.errorWidget
  }):
    assert(!(itemBuilder != null && buildSlivers != null)), 
    assert(itemBuilder != null || buildSlivers != null),
   super(key: key);

  @override
  _MessageListWidgetState createState() => _MessageListWidgetState();
}

class _MessageListWidgetState extends State<MessageListWidget> {
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();

  @override
  void initState() { 
    WidgetsBinding.instance
        .addPostFrameCallback((_){
          _refreshIndicatorKey.currentState.show();
        });

    super.initState();
  }

  Future<void> _executeFunction(MessageAction action) async{
    await widget.onRefresh(action);
  }

  List<Widget> _buildSlivers(){
    final btn = _LoadMoreButtonWidget(
      onPress: _executeFunction,
      status: widget.status,
      visible: widget.pullMore ,
    );

    final listed = <Widget>[];
    if(widget.itemBuilder != null ){
      listed.add(_buildContentSliver());
    }else{
      listed.addAll(widget.buildSlivers(context) );
    }
    
    listed.add(SliverList(
      delegate: SliverChildBuilderDelegate(
        (context,index)=>btn,
        childCount: 1
      )
    ));

    return listed;
  }

  Widget _buildContentSliver(){
    return SliverList(
      delegate: SliverChildListDelegate(
        List.generate(widget.itemCount +1, (index){
          
          if(index<widget.itemCount)
             return Padding(
               padding: EdgeInsets.symmetric(horizontal: 10.0),
               child: widget.itemBuilder(context,index)
             );
          else
            return _LoadMoreButtonWidget(
              onPress: _executeFunction,
              status: widget.status,
              visible:widget.pullMore ,
            );
        })
      ),
    );
  }

  Widget _buildErrorWidget(){
    final funct = widget.errorWidget ?? (_)=>Center(
          child: Text("Ooops! A ocurrido un error inesperado"),
        );

    return funct(context);
  }

  @override
  Widget build(BuildContext context) {

    switch (widget.status) {
      case Status.busy:
      case Status.free:
        return RefreshIndicator(
          onRefresh: ()=>_executeFunction(MessageAction.refresh),
          key: _refreshIndicatorKey,
          child: CustomScrollView(
            physics: AlwaysScrollableScrollPhysics(),
            slivers: _buildSlivers(),
          ),
        );
        break;
      default:
        return _buildErrorWidget();
    }
  }
}

class _LoadMoreButtonWidget extends StatelessWidget {
  final Status status;
  final Future<void> Function(MessageAction action) onPress;
  final bool visible;
  
  const _LoadMoreButtonWidget({Key key, this.status,this.onPress, this.visible}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return !visible ? UiHelper.verticalSpaceXSmall : status == Status.busy ? Padding(
      padding: EdgeInsets.only(top: 10),
      child: UiHelper.progressIndicator
    ) :
    FlatButton(
      child: Text("Ver más"),
      onPressed: () async{
        await onPress(MessageAction.more);
      },
    );
  }
}