import 'dart:async';
import 'package:espacio_jumex/core/util/utils.dart' show isNullOrEmpty;
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

class CustomWebView extends StatefulWidget {

  final String url;
  final String title;
  final void Function(WebViewController controller) onWebViewCreated;
  final Set<Factory<OneSequenceGestureRecognizer>> gestureRecognizers;

  CustomWebView({Key key,this.url,this.onWebViewCreated, this.gestureRecognizers, this.title}) : super(key: key);

  @override
  _CustomWebViewState createState() => _CustomWebViewState();
}

class _CustomWebViewState extends State<CustomWebView> {
  final Completer<WebViewController> _completerWebViewController = new Completer<WebViewController>();

  bool _loading = true;

  @override
  void initState() { 
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.headline6.copyWith(color: Colors.white);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(widget.title, style: style,),
            isNullOrEmpty(widget.url) ? SizedBox.shrink() : Text(widget.url, style: style.copyWith(fontSize: 10), overflow: TextOverflow.ellipsis,),
          ],
        ),
        centerTitle: false,
        leading: IconButton(icon: Icon(Icons.close), onPressed: (){
          Navigator.of(context).pop();
        }),
        actions: <Widget>[
          NavigationControls(_completerWebViewController.future, widget.url),
        ],
      ),
      body: ProgressHUD(
        loading: _loading,
        child: WebView(
          gestureRecognizers: widget.gestureRecognizers,
          initialUrl: widget.url,
          javascriptMode: JavascriptMode.unrestricted,
          onPageStarted: (_){
            if(!_loading){
              setState(() {
                _loading = true;
              });
            }
          },
          onPageFinished: (_){
            setState(() {
              _loading = false;
            });
          },
          onWebViewCreated: (webViewController) async {
            _completerWebViewController.complete(webViewController);
            widget.onWebViewCreated?.call(webViewController);
          },
        )
      ),
    );
  }
}

class NavigationControls extends StatelessWidget {
  const NavigationControls(this._webViewControllerFuture, this._url): assert(_webViewControllerFuture != null);

  final Future<WebViewController> _webViewControllerFuture;
  final String _url;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<WebViewController>(
      future: _webViewControllerFuture,
      builder: (BuildContext context, AsyncSnapshot<WebViewController> snapshot) {
        final bool webViewReady = snapshot.connectionState == ConnectionState.done;
        final WebViewController controller = snapshot.data;

        return PopupMenuButton<String>(
          icon: Icon(Icons.more_vert),
          itemBuilder: (context) => <PopupMenuEntry<String>>[
            PopupMenuItem(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios, color: Colors.black,),
                    onPressed: !webViewReady
                        ? null
                        : () async {
                            if (await controller.canGoBack()) {
                              await controller.goBack();
                            }
                            Navigator.of(context).pop();
                          },
                  ),
                  IconButton(
                    icon: const Icon(Icons.arrow_forward_ios, color: Colors.black,),
                    onPressed: !webViewReady
                        ? null
                        : () async {
                            if (await controller.canGoForward()) {
                              await controller.goForward();
                            }
                            Navigator.of(context).pop();
                          },
                  ),
                  IconButton(
                    icon: const Icon(Icons.replay, color: Colors.black,),
                    onPressed: !webViewReady
                        ? null
                        : () {
                            controller.reload();
                            Navigator.of(context).pop();
                          },
                  ),
                ],
              )
            ),
            PopupMenuDivider(),
            PopupMenuItem(
              child: ListTile(
                title: Text("Abrir en navegador"),
                onTap: ()async{
                  await launch(_url);
                  Navigator.of(context).pop();
                },
              )
            ),
            PopupMenuItem(
              child: ListTile(
                title: Text("Copiar enlace"),
                onTap: (){
                  Clipboard.setData(new ClipboardData(text: _url));
                  Navigator.of(context).pop();
                },
              )
            )
          ],
        );
      },
    );
  }
}

class ProgressHUD extends StatelessWidget {
  final Widget child;
  final bool loading;
  const ProgressHUD({Key key, this.child, this.loading}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        !loading ? SizedBox.shrink() : LinearProgressIndicator(),
        Expanded(
          child: Container(
            child: child,
          )
        )
      ],
    );
  }
}