import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/vacaciones_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/vacacionesView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class VacacionesPorAutorizarWidget extends StatefulWidget {  

  VacacionesPorAutorizarWidget({Key key}) : super(key: key);

  @override
  _VacacionesPorAutorizarWidgetState createState() => _VacacionesPorAutorizarWidgetState();
}

class _VacacionesPorAutorizarWidgetState extends State<VacacionesPorAutorizarWidget> {
  final _formKey = GlobalKey<FormState>();
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();

  TextEditingController _comentariosController ;
  ProgressDialog _progressDialog;
  String _comentarios = "Rechazado";
  
  @override
  void initState() {
    _comentariosController = TextEditingController.fromValue(TextEditingValue(text:_comentarios));

    _comentariosController.addListener(() {
      _comentarios = _comentariosController.text;
    });

     Future.microtask((){
      final viewModel = Provider.of<VacacionesViewModel>(context);
      viewModel.consultaVacacionesPorAutorizar(Provider.of<UserModel>(context), true).then((_){
        util.unathorized(context, viewModel.status,()=>null);
      });
    });

    super.initState();
  }

  @override
  void dispose() { 
    _comentariosController.dispose();
    super.dispose();
  }

  final arrastrarWidget = Column(
    children: [
      Text("Arrastrar"),
      Icon(Icons.arrow_downward)
    ],
  );

  void _approveSolicitud(VacacionesViewModel viewModel, SolicitudVacacionesModel solicitud) async{
    var reject = await _showApproveDialog();

    if(!reject)
    return;
    
    final user = Provider.of<UserModel>(context,listen: false);
    _progressDialog = util.progressDialogBuilder(context, "Autorizando");

    await _progressDialog.show();
    final success = await viewModel.autorizarVacaciones(user,solicitud);
    await _progressDialog.hide();
    
    if(!success){
      util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
    }
    
    _refreshIndicatorKey.currentState.show();
  }

  void _refuseSolicitud(VacacionesViewModel viewModel, SolicitudVacacionesModel solicitud) async{
    var reject = await _showRefuseDialog();

    if(!reject)
    return;

    final user = Provider.of<UserModel>(context,listen: false);
    _progressDialog = util.progressDialogBuilder(context, "Rechazando");

    await _progressDialog.show();
    final success = await viewModel.rechazarVacaciones(user,solicitud.copyWith(observaciones: _comentarios));
    await _progressDialog.hide();

    if(!success){
      util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
    }

    _refreshIndicatorKey.currentState.show();
  }

  Future<bool> _showRefuseDialog() async{
    return await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return ClipRect(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(32.0))
                ),
                title: Text("Escribe tus observaciones"),
                content: Form(
                  key: _formKey,
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: 5.0,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Comentarios"
                        ),
                        minLines: 1,
                        maxLines: 2,
                        validator: (val)=> val== null || val.isEmpty ? "Ingresar un mensaje" : null,
                        controller: _comentariosController,
                      ),
                    ],
                  ),      
                ),
                actions:<Widget>[
                  FlatButton(
                    child: Text("Cerrar"),
                    onPressed: (){
                      Navigator.of(context).pop(false);
                    },
                  ),
                  FlatButton(
                    child: Text("Enviar"),
                    onPressed: (){
                      final formState = _formKey.currentState;
                      if(formState.validate()){
                        formState.save();
                        Navigator.of(context).pop(true); 
                      }
                    },
                  )
                ],
              ),
            ]
          )
        );
      }
    );
  }

  Future<bool>  _showApproveDialog() async{
    return await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return ClipRect(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(32.0))
                ),
                title: Text("Autorizar vacaciones"),
                content: Text("La solicitud se autorizará."),
                actions:<Widget>[
                  FlatButton(
                    child: Text("Cerrar"),
                    onPressed: (){
                      Navigator.of(context).pop(false);
                    },
                  ),
                  FlatButton(
                    child: Text("Aprobar"),
                    onPressed: (){
                      Navigator.of(context).pop(true); 
                    },
                  )
                ],
              ),
            ]
          )
        );
      }
    );
  }

  Widget _buildList(VacacionesViewModel viewModel){
    final tsolicitudes = viewModel.solicitudesPorAutorizar?.length ?? 0;

    return ListView.builder(
      padding: UiHelper.listItemPadding,
      physics: AlwaysScrollableScrollPhysics(),
      itemCount: tsolicitudes >0 ? tsolicitudes : 1,
      itemBuilder: (context,index){
        if(tsolicitudes == 0){
          return arrastrarWidget;
        }else{
          final item = viewModel.solicitudesPorAutorizar[index];
          return ListItemWidget(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  flex: 3,
                  child: Padding(
                    padding: UiHelper.listItemPadding,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("De ${item.fechaInicio} a ${item.fechaFin}",textScaleFactor: 1.1,style: TextStyle(fontWeight: FontWeight.bold),),
                        UiHelper.verticalSpaceXSmall,
                        Text("${item.nombreColaborador}"),
                        UiHelper.verticalSpaceXSmall,
                        Text("Solicitado: ${item.fechaSolicitud}"),
                        UiHelper.verticalSpaceXSmall,
                        Text("Dias: ${item.dias}"),
                        item.comentarios != null ? UiHelper.verticalSpaceXSmall : SizedBox.shrink(),
                        item.comentarios != null ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Comentarios: "),
                            Expanded(child: Text(item.comentarios), flex: 2,)
                          ],
                        ) : SizedBox.shrink(),
                      ],
                    )
                  )
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check),
                      color: Colors.lightGreen[800],
                      onPressed: (){
                        _approveSolicitud(viewModel, item);
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.close),
                      color: Colors.red,
                      onPressed: (){
                        _refuseSolicitud(viewModel, item);
                      },
                    )
                  ],
                )
              ],
            )
          );
        }
      }
    );
  }

  @override
  Widget build(BuildContext context) {

    return Consumer<VacacionesViewModel>(
      builder: (context,viewModel,child)=>RefreshIndicator(
        onRefresh: () async{
          final result = await viewModel.consultaVacacionesPorAutorizar(Provider.of<UserModel>(context));
          util.unathorized(context, viewModel.status,()=>null);
          return Future.value(()=>result);
        },
        key: _refreshIndicatorKey,
        child: viewModel.statusPendientes == Status.busy && viewModel.init ? UiHelper.progressIndicator : _buildList(viewModel),
      ),
    );
  }
}