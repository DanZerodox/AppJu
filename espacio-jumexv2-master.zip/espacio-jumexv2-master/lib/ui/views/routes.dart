import 'dart:convert';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/faq_model.dart';
import 'package:espacio_jumex/core/models/pdfView_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/slideRightRoute.dart';
import 'package:espacio_jumex/ui/views/accesoExternoList_view.dart';
import 'package:espacio_jumex/ui/views/aprobarDocumento_view.dart';
import 'package:espacio_jumex/ui/views/avisoOportuno_view.dart';
import 'package:espacio_jumex/ui/views/avisoOportunoAdd_view.dart';
import 'package:espacio_jumex/ui/views/buzonCap_view.dart';
import 'package:espacio_jumex/ui/views/correoNomina_view.dart';
import 'package:espacio_jumex/ui/views/credencialAdd_view.dart';
import 'package:espacio_jumex/ui/views/credencial_view.dart';
import 'package:espacio_jumex/ui/views/cumpleaniosMensaje_view.dart';
import 'package:espacio_jumex/ui/views/cumpleanios_view.dart';
import 'package:espacio_jumex/ui/views/faq_view.dart';
import 'package:espacio_jumex/ui/views/ayuda_view.dart';
import 'package:espacio_jumex/ui/views/contrasenia_view.dart';
import 'package:espacio_jumex/ui/views/home_view.dart';
import 'package:espacio_jumex/ui/views/incidenciasAdd_view.dart';
import 'package:espacio_jumex/ui/views/landing_view.dart';
import 'package:espacio_jumex/ui/views/login_view.dart';
import 'package:espacio_jumex/ui/views/pdfViewer_view.dart';
import 'package:espacio_jumex/ui/views/perfil_view.dart';
import 'package:espacio_jumex/ui/views/preevaluate_view.dart';
import 'package:espacio_jumex/ui/views/prestaciones_view.dart';
import 'package:espacio_jumex/ui/views/recibo_view.dart';
import 'package:espacio_jumex/ui/views/restablecerContrasenia_view.dart';
import 'package:espacio_jumex/ui/views/revistaJumex_View.dart';
import 'package:espacio_jumex/ui/views/sugerencias_view.dart';
import 'package:espacio_jumex/ui/views/tarjetaCumpleanios_view.dart';
import 'package:espacio_jumex/ui/views/tramites_view.dart';
import 'package:espacio_jumex/ui/views/accesoExternoContenido_view.dart';
import 'package:espacio_jumex/ui/views/vacacionesAdd_view.dart';
import 'package:espacio_jumex/ui/views/vacaciones_view.dart';
import 'package:espacio_jumex/ui/views/yammerItem_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Routes {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RoutePath.Landing:
        return SlideRightRoute(settings: settings, widget: LandingView());

      case RoutePath.Login:
        var message = settings.arguments as String;
        return SlideRightRoute(settings: settings, widget: LoginView(message: message));

      case RoutePath.PreHome:
        var args = settings.arguments;
        int page = args is String ? int.parse(args) : (args ?? 0);
        return MaterialPageRoute(
          settings: settings,
          builder: (context) => PreHomeWidget(index: page),
        );

      case RoutePath.Home:
        var args = settings.arguments;
        int page = args is String ? int.parse(args) : (args ?? 0);
        return SlideRightRoute(settings: settings, widget: HomeView(index: page));

      case RoutePath.Contrasena:
        return SlideRightRoute(settings: settings, widget: ContraseniaView());

      case RoutePath.Sugerencias:
        return SlideRightRoute(settings: settings, widget: SugerenciasView());

      case RoutePath.Preguntas:
        return SlideRightRoute(settings: settings, widget: AyudaView());

      case RoutePath.BuzonCap:
        return SlideRightRoute(settings: settings, widget: BuzonCapView());

      case RoutePath.FAQ:
        var item = settings.arguments as FAQModel;
        return SlideRightRoute(settings: settings, widget: FAQView(faqModel: item));

      case RoutePath.Preevaluacion:
        final args = settings.arguments;
        int page = args is String ? int.parse(args) : (args ?? 0);
        return SlideRightRoute(
            settings: settings,
            widget: PreevaluateView(
              index: page,
            ));

      case RoutePath.Recibo:
        return SlideRightRoute(settings: settings, widget: ReciboView());

      case RoutePath.Tramites:
        return SlideRightRoute(settings: settings, widget: TramitesView());

      case RoutePath.Credencial:
        return SlideRightRoute(settings: settings, widget: CredencialView());

      case RoutePath.CredencialAdd:
        return SlideRightRoute(settings: settings, widget: CredencialAddView());

      case RoutePath.CorreoNomina:
        return SlideRightRoute(settings: settings, widget: CorreoNominaView());

      case RoutePath.Cumpleanios:
        return SlideRightRoute(settings: settings, widget: CumpleaniosView());

      case RoutePath.CumpleaniosMensaje:
        var items = settings.arguments as List<ColaboradorModel>;
        return SlideRightRoute(settings: settings, widget: CumpleaniosMensajeView(colaboradores: items));

      case RoutePath.TarjetaCumpleanios:
        var tempId = settings.arguments as String;
        return SlideRightRoute(
            settings: settings,
            widget: TarjetaCumpleaniosView(
              tempId: tempId,
            ));

      case RoutePath.Vacaciones:
        var args = settings.arguments;
        int page = args is String ? int.parse(args) : (args ?? 0);
        return SlideRightRoute(
            settings: settings,
            widget: VacacionesView(
              index: page,
            ));

      case RoutePath.VacacionesAdd:
        return SlideRightRoute(settings: settings, widget: VacacionesAddView());

      case RoutePath.Bienvenida:
        return SlideRightRoute(settings: settings, widget: BienvenidaView());

      case RoutePath.Normatividad:
        return SlideRightRoute(settings: settings, widget: NormatividadView());

      case RoutePath.AvisoOportuno:
        var args = settings.arguments;
        int page = args is String ? int.parse(args) : (args ?? 0);
        return SlideRightRoute(
            settings: settings,
            widget: AvisoOportunoView(
              index: page,
            ));

      case RoutePath.AvisoOportunoAdd:
        return SlideRightRoute(settings: settings, widget: AvisoOportunoAddView());

      case RoutePath.Beneficios:
        return SlideRightRoute(settings: settings, widget: BeneficiosView());

      case RoutePath.Noticias:
        return SlideRightRoute(settings: settings, widget: NoticiasView());

      case RoutePath.Vacantes:
        return SlideRightRoute(settings: settings, widget: VacantesView());

      case RoutePath.YammerDetail:
        final item = settings.arguments as YammerModel;
        return SlideRightRoute(settings: settings, widget: YammerItemView(yammerModel: item));

      case RoutePath.Revista:
        return SlideRightRoute(settings: settings, widget: RevistaJumexView());
        break;

      case RoutePath.VisualizarPdf:
        final args = settings.arguments;
        final item = args is String ? PdfViewModel.fromJson(JsonDecoder().convert(args)) : args as PdfViewModel;
        return SlideRightRoute(
            settings: settings,
            widget: PdfViewerView(
              pdf: item,
            ));
        break;

      case RoutePath.Perfil:
        return SlideRightRoute(settings: settings, widget: PerfilView());
        break;

      case RoutePath.ContenidoExterno:
        final args = settings.arguments;
        final item = args is String ? AccesoModel.fromJson(JsonDecoder().convert(args)) : args as AccesoModel;
        return SlideRightRoute(settings: settings, widget: AccesoExternoContenidoView(accesoModel: item));
        break;

      case RoutePath.AccesoExterno:
        final args = settings.arguments;
        int item = args is String ? int.parse(args) : (args ?? 0);
        return SlideRightRoute(settings: settings, widget: AccesoExternoListView(idAcceso: item));
        break;

      case RoutePath.AvisoLegal:
        return SlideRightRoute(settings: settings, widget: AprobarDocumentoView());
        break;

      case RoutePath.RestablecerContrasena:
        var item = settings.arguments as String;
        return SlideRightRoute(
            settings: settings,
            widget: RestablecerContrasenia(
              usuario: item,
            ));
        break;

      case RoutePath.IncidenciasAdd:
        return SlideRightRoute(settings: settings, widget: IncidenciasAddView());
        break;

      default:
        return MaterialPageRoute(
            builder: (_) => Scaffold(
                  body: Center(
                    child: Text('No route defined for ${settings.name}'),
                  ),
                ));
    }
  }
}
