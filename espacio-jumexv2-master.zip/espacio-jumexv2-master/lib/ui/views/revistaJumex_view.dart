import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/pdfView_model.dart';
import 'package:espacio_jumex/core/models/photoItem_model.dart';
import 'package:espacio_jumex/core/models/revistaJumex_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/resourceView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/photoGalery_view.dart';
import 'package:espacio_jumex/ui/widgets/cachedImage_widget.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class RevistaJumexView extends StatefulWidget {
  RevistaJumexView({Key key}) : super(key: key);

  @override
  _RevistaJumexViewState createState() => _RevistaJumexViewState();
}

class _RevistaJumexViewState extends State<RevistaJumexView> {
  Widget _buildBody(ResourceViewModel viewModel, Widget progress, TargetPlatform targetPlatform) {
    switch (viewModel.status) {
      case Status.busy:
        return progress;
        break;
      case Status.free:
        return (viewModel.revistas?.length ?? 0) > 0
            ? _buildContent(viewModel, targetPlatform)
            : Center(
                child: Text("No hay revistas que mostrar"),
              );
        break;
      default:
        return Center(
          child: Text(viewModel.message),
        );
    }
  }

  Widget _buildContent(ResourceViewModel viewModel, TargetPlatform targetPlatform) {
    var revistas = viewModel.revistas;

    final tokenHeaders = Map<String, String>.fromEntries([MapEntry<String, String>('token', Provider.of<UserModel>(context).tokenAcceso)]);

    return ListView.builder(
        padding: UiHelper.listItemPadding,
        itemCount: viewModel.revistas.length,
        itemBuilder: (context, index) => ListItemWidget(
              child: Padding(
                  padding: EdgeInsets.only(right: 10, top: 5, bottom: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          margin: EdgeInsets.only(right: 10.0),
                          child: SizedBox.fromSize(
                              size: Size(70, 100),
                              child: CachedImageWidget(
                                headers: tokenHeaders,
                                url: "${ApiConstant.apiEndpoint}/Resource/revista/${revistas[index].id}/${revistas[index].resourceModels[0].id}",
                                errorWidget: (context, url, error) => Center(
                                  child: Icon(Icons.broken_image),
                                ),
                              ))),
                      Flexible(child: Text(viewModel.revistas[index].nombre))
                    ],
                  )),
              onTap: () {
                _goToJourney(viewModel.revistas[index], tokenHeaders);
              },
            ));
  }

  void _goToJourney(RevistaJumexModel resourceModel, Map<String, String> tokenHeaders) async {
    if (resourceModel.type == MediaType.image) {
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => PhotoGaleryView(
                headers: tokenHeaders,
                backgroundColor: Colors.transparent,
                initialIndex: 0,
                photos: resourceModel.resourceModels
                    .map<PhotoItemModel>((x) => PhotoItemModel(id: x.id, url: "${ApiConstant.apiEndpoint}/Resource/revista/${resourceModel.id}/${x.id}", type: resourceModel.type))
                    .toList(),
              )));
    } else {
      Navigator.of(context)
          .pushNamed(RoutePath.VisualizarPdf, arguments: new PdfViewModel(title: resourceModel.nombre, url: "${ApiConstant.apiEndpoint}/Resource/revista/${resourceModel.id}"));
    }
  }

  @override
  Widget build(BuildContext context) {
    final targetPlatform = Theme.of(context).platform;

    return BaseWidget<ResourceViewModel>(
      model: ResourceViewModel(resourceService: Provider.of(context), customCacheManager: Provider.of(context)),
      onModelReady: (model) {
        model.consultaRevistas(Provider.of<UserModel>(context)).then((_) {
          util.unathorized(context, model.status, () => null);
        });
      },
      child: UiHelper.progressIndicator,
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          title: Text("Revista Jumex"),
          centerTitle: false,
        ),
        body: _buildBody(model, child, targetPlatform),
      ),
    );
  }
}
