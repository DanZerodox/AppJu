import 'package:espacio_jumex/core/models/incidencia_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class IncidenciasListWidget extends StatefulWidget {
  IncidenciasListWidget({Key key}) : super(key: key);

  @override
  _IncidenciasListWidgetState createState() => _IncidenciasListWidgetState();
}

class _IncidenciasListWidgetState extends State<IncidenciasListWidget> {
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();
  ProgressDialog _progressDialog;

  final arrastrarWidget = Column(
    children: [
      Text("Arrastrar"),
      Icon(Icons.arrow_downward)
    ],
  );

   @override
  void initState() {
    Future.microtask((){
      final viewModel = Provider.of<IncidenciasViewModel>(context);
      viewModel.consultaIncidencias(Provider.of<UserModel>(context), true).then((_){
        util.unathorized(context, viewModel.status,()=>null);
      });
    });

    super.initState();
  }

  void _deleteIncidencia(IncidenciasViewModel viewModel, IncidenciaModel solicitud) async{
    final bool delete = await _showConfirmDialog();

    if(!delete) return;

    final user = Provider.of<UserModel>(context);
    _progressDialog = util.progressDialogBuilder(context, "Eliminando");

    await _progressDialog.show();
    final success = await viewModel.borrarIncidencia(user,solicitud);
    await _progressDialog.hide();

    if(!success){
      util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
    }
    _refreshIndicatorKey.currentState.show();
  }

  Widget _buildBody(IncidenciasViewModel viewModel){
    final tsolicitudes = viewModel.incidencias?.length ?? 0;

    return ListView.builder(
      padding: UiHelper.listItemPadding,
      physics: AlwaysScrollableScrollPhysics(),
      itemCount: tsolicitudes == 0 ? 1 : tsolicitudes,
      itemBuilder: (context,index){
        if(tsolicitudes == 0){
          return arrastrarWidget;
        }else{
          final item = viewModel.incidencias[index];
          return ListItemWidget(
            child: ExpansionTile(
              key: PageStorageKey<String>(item.id.toString()),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              expandedAlignment: Alignment.centerLeft,
              initiallyExpanded: item.estatus == "INIT",
              trailing: item.estatus != "INIT" ? null : IconButton(
                icon: Icon(Icons.delete),
                color: Colors.red[400],
                onPressed: (){
                  _deleteIncidencia(viewModel, item);
                },
              ),
              title: Text("${item.concepto}", style: TextStyle(color: item.estatus == 'RECH' ?  Colors.red[400] : item.estatus == 'PROC' ? Colors.green[400] : Colors.black ),),
              children: [
                Padding(
                  padding: UiHelper.listFirstInternalItemPadding,
                  child: item.fechaInicio != item.fechaFin ? Text("De ${item.fechaInicio} al ${item.fechaFin}") : Text("El: ${item.fechaInicio}"),
                ),
                Padding(
                  padding: UiHelper.listInternalItemPadding,
                  child: item.horaInicio != null && item.horaInicio.isNotEmpty ? Text("Horario: ${item.horaInicio} a ${item.horaFin}") : Text("Cantidad: ${item.cantidad}"),
                ),
                Padding(
                  padding: UiHelper.listInternalItemPadding,
                  child: Text("Solicitado: ${item.fechaRegistro}"),
                ),
                Padding(
                  padding: UiHelper.listInternalItemPadding,
                  child: Text("Estatus: ${item.estatusDesc}"),
                ),
                item.observaciones != null && item.observaciones.isNotEmpty ? Padding(
                  padding: UiHelper.listInternalItemPadding,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Observaciones:"),
                      Expanded(child: Text( item.observaciones ?? "-"), flex: 2,)
                    ],
                  ),
                ) : SizedBox.shrink(),
                item.motivo != null && item.motivo.isNotEmpty ? Padding(
                  padding: UiHelper.listInternalItemPadding,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Motivo:"),
                      Expanded(child: Text( item.motivo ?? "-"), flex: 2,)
                    ],
                  ),
                ) : SizedBox.shrink(),
                Padding(
                  padding: UiHelper.listLastInternalItemPadding,
                  child: Text("Folio: ${item.id}"),
                ),
              ],
            )
          );
        }
      }
    );
  }

  Future<bool>  _showConfirmDialog() async{
    return await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return ClipRect(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(32.0))
                ),
                title: Text("Borrar incidencia"),
                content: Text("¿Estas seguro de borrar la incidencia?"),
                actions:<Widget>[
                  FlatButton(
                    child: Text("Cerrar"),
                    onPressed: (){
                      Navigator.of(context).pop(false);
                    },
                  ),
                  FlatButton(
                    child: Text("Borrar"),
                    onPressed: (){
                      Navigator.of(context).pop(true); 
                    },
                  )
                ],
              ),
            ]
          )
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {

     return Consumer<IncidenciasViewModel>(
      builder: (context,viewModel,child)=>RefreshIndicator(
        key: _refreshIndicatorKey,
        onRefresh: () async{
          final response = await viewModel.consultaIncidencias(Provider.of<UserModel>(context));
          util.unathorized(context, viewModel.status,()=>null);
          return Future.value(()=>response);
        },
        child: viewModel.statusInci == Status.busy && viewModel.initIncidencias ? UiHelper.progressIndicator : _buildBody(viewModel),
      ),
    );
  }
}