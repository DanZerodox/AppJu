import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/configuration_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/appView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class AjustesWidget extends StatefulWidget {
  final Status status;
  AjustesWidget({Key key, this.status}) : super(key: key);

  @override
  _AjustesWidgetState createState() => _AjustesWidgetState();
}

class _AjustesWidgetState extends State<AjustesWidget> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  ProgressDialog _progressDialog;

  @override
  void initState() {
    Future.microtask((){
      Provider.of<AppViewModel>(context).configuracionLocal();
    });

    super.initState();
  }

  void _cerrarSesion(AppViewModel viewModel) async{
    _progressDialog = util.progressDialogBuilder(context,"Cerrando sesión");

    await _progressDialog.show();
    await viewModel.signOut(Provider.of<UserModel>(context,listen: false));
    await _progressDialog.hide();

    Navigator.of(context).pushNamedAndRemoveUntil(RoutePath.Login,(_)=>false);
  }

  void _ajustarNotificacionCumpleanios(AppViewModel viewModel, ConfigurationModel configurationModel, bool value) async{
    final activo = configurationModel.bitActivo;
    bool confirm = true;

    if(activo == 1){
      confirm = await _showConfirmDialog("Al desactivar esta opción, ya no recibirá correos ni notificaciones de cumpleaños, ¿desea continuar?");

      if(!confirm){
        return;
      }
    }

    if(activo == 1 ){
      _progressDialog = util.progressDialogBuilder(context,"Desactivando");
    }else{
      _progressDialog = util.progressDialogBuilder(context,"Activando");
    }

    await _progressDialog.show();
    final success = await viewModel.actualizaConfiguracion(Provider.of<UserModel>(context), configurationModel, value ? 1 : 0);
    await _progressDialog.hide();

    if(!success){
      util.unathorized(context, viewModel.status, ()=>util.showAlertPopup(context, "¡Advertencia!", viewModel.message));
    }
  }

  void _sincronizarInformacion(AppViewModel viewModel) async{
    _progressDialog = util.progressDialogBuilder(context,"Sincronizando");

    await _progressDialog.show();
    final success = await viewModel.sincronizarInformacion(Provider.of<UserModel>(context));
    await _progressDialog.hide();
    
    if(!success){
      util.unathorized(context, viewModel.status, ()=>util.showAlertPopup(context, "¡Advertencia!", viewModel.message));
    }

  }

  Future<bool> _showConfirmDialog(String content){
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context)=>AlertDialog(
        title: Text("¡Advertencia!"),
        content: Text(content),
        actions: <Widget>[
          FlatButton(
            onPressed: (){
              Navigator.of(context).pop(false);
            }, 
            child: Text("Cancelar")
          ),
          FlatButton(
            onPressed: (){
              Navigator.of(context).pop(true);
            }, 
            child: Text("Desactivar")
          )
        ],
      )
    );
  }

  Widget _buildBody(AppViewModel appViewModel){

    return Scaffold(
      key: _scaffoldKey,
      body: ListView(
        padding: EdgeInsets.all(0.0),
        children: <Widget>[
          Column(
            children: <Widget>[
              new ListTile(
                title: const Text("Cuenta",textScaleFactor: .9,style: const TextStyle(fontWeight: FontWeight.bold),),
              ),
              ListTile(
                title: const Text("Información"),
                onTap: (){
                  Navigator.of(context).pushNamed(RoutePath.Perfil);
                },
              ),
              UiHelper.horizontalDivider,
              ListTile(
                title: const Text("Cambiar contraseña"),
                onTap: (){
                  Navigator.of(context).pushNamed(RoutePath.Contrasena).then((val){
                    if(val!= null){
                      util.showAlertPopup(context, "¡Atención!", val);
                    }
                  });
                },
              ),
              UiHelper.horizontalDivider,
              ListTile(
                title: const Text("Sugerencias"),
                subtitle: const Text("Haznos saber tu opinión sobre esta aplicación"),
                onTap: () async{
                  Navigator.of(context).pushNamed(RoutePath.Sugerencias).then((value){
                    if(!util.isNullOrEmpty(value)){
                      util.showAlertPopup(context, "¡Atención!", value);
                    }
                  });
                },
              ),
              UiHelper.horizontalDivider,
              ListTile(
                title: const Text("Cerrar sesión"),
                onTap: (){
                  _cerrarSesion(appViewModel);
                },
              ),
              UiHelper.horizontalDivider,
              ListTile(
                title: const Text("Sincronizar"),
                subtitle: const Text("Sincronizar menú (se perderá la personalización), preguntas frecuentes y directorio"),
                onTap: (){
                  _sincronizarInformacion(appViewModel);
                },
              ),
              UiHelper.horizontalDivider,
              new ListTile(
                title: const Text("Notificaciones",textScaleFactor: .9,style: const TextStyle(fontWeight: FontWeight.bold),),
              ),
              SwitchListTile(value: appViewModel.configuracion?.cumpleanios?.bitActivo == 1, onChanged: (value){
                  _ajustarNotificacionCumpleanios(appViewModel, appViewModel.configuracion.cumpleanios, value);
                },
                title: const Text("Recibir correo y notificación en mi cumpleaños"),
              ),
              UiHelper.horizontalDivider,
              SwitchListTile(value: appViewModel?.configuracion?.cumpleaniosColaborador?.bitActivo == 1, onChanged: (value){
                  _ajustarNotificacionCumpleanios(appViewModel, appViewModel.configuracion.cumpleaniosColaborador, value);
                },
                title: const Text("Recibir correos en cumpleaños de mis compañeros"),
              ),
              UiHelper.horizontalDivider,
              new ListTile(
                title: const Text("Aplicación",textScaleFactor: .9,style: const TextStyle(fontWeight: FontWeight.bold),),
              ),
              ListTile(
                title: const Text("Limpiar caché"),
                subtitle: const Text("Se eliminarán las imágenes temporales del dispositivo"),
                onTap: () async{
                  _progressDialog = util.progressDialogBuilder(context,"Limpiando cache");
                  await _progressDialog.show();
                  await appViewModel.limpiarCache();
                  await _progressDialog.hide();
                },
              ),
              UiHelper.horizontalDivider,
              new ListTile(
                title: const Text("Versión"),
                subtitle: Text(appViewModel.appVersion ?? ""),
              ),
              UiHelper.verticalSpaceMedium,
            ],
          )
        ],
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppViewModel>(
      builder: (context, viewModel, child) => widget.status == Status.busy || viewModel.status == Status.busy ? Center(
        child: UiHelper.progressIndicator,
      ) :  _buildBody(viewModel),
    );
  }
}