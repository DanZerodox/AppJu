import 'package:espacio_jumex/core/viewmodel/view/userView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:flutter/services.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class RestablecerContrasenia extends StatefulWidget {
  final String usuario;

  RestablecerContrasenia({Key key,this.usuario}) : super(key: key);

  @override
  _RestablecerContraseniaState createState() => _RestablecerContraseniaState();
}

class _RestablecerContraseniaState extends State<RestablecerContrasenia> {

  final _scaffoldKey = GlobalKey<ScaffoldState>();

  static final _formKey = GlobalKey<FormState>();

  final _usuarioFocus = FocusNode();
  final _usuarioController = new TextEditingController();

  String _usuario;
  ProgressDialog _progressDialog;
  bool _success = false;

  @override
  void initState() {
    _usuarioController.text = widget.usuario;
    _usuario = widget.usuario;

    _usuarioController.addListener((){
      _usuario = _usuarioController.text;
    });

    super.initState();
  }

  @override
  void dispose() {
    _usuarioController.dispose();
    super.dispose();
  }

  Widget _buildForm(UserViewModel model){
    final padding = UiHelper.formItemsPadding;

    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          Padding(
            padding: padding,
            child: TextFormField(
              decoration: InputDecoration(
                labelText: "Usuario",
                hintText: "Ingresa tu numero de empleado",
                contentPadding: const EdgeInsets.symmetric(vertical: 20),
              ),
              autocorrect: false,
              controller: _usuarioController,
              validator: (val) => val == null || val.isEmpty ? "El valor es requerido" : null,
              focusNode: _usuarioFocus,
              keyboardType: TextInputType.number,
              textInputAction: TextInputAction.done,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r"^[\d]+$"))
              ],
              onFieldSubmitted: (_){
                _usuarioFocus.unfocus();
                _submit(model);
              },
            ),
          ),
        ],
      )
    );
  }

  Widget _buildSubmitButton(UserViewModel viewModel){
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Recuperar",
        onSubmit: (){
          _submit(viewModel);
        },
      ),
    );
  }

  void _submit(UserViewModel viewModel) async{
    FocusScope.of(context).requestFocus(new FocusNode());
    
    final formState = _formKey.currentState;
    if(formState.validate()){
      formState.save();

      await _progressDialog.show();
      _success = await viewModel.recuperarContrasenia(_usuario);
      await _progressDialog.hide();

      util.showAlertPopup(context, _success ? "¡Atención!":  "¡Advertencia!", viewModel.message);

    }
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context,"Validando");

    return BaseWidget<UserViewModel>(
      model: UserViewModel(userService: Provider.of(context)),
      builder: (context,UserViewModel model,child)=>Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          title: const Text("Recuperar contraseña"),
          centerTitle: false,
        ),
        body: new ListView(
          padding: UiHelper.listItemPadding,
          children: <Widget>[
            Card(
              child: new Column(
                children: <Widget>[
                  _buildForm(model),
                  !_success ? _buildSubmitButton(model) : UiHelper.verticalSpaceSmall
                ],
              )
            )
          ],
        ),
      ),
    );
  }
}