import 'dart:convert';
import 'package:espacio_jumex/core/models/preevaluate_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/slideRightRoute.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/customWeb_view.dart';
import 'package:espacio_jumex/ui/widgets/dateTime_formfield.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class PreevaluateWidget extends StatefulWidget {
  PreevaluateWidget({Key key}) : super(key: key);

  @override
  _PreevaluateWidgetState createState() => _PreevaluateWidgetState();
}

class _PreevaluateWidgetState extends State<PreevaluateWidget> {
  
  final _formKey = GlobalKey<FormState>();

  ProgressDialog _progressDialog;

  Widget _buildDateInput(IncidenciasViewModel viewModel){
    return Card(
      child: Form(
        key: _formKey,
        child: Padding(
          padding: UiHelper.formItemsPadding,
          child: DateTimeFormField(
            label: "Ingresar fecha",
            dateFormat: viewModel.dateFormat,
            validator: (value)=>value == null ? "Indicar una fecha válida" : null,
            onDateSelected: (value)=>_captureDate(viewModel,value),
            firstDate: DateTime(DateTime.now().year-1),
            lastDate: DateTime.now().add(Duration(days: 1)),
            initialValue: viewModel.fechaPreevaluar,
            decoration: InputDecoration(
              suffixIcon: Icon(Icons.calendar_today),
              labelText: "Fecha"
            ),
          ),
        ),
      ),
    );
  }

  void _captureDate(IncidenciasViewModel viewModel, DateTime date) async{
    final state = _formKey.currentState;

    if(state.validate()){
      
      await _progressDialog.show();
      final success = await viewModel.consultaPreevaluacion(Provider.of<UserModel>(context),  date);
      await _progressDialog.hide();

      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }
    }
  }

  List<Widget> _buildPreevaluate(IncidenciasViewModel viewModel){
    final preevaluate = viewModel.preevaluacion;
    final items = <Widget>[
      UiHelper.verticalSpaceSmall,
    ];

    if(preevaluate != null){
      final periodo = [
        Text("Periodo: Del ${preevaluate.periodoInicio ?? "Sin seleccionar"} al ${preevaluate.periodoFin ?? ""}",style: const TextStyle(fontWeight: FontWeight.bold),),
        UiHelper.verticalSpaceSmall,
        RaisedButton(
          child: Text("Ver texto"),
          onPressed: () async{
            Navigator.of(context).push(SlideRightRoute(
              settings: RouteSettings(name: "webView"),
              widget: CustomWebView(
                title: "Periodo: ${preevaluate.periodoInicio}",
                onWebViewCreated: (controler)async{
                  final html = "<!DOCTYPE html><html><head><meta charset='UTF-8'/><style> body{position:absolute;color: #242729;} #preevaluate{overflow: scroll;width: 1000px;height: auto;float: none;height: 600px;margin-left: auto;margin-top: 0px;clear: none;min-height: 50px;margin-right: auto;font-family: 'Courier New';font-size: 10px !important; font-weight: bold;}</style></head><body><div id='preevaluate'>${preevaluate.html}</div></body></html>";
                  final contentBase64 = await compute(base64Encode, const Utf8Encoder().convert(html));
                  controler.loadUrl('data:text/html;base64,$contentBase64');
                },
              )
            ));
          }
        ),
      ];

      final marcajes = preevaluate.marcajes.map((x)=>_MarcajeItemWidget(
        marcajeModel: x,
      )).toList();

      items.addAll(periodo);
      items.addAll(marcajes);
      if(marcajes.length >0) items.add(UiHelper.verticalSpaceXLarge);
    }

    return items;
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Consultando");

    return Consumer<IncidenciasViewModel>(
      child: Center(
        child: Text("Sin información"),
      ),
      builder: (ctx,viewModel, c)=>ListView(
        padding: UiHelper.listItemPadding,
        addAutomaticKeepAlives: true,
        cacheExtent: 30.0,
        children: <Widget>[
          _buildDateInput(viewModel),
          UiHelper.verticalSpaceSmall,
          ..._buildPreevaluate(viewModel)
        ],
      ),
    );
  }
}

class _MarcajeItemWidget extends StatelessWidget {
  final MarcajeModel marcajeModel;
  const _MarcajeItemWidget({Key key, this.marcajeModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    final detalle = <Widget>[];

    detalle.addAll([
      Padding(
        padding: UiHelper.listFirstInternalItemPadding,
        child: Text("Turno: ${marcajeModel.turno}"),
      ),
      Padding(
        padding: UiHelper.listInternalItemPadding,
        child: Text("Horario: ${marcajeModel.entrada} - ${marcajeModel.salida}"),
      ),
    ]);

    if(marcajeModel.entrada.trim() != "DESC" && marcajeModel.marcaje_1.isNotEmpty ){
      detalle.addAll([     
        Padding(
          padding: UiHelper.listInternalItemPadding,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text("Entrada: ${marcajeModel.marcaje_1}"),
              UiHelper.horizontalSpaceSmall,
              Text("Salida: ${marcajeModel.marcaje_2}")
            ],
          ),
        ),
      ]);
    }

    if(marcajeModel.incidencia.trim().isNotEmpty || marcajeModel.observacion.trim().isNotEmpty){
      detalle.add(
        Padding(
          padding: UiHelper.listLastInternalItemPadding,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text("Incidencia:"),
              UiHelper.horizontalSpaceSmall,
              Flexible(
                child: Text(marcajeModel.incidencia.trim().isNotEmpty ? marcajeModel.incidencia : marcajeModel.observacion)
              )
            ],
          )
        )
      );
    }

    return ListItemWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: UiHelper.listHeaderItemPaddingLarge,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                RichText(
                  textScaleFactor: 1.1,
                  text: TextSpan(
                    text: marcajeModel.dia,
                    style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    children: [
                      TextSpan(
                        text: " ${marcajeModel.fecha}",
                        style: TextStyle(color: Colors.black, fontWeight: FontWeight.normal),
                      )
                    ]
                  )
                ),
              ],
            ),
          ),
          ...detalle
        ],
      )
    );
  }
}