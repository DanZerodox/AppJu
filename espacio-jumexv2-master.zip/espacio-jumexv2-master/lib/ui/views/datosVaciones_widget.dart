import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/vacaciones_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/vacacionesView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DatosVacacionesWidget extends StatefulWidget {

  DatosVacacionesWidget({Key key}) :super(key: key);

  @override
  _DatosVacacionesWidgetState createState() => _DatosVacacionesWidgetState();
}

class _DatosVacacionesWidgetState extends State<DatosVacacionesWidget> {

  @override
  void initState() {
    
    Future.microtask((){
      final viewModel = Provider.of<VacacionesViewModel>(context);
      viewModel.consultaDatosVacaciones(Provider.of<UserModel>(context)).then((_){
        util.unathorized(context, viewModel.status,()=>null);
      });
    });

    super.initState();
  }

  Widget _buildVacaciones(InformacionVacacionesModel vacacionesModel){
    return Container(
      child: ListView(
        padding: UiHelper.listItemPadding,
        children: <Widget>[
          Card(
            child: Column(
              children: <Widget>[
                ListTile(
                  title: Text("Periodo ${vacacionesModel.periodo.periodoInicio == null ? "Proximo" : "" }"),
                  subtitle: vacacionesModel.periodo.periodoInicio != null || vacacionesModel.periodoProximo.periodoInicio != null ?
                  Text("Del ${vacacionesModel.periodo.periodoInicio ?? vacacionesModel.periodoProximo.periodoInicio ?? ""} al ${vacacionesModel.periodo.periodoFin ?? vacacionesModel.periodoProximo.periodoFin}"):
                  Text("--"),
                ),
                vacacionesModel.nombreJefe != null && vacacionesModel.nombreJefe.isNotEmpty ? ListTile(
                  title: Text("Jefe directo"),
                  subtitle: Text(vacacionesModel.nombreJefe)
                ) : SizedBox.shrink(),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: ListTile(
                        title: Text("Derecho"),
                        subtitle: Text("${vacacionesModel.derechoVacacional ?? "--"}"),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: Text("Liquidación"),
                        subtitle: Text("${vacacionesModel.liquidacionVacacional ?? "--"}"),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: ListTile(
                        title: Text("Saldo"),
                        subtitle: Text("${vacacionesModel.saldoVacacional ?? "--"}"),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: Text("Vencen"),
                        subtitle: Text("${vacacionesModel.periodo.vencimiento ?? vacacionesModel.periodoProximo.vencimiento ?? "--"}"),
                      ),
                    )
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {    
    return Consumer<VacacionesViewModel>(
      child: Center(
        child: Text("Sin información"),
      ),
      builder: (ctx,viewModel, c){
        return viewModel.status == Status.busy 
          ? UiHelper.progressIndicator 
            : viewModel.status == Status.error || viewModel.informacionVacaciones == null ? c  : _buildVacaciones(viewModel.informacionVacaciones);
      },
    );
  }
}