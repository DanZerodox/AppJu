import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/userView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/shared/theme.dart' as theme;
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/cachedImage_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class LoginView extends StatelessWidget {
  final String message;
  const LoginView({Key key, this.message}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseWidget<UserViewModel>(
      model: UserViewModel(
        userService: Provider.of(context),
        localdbService: Provider.of(context),
        firebaseMessagingService: Provider.of(context)
      ),
      onModelReady: (model) => model.fetchUser(),
      builder: (context, model, child) => model.status == Status.busy ? UiHelper.progressIndicator : LoginFormWidget(
        message: this.message, 
        usuario: model.userReqModel.userNumber,
        handlePassword: (value) => model.setReqPassword(value),
        handleUsuario: (value) => model.setReqUser(value),
      ),
    );
  }
}

class LoginFormWidget extends StatefulWidget {
  final String message;
  final String usuario;
  final ValueChanged<String> handleUsuario;
  final ValueChanged<String> handlePassword;

  LoginFormWidget({Key key, this.message, this.usuario, this.handleUsuario, this.handlePassword}) : super(key: key);
  
  @override
  _LoginFormWidgetState createState() => _LoginFormWidgetState();
}

class _LoginFormWidgetState extends State<LoginFormWidget> {

  final _scaffoldKey = GlobalKey<ScaffoldState>();
  static final _formKey = GlobalKey<FormState>();
  static final _userKey = GlobalKey<FormState>();
  static final _userPasswordKey = GlobalKey<FormState>();

  final _userPasswordNodeFocus = FocusNode();
  final _userFocusNode = FocusNode();

  TextEditingController _usuarioController;
  TextEditingController _passwordController;

  static const double _radius = 20.0;

  ProgressDialog _progressDialog;

  @override
  void initState() { 
    _usuarioController  = TextEditingController.fromValue(
      TextEditingValue(text: widget.usuario?.toString() ?? "")
    )..addListener((){
      widget.handleUsuario?.call(_usuarioController.text);
    });

    _passwordController = TextEditingController()
    ..addListener(() {
      widget.handlePassword?.call(_passwordController.text);
    });

    WidgetsBinding.instance
        .addPostFrameCallback((_){
          if(widget.message!= null && widget.message.isNotEmpty){
            util.showAlertPopup(context, "Error", widget.message);
          }
        });

    super.initState();
  }

  @override
  void dispose() { 
    _usuarioController?.dispose();
    _passwordController?.dispose();
    
    super.dispose();
  }

  Widget _buildForm(UserViewModel viewModel){
    final _styleTextField = const TextStyle(
      fontFamily: "Lucida",
      fontSize: 14.0
    );

    final _padingElements = const EdgeInsets.symmetric(
        horizontal: 40,
        vertical: 5
    );

    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: _padingElements,
            child: TextFormField(
              key: _userKey,
              autocorrect: false,
              controller: _usuarioController,
              style: _styleTextField,
              textInputAction: TextInputAction.next,
              focusNode: _userFocusNode,
              onFieldSubmitted: (value){
                _userFocusNode.unfocus();
                FocusScope.of(context).requestFocus(_userPasswordNodeFocus);
              },
              decoration: new InputDecoration(
                labelText: "Usuario",
                hintText: "Ingresa tu numero de empleado",
                contentPadding: const EdgeInsets.symmetric(vertical: 20),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [ FilteringTextInputFormatter.digitsOnly ],
              validator: (val)=> val.isEmpty ? 'Ingresar numero de empleado' : null,
            ),
          ),
          Padding(
            padding: _padingElements,
            child: TextFormField(
              key: _userPasswordKey,
              autocorrect: false,
              controller: _passwordController,
              validator: (val)=> val.isEmpty ? 'Ingresar password' : null,
              obscureText: true,
              style: _styleTextField,
              focusNode: _userPasswordNodeFocus,
              textInputAction: TextInputAction.done,
              onFieldSubmitted: (value){
                _userPasswordNodeFocus.unfocus();
                FocusScope.of(context).requestFocus(new FocusNode());
                _submitSignIn(viewModel);
              },
              decoration: InputDecoration(
                  labelText: "Contraseña",
                  hintText: "Ingresa tu contraseña",
                  contentPadding: const EdgeInsets.symmetric(vertical: 20),
              ),
            )
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 5
            ),
            child: CheckboxListTile(
              controlAffinity: ListTileControlAffinity.leading,
              dense: true,
              title: Text("Recordar sesión"),
              value: viewModel.userReqModel.rememberme == 1, 
              onChanged: (value){
                viewModel.setReqRememberMe(value);
              }
            )
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 5
            ),
            child: FlatButton(
              child: Text("Olvidé mi contraseña"),
              onPressed: (){
                Navigator.of(context).pushNamed(RoutePath.RestablecerContrasena,arguments: viewModel.userReqModel.userNumber);
              },
            )
          )
        ],
      ),
    );
  }

  Widget _buildButton(UserViewModel viewModel){
    return Container(
      height: 50.0,
      margin: EdgeInsets.symmetric(vertical: 15.0),
      child: RaisedButton(
        shape: new RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        padding: EdgeInsets.all(0.0),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: <Color>[
                Color(0xFF0D47A1),
                Color(0xFF1976D2),
                Color(0xFF42A5F5),
              ]
            ),
            borderRadius: BorderRadius.circular(30.0),
          ),
          child: Container(
            constraints: BoxConstraints(
              maxWidth: 300.0, minHeight: 50.0
            ),
            alignment: Alignment.center,
            child: Text("Ingresar",textScaleFactor: 1.3, style: TextStyle(fontWeight: FontWeight.bold),),
          ),
        ),
        onPressed: () async{
          FocusScope.of(context).requestFocus(new FocusNode());
          _submitSignIn(viewModel);
        },
      ),
    );
  }

  final _backgroundImage = Container(
    decoration: BoxDecoration(
      color: theme.primaryColor,
      borderRadius:  BorderRadius.only(
        bottomLeft: const Radius.circular(_radius),
        bottomRight: const Radius.circular(_radius),
      )
    ),
    height: 200,
    width: double.infinity,
    child: CachedImageWidget(
      url: "${ApiConstant.apiServer}/Content/img/app/login_background_01.png",
      placeholder: (_,__)=>UiHelper.verticalSpaceXSmall,
      imageBuider: (context,provider)=>ClipRRect(
        child:  Image(
          image: provider,
          fit: BoxFit.fill,
        ),
        borderRadius:  BorderRadius.only(
          bottomLeft: const Radius.circular(_radius),
          bottomRight: const Radius.circular(_radius),
        )
      ),
    ),
  );

  void _submitSignIn(UserViewModel viewModel) async{
    final form = _formKey.currentState;
    
    if (form.validate()) {
      form.save();

      await _progressDialog.show();
      var success = await viewModel.signIn();
      await _progressDialog.hide();

      if(success){
        if(viewModel.userModel.avisoLegal>0)
         Navigator.pushReplacementNamed(context, RoutePath.AvisoLegal);
        else 
         Navigator.pushReplacementNamed(context, RoutePath.Home);
      }else{
        util.showAlertPopup(context,"¡Atención!", viewModel.message);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    
    _progressDialog = util.progressDialogBuilder(context,"Validando");
    
    return Scaffold(
      key: _scaffoldKey,
      body: Consumer<UserViewModel>(
        child: _backgroundImage,
        builder: (context, viewModel, child)=>Container(
          child: Stack(
            children: <Widget>[
              child,
              Center(
                child: ListView(
                  children: <Widget>[
                    UiHelper.verticalSpaceXLarge,
                    Card(
                      margin: EdgeInsets.only( right: 20.0, left: 20.0, ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(_radius))
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Padding(padding: EdgeInsets.only(top: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Image.asset("assets/images/espaciojumex_login.png"),
                                SizedBox(width: 20.0,),
                                Text("Espacio Jumex",textScaleFactor: 1.5),
                              ],
                            ),
                          ),
                          _buildForm(viewModel),
                          _buildButton(viewModel)
                        ],
                      )
                    )
                  ],
                )
              )
            ],
          ) ,
        )
      )
    );
  }
}