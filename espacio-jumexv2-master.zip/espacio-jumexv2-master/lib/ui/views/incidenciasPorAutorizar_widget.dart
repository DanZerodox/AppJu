import 'package:espacio_jumex/core/models/incidencia_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class IncidenciasPorAutorizarWidget extends StatefulWidget {
  IncidenciasPorAutorizarWidget({Key key}) : super(key: key);

  @override
  _IncidenciasPorAutorizarWidgetState createState() => _IncidenciasPorAutorizarWidgetState();
}

class _IncidenciasPorAutorizarWidgetState extends State<IncidenciasPorAutorizarWidget> {
  final _formKey = GlobalKey<FormState>();
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();

  TextEditingController _comentariosController;
  ProgressDialog _progressDialog;
  String _comentarios = "Rechazado";

  @override
  void initState() {
    _comentariosController = TextEditingController.fromValue(TextEditingValue(text: _comentarios));

    _comentariosController.addListener(() {
      _comentarios = _comentariosController.text;
    });

    Future.microtask(() {
      final viewModel = Provider.of<IncidenciasViewModel>(context);
      viewModel.consultaIncidenciasPendientes(Provider.of<UserModel>(context), true).then((_) {
        util.unathorized(context, viewModel.status, () => null);
      });
    });

    super.initState();
  }

  @override
  void dispose() {
    _comentariosController.dispose();
    super.dispose();
  }

  final arrastrarWidget = Column(
    children: [Text("Arrastrar"), Icon(Icons.arrow_downward)],
  );

  void _approveSolicitud(IncidenciasViewModel viewModel, IncidenciaPendienteModel solicitud) async {
    var reject = await _showApproveDialog();

    if (!reject) return;

    final user = Provider.of<UserModel>(context, listen: false);
    _progressDialog = util.progressDialogBuilder(context, "Autorizando");

    await _progressDialog.show();
    final success = await viewModel.autorizarIncidencia(user, solicitud);
    await _progressDialog.hide();

    if (!success) {
      util.unathorized(context, viewModel.status, () => util.showAlertPopup(context, "¡Atención!", viewModel.message));
    }

    _refreshIndicatorKey.currentState.show();
  }

  void _refuseSolicitud(IncidenciasViewModel viewModel, IncidenciaPendienteModel solicitud) async {
    var reject = await _showRefuseDialog();

    if (!reject) return;

    final user = Provider.of<UserModel>(context, listen: false);
    _progressDialog = util.progressDialogBuilder(context, "Rechazando");

    await _progressDialog.show();
    final success = await viewModel.rechazarIncidencia(user, solicitud, _comentarios);
    await _progressDialog.hide();

    if (!success) {
      util.unathorized(context, viewModel.status, () => util.showAlertPopup(context, "¡Atención!", viewModel.message));
    }

    _refreshIndicatorKey.currentState.show();
  }

  Future<bool> _showRefuseDialog() async {
    return await showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return ClipRect(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(32.0))),
              title: Text("Escribe tus observaciones"),
              content: Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 5.0,
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: "Comentarios"),
                      minLines: 1,
                      maxLines: 2,
                      validator: (val) => val == null || val.isEmpty ? "Ingresar un mensaje" : null,
                      controller: _comentariosController,
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                FlatButton(
                  child: Text("Cerrar"),
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                ),
                FlatButton(
                  child: Text("Enviar"),
                  onPressed: () {
                    final formState = _formKey.currentState;
                    if (formState.validate()) {
                      formState.save();
                      Navigator.of(context).pop(true);
                    }
                  },
                )
              ],
            ),
          ]));
        });
  }

  Future<bool> _showApproveDialog() async {
    return await showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return ClipRect(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(32.0))),
              title: Text("Autorizar incidencia"),
              content: Text("La incidencia se autorizará."),
              actions: <Widget>[
                FlatButton(
                  child: Text("Cerrar"),
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                ),
                FlatButton(
                  child: Text("Aprobar"),
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                )
              ],
            ),
          ]));
        });
  }

  Widget _buildList(IncidenciasViewModel viewModel) {
    final tsolicitudes = viewModel.incidenciasPorAutorizar?.length ?? 0;

    return ListView.builder(
        padding: UiHelper.listItemPadding,
        physics: AlwaysScrollableScrollPhysics(),
        itemCount: tsolicitudes > 0 ? tsolicitudes : 1,
        itemBuilder: (context, index) {
          if (tsolicitudes == 0) {
            return arrastrarWidget;
          } else {
            final item = viewModel.incidenciasPorAutorizar[index];
            return ListItemWidget(
                child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                    flex: 3,
                    child: Padding(
                        padding: UiHelper.listItemPadding,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "${item.concepto}",
                              textScaleFactor: 1.1,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            UiHelper.verticalSpaceSmall,
                            Text("${item.nombre}"),
                            UiHelper.verticalSpaceSmall,
                            Text("De ${item.fechaInicio} a ${item.fechaFin}"),
                            UiHelper.verticalSpaceSmall,
                            item.horaInicio != null && item.horaInicio.isNotEmpty ? Text("Horario: ${item.horaInicio} a ${item.horaFin}") : Text("Cantidad: ${item.cantidad}"),
                            UiHelper.verticalSpaceSmall,
                            Text("Solicitado: ${item.fechaRegistro}"),
                            UiHelper.verticalSpaceSmall,
                            (item.observaciones ?? '') != '' ? UiHelper.verticalSpaceXSmall : SizedBox.shrink(),
                            (item.observaciones ?? '') != ''
                                ? Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [Text("Comentarios: "), Expanded(flex: 2, child: Text(item.observaciones))],
                                  )
                                : SizedBox.shrink(),
                          ],
                        ))),
                item.estatus == 'INIT'
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: Icon(Icons.check),
                            color: Colors.lightGreen[800],
                            onPressed: () {
                              _approveSolicitud(viewModel, item);
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.close),
                            color: Colors.red,
                            onPressed: () {
                              _refuseSolicitud(viewModel, item);
                            },
                          )
                        ],
                      )
                    : SizedBox.shrink()
              ],
            ));
          }
        });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<IncidenciasViewModel>(
      builder: (context, viewModel, child) {
        switch (viewModel.statusInciPendientes) {
          case Status.error:
            return Center(
              child: Text(viewModel.message),
            );
            break;
          default:
            return RefreshIndicator(
              onRefresh: () async {
                final result = await viewModel.consultaIncidenciasPendientes(Provider.of<UserModel>(context));
                util.unathorized(context, viewModel.status, () => null);
                return Future.value(() => result);
              },
              key: _refreshIndicatorKey,
              child: viewModel.statusInciPendientes == Status.busy && viewModel.initIncidencias ? UiHelper.progressIndicator : _buildList(viewModel),
            );
        }
      },
    );
  }
}
