import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/photoItem_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:espacio_jumex/ui/widgets/thumbnail_widget.dart';
import 'package:flutter/material.dart';

class YammerListItemWidget extends StatelessWidget {
  final YammerModel yammerModel;
  final VoidCallback onTap;
  const YammerListItemWidget({Key key, @required this.yammerModel, this.onTap}) : super(key: key);

  Widget _buildItem(BuildContext context) {
    return ListItemWidget(
      margin: EdgeInsets.only(top: 4),
      constraints: UiHelper.listItemConstraintsLarge.copyWith(minHeight: 140, maxHeight: 450),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          ListTile(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Expanded(
                    child: Container(
                  child: Text(
                    yammerModel.title ?? "--",
                    overflow: TextOverflow.ellipsis,
                  ),
                )),
                Text(
                  yammerModel.createdAt,
                  style: TextStyle(fontSize: 12.0, fontStyle: FontStyle.italic),
                ),
                Icon(Icons.expand_more)
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Flexible(
                    child: Container(
                  padding: UiHelper.listInternalItemPadding,
                  constraints: BoxConstraints(minHeight: 35, maxHeight: 450),
                  child: Text(
                    yammerModel.contentParsed,
                    overflow: TextOverflow.ellipsis,
                  ),
                )),
              ],
            ),
          ),
          UiHelper.verticalSpaceSmall,
          _buildImagesGrid(context, yammerModel),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: onTap ??
            () {
              Navigator.of(context).pushNamed(RoutePath.YammerDetail, arguments: yammerModel);
            },
        child: _buildItem(context));
  }
}

class YammerItemWidget extends StatelessWidget {
  final YammerModel yammerModel;

  const YammerItemWidget({Key key, @required this.yammerModel}) : super(key: key);

  Widget _buildItem(BuildContext context, YammerModel item) {
    return Padding(
        padding: EdgeInsets.only(top: 4),
        child: ListItemWidget(
          constraints: UiHelper.listItemConstraintsLarge.copyWith(minHeight: 140, maxHeight: double.infinity),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Expanded(
                        child: Container(
                      child: Text(
                        item.title ?? "--",
                        overflow: TextOverflow.ellipsis,
                      ),
                    )),
                    Text(
                      item.createdAt,
                      style: TextStyle(fontSize: 12.0, fontStyle: FontStyle.italic),
                    ),
                  ],
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Flexible(
                        child: Container(
                      padding: UiHelper.listInternalItemPadding,
                      constraints: BoxConstraints(minHeight: 35, maxHeight: double.infinity),
                      child: Text(item.contentParsed),
                    )),
                  ],
                ),
              ),
              UiHelper.verticalSpaceSmall,
              _buildImagesGrid(context, yammerModel),
            ],
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    final item = yammerModel;

    return _buildItem(context, item);
  }
}

Widget _buildImagesGrid(BuildContext context, YammerModel yammerModel) {
  final media = yammerModel.media;

  switch (media?.length ?? 0) {
    case 0:
      return UiHelper.verticalSpaceSmall;
      break;
    default:
      return ThumbnailWidget(
        items: yammerModel.media
            .map<PhotoItemModel<String>>((x) => PhotoItemModel<String>(
                id: x.id.toString(),
                url: x.type == MediaType.video ? x.urlContent : "${ApiConstant.apiEndpoint}/${x.urlContent}",
                thumbnail: "${ApiConstant.apiEndpoint}/${x.thumbnail}",
                type: x.type == MediaType.video ? MediaType.video2Factor : x.type,
                info: x.name))
            .toList(),
      );
  }
}
