import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/viewmodel/view/yammerView_model.dart';
import 'package:espacio_jumex/ui/views/avisoOportunoList_widget.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/bottomAppBar_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AvisoOportunoView extends StatefulWidget {
  final int index;
  AvisoOportunoView({Key key, this.index}) : super(key: key);

  @override
  _AvisoOportunoViewState createState() => _AvisoOportunoViewState();
}

class _AvisoOportunoViewState extends State<AvisoOportunoView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  
  PageController _pageController;
  int _index = 0;

  final _views = <Widget>[
    AvisoOportunoListWidget(key: PageStorageKey<String>("AvisoOportunoListWidget")),
    AvisoOportunoMyListWidget(key: PageStorageKey<String>("AvisoOportunoMyListWidget")),
  ];

  @override
  void initState() {
    _index = widget.index;
    _pageController = PageController(initialPage: _index);
    super.initState();
  }

  @override
  void dispose() { 
    _pageController.dispose();
    super.dispose();
  }

  void _changePage(int index){
     _pageController.animateToPage(index, duration: new Duration(milliseconds: 500),curve: Curves.easeInOut );
  }

  void _showMessage(String text){
    if(text!=null && text.isNotEmpty){
      _scaffoldKey.currentState.showSnackBar(new SnackBar(content: Text(text),duration: new Duration(seconds: 2),));
    }
  }

  @override
  Widget build(BuildContext context) {
    return BaseWidget<YammerViewModel>(
      model: YammerViewModel(yammerService: Provider.of(context),localdbService: Provider.of(context)),
      builder: (context,model,child)=>Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          title: Text("Aviso oportuno"),
          centerTitle: false,
        ),
        body: PageView(
          controller: _pageController,
          onPageChanged: (index){
            setState(() {
              _index = index;
            });
          },
          children: _views,
        ),
        floatingActionButton: _index == 0 || model.pendientes ? null : FloatingActionButton.extended(
          label: Text("Agregar"),
          icon: Icon(Icons.add),
          onPressed: (){
            Navigator.of(context).pushNamed(RoutePath.AvisoOportunoAdd)
              .then((value) async{
                _showMessage(value);
                model.subiendoAviso();
              });
          }
        ),
        bottomNavigationBar: BottomAppBarWidget(
          currentIndex: _index,
          onTap: (index){
            _changePage(index);
          },
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.list),
              label: "Avisos"
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.publish),
              label: "Publicar"
            )
          ]
        )
      ),
    );
  }
}