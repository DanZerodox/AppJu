import 'package:espacio_jumex/core/models/directorio_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class DirectorioRHWidget extends StatelessWidget {

  Widget _buildDirectorioList(List<DirectorioModel> data){
    return ListView.builder(
      itemCount: data.length,
      padding: UiHelper.listItemPadding,
      itemBuilder: (context, index) {
        return ExpansionTile(
          title: Text(data[index].name),
          initiallyExpanded: false,
          children: data[index].contacts.map((item)=>
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.0,vertical: 8.0),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(item.nombre,style: TextStyle(fontWeight: FontWeight.bold),),
                          Container(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text("Area: ",style: TextStyle(fontWeight: FontWeight.bold),),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(item.area),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                          Row(
                            children: <Widget>[
                              Text("Extensión: ",style: TextStyle(fontWeight: FontWeight.bold),),
                              Text(item.extension),
                            ],
                          ),
                          Container(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text("E-Mail: ",style: TextStyle(fontWeight: FontWeight.bold),),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(item.email)
                                    ],
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                )
              )
          ).toList(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BaseWidget<NominaViewModel>(
      model: NominaViewModel(nominaService: Provider.of(context),localdbService: Provider.of(context)),
      onModelReady: (model){
        model.consultaDirectorioRH(Provider.of<UserModel>(context)).then((_){
          util.unathorized(context, model.status,()=>null);
        });
      },
      builder: (context,model,child){
        if(model.status == Status.busy){
          return UiHelper.progressIndicator;
        }else{
          if(model.directorio == null || model.directorio.length == 0){
            return Center(
              child: Text(model.message ?? "No hay información"),
            );
          }else{
            return _buildDirectorioList(model.directorio);
          }
        }
      },
    );
  }
}