import 'dart:convert';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/ui/views/customWeb_view.dart';
import 'package:espacio_jumex/ui/widgets/dateTime_formfield.dart';
import 'package:flutter/foundation.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/reciboDetalle_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

/// ReciboView
/// Clase StatefulWidget/View para mostrar el detalle de recibo de nómina
class ReciboView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ReciboState();
}

class _ReciboState extends State<ReciboView> {
  final _keyForm = GlobalKey<FormState>();

  final _tipoPagoList = [
    new DropdownMenuItem(
      child: new Text("Selecciona un recibo"),
      value: "--",
    ),
    new DropdownMenuItem(
      child: new Text("Nomina"),
      value: "",
    ),
    new DropdownMenuItem(
      child: new Text("Aguinaldo"),
      value: "a",
    ),
    new DropdownMenuItem(
      child: new Text("Bono"),
      value: "b",
    ),
    new DropdownMenuItem(
      child: new Text("Fondo de ahorro"),
      value: "f",
    ),
    new DropdownMenuItem(
      child: new Text("PTU"),
      value: "p",
    ),
  ];

  ProgressDialog _progressDialog;
  DateTime _selectedDate;
  String _tipoRecibo = '--';

  @override
  void dispose() {
    super.dispose();
  }

  Widget _buildForm(NominaViewModel viewModel) {
    return Card(
        child: Form(
      key: _keyForm,
      child: Column(
        children: <Widget>[
          Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: FormField<String>(
              validator: (val) => val == '--' ? "Selecciona una opción" : null,
              builder: (state) => new DropdownButton(
                isExpanded: true,
                value: _tipoRecibo,
                items: _tipoPagoList,
                onChanged: (value) {
                  state.didChange(value);
                  setState(() => _tipoRecibo = value);
                  if (_tipoRecibo != '' && _tipoRecibo != '--') _submit(viewModel);
                },
              ),
            ),
          ),
          _tipoRecibo == ''
              ? Padding(
                  padding: UiHelper.compactFormItemsPadding,
                  child: DateTimeFormField(
                    dateFormat: viewModel.dateFormatter,
                    label: "Ingresar fecha",
                    validator: (value) => value == null ? "Indicar una fecha válida" : null,
                    firstDate: DateTime(DateTime.now().year - 1),
                    lastDate: DateTime.now().add(Duration(days: 1)),
                    initialValue: _selectedDate,
                    onDateSelected: (value) {
                      _selectedDate = value;
                      _submit(viewModel);
                    },
                    decoration: InputDecoration(suffixIcon: Icon(Icons.calendar_today), labelText: "Fecha"),
                  ),
                )
              : SizedBox.shrink(),
        ],
      ),
    ));
  }

  void _submit(NominaViewModel viewModel) async {
    final state = _keyForm.currentState;
    if (state.validate()) {
      await _progressDialog.show();
      final success = await viewModel.consultaRecibo(Provider.of<UserModel>(context), _tipoRecibo, _selectedDate);
      await _progressDialog.hide();

      if (!success) {
        util.unathorized(context, viewModel.status, () => util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }
    }
  }

  List<Widget> _buidRecibo(NominaViewModel viewModel) {
    final recibo = viewModel.recibo;

    if (recibo == null) {
      return [UiHelper.verticalSpaceXSmall];
    }

    return <Widget>[
      Text(
        "Periodo: Del ${recibo.periodoPago2} al ${recibo.periodoPago3}",
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      UiHelper.verticalSpaceSmall,
      RaisedButton(
          child: Text("Ver texto"),
          onPressed: () async {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => CustomWebView(
                      title: "Periodo: ${recibo.periodoPago}",
                      onWebViewCreated: (controler) async {
                        final html =
                            "<!DOCTYPE html><html><head><meta charset='UTF-8'/><style> body{position:absolute;color: #242729;} #preevaluate{overflow: scroll;width: 1000px;height: auto;float: none;height: 600px;margin-left: auto;margin-top: 0px;clear: none;min-height: 50px;margin-right: auto;font-family: 'Courier New';font-size: 10px !important; font-weight: bold;}</style></head><body><div id='preevaluate'>${recibo.html}</div></body></html>";
                        final contentBase64 = await compute(base64Encode, const Utf8Encoder().convert(html));
                        controler.loadUrl('data:text/html;base64,$contentBase64');
                      },
                    )));
          }),
      UiHelper.verticalSpaceSmall,
      ReciboDetalleWidget(reciboModel: recibo),
    ];
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Consultando");

    return BaseWidget<NominaViewModel>(
      model: NominaViewModel(nominaService: Provider.of(context), localdbService: Provider.of(context)),
      builder: (context, model, child) => Scaffold(
          appBar: new AppBar(
            centerTitle: false,
            title: new Text("Recibo"),
          ),
          body: ListView(
            padding: UiHelper.listItemPadding,
            physics: ClampingScrollPhysics(),
            children: <Widget>[_buildForm(model), UiHelper.verticalSpaceSmall, ..._buidRecibo(model)],
          )),
    );
  }
}
