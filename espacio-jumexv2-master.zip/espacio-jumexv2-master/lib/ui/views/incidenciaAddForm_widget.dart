import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/dateTime_formfield.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class IncidenciaAddFormWidget extends StatefulWidget {
  IncidenciaAddFormWidget({Key key}) : super(key: key);

  @override
  _IncidenciaAddFormWidgetState createState() => _IncidenciaAddFormWidgetState();
}

class _IncidenciaAddFormWidgetState extends State<IncidenciaAddFormWidget> {
  final _formKey = GlobalKey<FormState>();

  ProgressDialog _progressDialog;

  Widget _buildForm(IncidenciasViewModel viewModel){
    final incidencia = viewModel.incidencia;
    final inputs = <Widget>[];

    if(incidencia.capturarHoras!= 0){

      final horaInicioInput = Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: DateTimeFormField(
          mode: DateFieldPickerMode.time,
          dateFormat: viewModel.hourFormat,
          label: "De",
          initialValue: viewModel.horaInicio?.add(Duration(hours: 1)),
          validator: (value) => viewModel.incidencia.capturarHoras >0 && value == null ? "Favor de indicar una hora" : null,
          onDateSelected: viewModel.setHoraInicio,
          decoration: InputDecoration(
            suffixIcon: Icon(Icons.calendar_today),
            labelText: "Hora inicio"
          ),
        )
      );

      inputs.add(horaInicioInput);

      if(viewModel.horaInicio != null){
        inputs.add(Padding(
          padding: UiHelper.compactFormItemsPadding,
          child: DateTimeFormField(
            mode: DateFieldPickerMode.time,
            dateFormat: viewModel.hourFormat,
            label: "A",
            initialValue: viewModel.horaFin,
            validator: (value) => viewModel.incidencia.capturarHoras >0 && value == null ? "Favor de indicar una hora" : null,
            onDateSelected: viewModel.setHoraFin,
            decoration: InputDecoration(
              suffixIcon: Icon(Icons.calendar_today),
              labelText: "Hora termino"
            ),
          )
        ));
      }
    }

    inputs.addAll([
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: TextFormField(
          //controller: _observacionesController,
          initialValue: viewModel.comentarios,
          onChanged: viewModel.setComentarios,
          maxLines: null,
          keyboardType: TextInputType.multiline,
          decoration: InputDecoration(
              labelText: 'Agrega aquí tus comentarios',
              hintText: 'Comentarios',
          )
        ),
      ),
      UiHelper.verticalSpaceMedium,
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: Text("Para los días:"),
      ),
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: viewModel.fechasIncidencia.map((e) => Container(
            margin: EdgeInsets.only(top: 5.0),
            child: Text("${e.fecha} (${e.dia})")
          )).toList(),
        ),
      ),

      Container(
        margin: EdgeInsets.symmetric(vertical: 25.0),
        child: Center(
          child: SubmitButtonWidget(
            title: "Enviar",
            onSubmit: (){
              _submit(viewModel);
            },
          )
        ),
      )
    ]);

    final form = Container(
      margin: UiHelper.formItemsMargin,
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: inputs,
        )
      ),
    );

    return form;
  }

  void _submit(IncidenciasViewModel viewModel) async{
    
    FocusScope.of(context).requestFocus(FocusNode());
    final state = _formKey.currentState;

    if(state.validate()){
      await _progressDialog.show();
      final success = await viewModel.agregarIncidencia(Provider.of<UserModel>(context));
      await _progressDialog.hide();

      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop(viewModel.message);
      }
    }

  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Enviado");

    return Consumer<IncidenciasViewModel>(
      builder: (context, viewModel, child) => ListView(
        padding: UiHelper.listItemPadding,
        children: <Widget>[
          Card(
            child: Column(
              children: <Widget>[
                _buildForm(viewModel),
              ],
            ),
          ),
        ],
      ),
    );
  }
}