import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/yammerItem_widget.dart';
import 'package:flutter/material.dart';

class YammerItemView extends StatelessWidget {
  final YammerModel yammerModel;
  const YammerItemView({Key key,this.yammerModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Yammer"),
        centerTitle: false,
      ),
      body: ListView(
        padding: UiHelper.listItemPadding,
        children: <Widget>[
          YammerItemWidget(
            yammerModel: yammerModel,
          )
        ],
      )
    );
  }
}