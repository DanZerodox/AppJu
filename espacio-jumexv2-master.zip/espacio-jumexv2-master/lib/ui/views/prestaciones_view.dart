import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/ui/views/prestaciones_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BienvenidaView extends StatelessWidget {
  const BienvenidaView({Key key}) : super(key: key);

  static final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final acceso = Provider.of<AccesosModel>(context).accesos.firstWhere((x)=>x.rutaAcceso == RoutePath.Bienvenida);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Bienvenida"),
        centerTitle: false,
      ),
      body: PrestacionesWidget(
        yammerId: YammerConstant.yammerBienvenidaId,
        accesoModel: acceso,
      )
    );
  }
}

class NormatividadView extends StatelessWidget {
  const NormatividadView({Key key}) : super(key: key);

  static final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final acceso = Provider.of<AccesosModel>(context).accesos.firstWhere((x)=>x.rutaAcceso == RoutePath.Normatividad);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Normatividad"),
        centerTitle: false,
      ),
      body: PrestacionesWidget(
        yammerId: YammerConstant.yammerNormatividadId,
        accesoModel: acceso,
      )
    );
  }
}

class VacantesView extends StatelessWidget {
  const VacantesView({Key key}) : super(key: key);

  static final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final acceso = Provider.of<AccesosModel>(context).accesos.firstWhere((x)=>x.rutaAcceso == RoutePath.Vacantes);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Vacantes"),
        centerTitle: false,
      ),
      body: PrestacionesWidget(
        yammerId: YammerConstant.yammerVacantesId,
        accesoModel: acceso,
      )
    );
  }
}

class BeneficiosView extends StatelessWidget {
  const BeneficiosView({Key key}) : super(key: key);

  static final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final acceso = Provider.of<AccesosModel>(context).accesos.firstWhere((x)=>x.rutaAcceso == RoutePath.Beneficios);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Beneficios"),
        centerTitle: false,
      ),
      body: PrestacionesWidget(
        yammerId: YammerConstant.yammerBeneficiosId,
        accesoModel: acceso,
      )
    );
  }
}

class NoticiasView extends StatelessWidget {
  static final _scaffoldKey = GlobalKey<ScaffoldState>();

  const NoticiasView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final acceso = Provider.of<AccesosModel>(context).accesos.firstWhere((x)=>x.rutaAcceso == RoutePath.Noticias);
    
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Noticias"),
        centerTitle: false,
      ),
      body: PrestacionesWidget(
        yammerId: YammerConstant.yammerNoticiasId,
        accesoModel: acceso,
      ),
    ); 
  }
}