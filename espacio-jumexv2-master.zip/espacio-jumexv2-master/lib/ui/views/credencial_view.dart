import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CredencialView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => CredencialState();
}

class CredencialState extends State<CredencialView> {
  final _scaffoldKey = new GlobalKey<ScaffoldState>();
  final _refreshIndicatorKey = new GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) => _refreshIndicatorKey.currentState.show());
    super.initState();
  }

  void _showMessage(String text) {
    if (text != null && text.isNotEmpty)
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
        content: Text(text),
        duration: new Duration(seconds: 2),
      ));
  }

  Widget _buildSolicitudes(NominaViewModel viewModel) {
    return RefreshIndicator(
      key: _refreshIndicatorKey,
      onRefresh: () async {
        final response = await viewModel.consultaSolicitudesCredencial(Provider.of<UserModel>(context));
        util.unathorized(context, viewModel.status, () => null);
        return Future.value(() => response);
      },
      child: ListView.builder(
          itemCount: viewModel.solicitudCredenciales != null ? viewModel.solicitudCredenciales.length : 0,
          padding: UiHelper.listItemPadding,
          itemBuilder: (ctx, index) => Card(
                child: viewModel.status == Status.error
                    ? new Center(
                        child: Text(viewModel.message),
                      )
                    : ExpansionTile(
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            new Text(viewModel.solicitudCredenciales[index].motivo),
                            new Text(
                              viewModel.solicitudCredenciales[index].fechaSolicitud,
                              textScaleFactor: 0.8,
                            )
                          ],
                        ),
                        children: <Widget>[
                          ListTile(title: new Text("Estatus: ${viewModel.solicitudCredenciales[index].estatus}")),
                          ListTile(title: new Text("Fecha de entrega: ${viewModel.solicitudCredenciales[index].fechaEntrega}")),
                        ],
                      ),
              )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BaseWidget<NominaViewModel>(
      model: NominaViewModel(nominaService: Provider.of(context)),
      builder: (context, model, child) => Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          title: Text("Solicitudes de credencial"),
          centerTitle: false,
        ),
        body: _buildSolicitudes(model),
        floatingActionButton: FloatingActionButton.extended(
          elevation: 10.0,
          label: Text("Solicitud"),
          icon: Icon(Icons.add),
          onPressed: () => Navigator.of(context).pushNamed(RoutePath.CredencialAdd).then((value) {
            _showMessage(value);
            _refreshIndicatorKey.currentState.show();
          }),
        ),
      ),
    );
  }
}
