import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class FAQSWidget extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return BaseWidget<NominaViewModel>(
      onModelReady: (model){
        model.consultaPreguntasFrecuentes(Provider.of<UserModel>(context))
        .then((_){
          util.unathorized(context, model.status,()=>null);
        });
      },
      model: NominaViewModel(nominaService: Provider.of(context), localdbService: Provider.of(context)),
      builder: (context,model,child){
        if(model.status == Status.busy){
          return UiHelper.progressIndicator;
        }else{
          if(model.faqs == null || model.faqs.length == 0){
            return Center(
              child: Text(model.message ?? "No hay información"),
            );
          }else{
            final data = model.faqs;

            return ListView.builder(
              padding: EdgeInsets.all(8.0),
              shrinkWrap: true,
              itemCount: data.length,
              itemBuilder: (conext,index){
                return InkWell(
                    child: ListTile(
                      title: Text(data[index].pregunta),
                    ),
                    onTap: () => Navigator.pushNamed(context, RoutePath.FAQ, arguments: data[index])
                );
              }
            );
          }
        }
      },
    );
  }
}