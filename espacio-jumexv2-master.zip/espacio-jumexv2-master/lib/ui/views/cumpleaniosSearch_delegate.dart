// ignore: unused_import
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/selectableItem.dart';
import 'package:espacio_jumex/ui/views/cumpleaniosItem_widget.dart';
import 'package:flutter/material.dart';

class CumpleaniosSearchDelegate extends SearchDelegate<String> {
  
  final List<SelectableItem<ColaboradorModel>> _list;
  final ValueChanged<SelectableItem> onSelectItem;
  List<ColaboradorModel> _recent = [];

  CumpleaniosSearchDelegate({List<SelectableItem<ColaboradorModel>> list,this.onSelectItem}): 
  _list = list{
    _recent = list.where((e) => !e.isSelected).map((x)=>x.item).toList();
  }

  @override
  List<Widget> buildActions(BuildContext context) {
    final actions =<Widget>[
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: (){
          query = "";
          showSuggestions(context);
        }
      )
    ];

    return actions;
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: (){
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final results = _list.where((x)=>x.item.nombre.toLowerCase().startsWith(query.toLowerCase())).toList();

    return Container(
      color: Colors.white,
      child: ListView.builder(
        itemCount: results.length,
        itemBuilder: (context,index){
          var item = results[index].item;

           return Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: CumpleaniosItemWidget(
              fecha: item.fecha,
              localidad: item.localidad,
              nombre: item.nombre,
              hasMobile: item.hasMobile,
              onTap: ()=>close(context,item.nombre)
            )
          );
        }
      )
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final suggestions = query.isEmpty ? 
      _recent 
      : _list.where((x)=>x.item.nombre.toLowerCase().startsWith(query.toLowerCase()))
        .map((x)=>x.item)
        .toList();

    return ListView.builder(
      itemCount: suggestions.length,
      itemBuilder: (context,index)=>ListTile(
        title: RichText(
          text: TextSpan(
            text: suggestions[index].nombre.substring(0,query.length),
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            children: [
              TextSpan(
                text: suggestions[index].nombre.substring(query.length),
                style: TextStyle(color: Colors.grey),
              )
            ]
          ),
        ),
        onTap: ()=>close(context,suggestions[index].nombre),
      ),
    );
  } 
}