import 'package:espacio_jumex/core/models/pdfView_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/resourceView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:native_pdf_view/native_pdf_view.dart';
import 'package:provider/provider.dart';

class PdfViewerView extends StatefulWidget {
  final PdfViewModel pdf;

  PdfViewerView({Key key, this.pdf}) : super(key: key);

  @override
  _PdfViewerViewState createState() => _PdfViewerViewState();
}

class _PdfViewerViewState extends State<PdfViewerView> {
  PdfController _pdfController;
  int _currentPageNumber = 1;
  int _allPagesCount = 0;

   @override
  void initState() { 
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp
    ]);

    super.initState();
  }

  @override
  void dispose() { 
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight
    ]);
    
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        centerTitle: false,
        title: Text(widget.pdf.title),
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: (){
            Navigator.of(context).pop();
          },
        ),
        actions: _allPagesCount == 0 ? null : <Widget>[
          IconButton(
            icon: Icon(Icons.navigate_before),
            onPressed: () {
              _pdfController.previousPage(
                curve: Curves.ease,
                duration: Duration(milliseconds: 100),
              );
            },
          ),
          Container(
            alignment: Alignment.center,
            child: Text(
              '$_currentPageNumber/$_allPagesCount',
              style: TextStyle(fontSize: 22, color: Colors.white),
            ),
          ),
          IconButton(
            icon: Icon(Icons.navigate_next),
            onPressed: () {
              _pdfController.nextPage(
                curve: Curves.ease,
                duration: Duration(milliseconds: 100),
              );
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(color: Colors.blueGrey[200]),
        child: new PdfViewerWidget(widget.pdf.url,
          onDocumentLoaded: (d){
            setState(() {
              _allPagesCount = d.pagesCount;
            });
          },
          onPageChanged: (i){
            setState(() {
              _currentPageNumber = i;
            });
          },
          controller: (c)=>_pdfController = c,
        ),
      ),
    );
  }
}


class PdfViewerWidget extends StatefulWidget {
  final String url;
  final ValueChanged<PdfDocument> onDocumentLoaded;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<PdfController> controller;

  PdfViewerWidget(this.url,{Key key,this.onDocumentLoaded,this.controller, this.onPageChanged}) : super(key: key);

  @override
  _PdfViewerWidgetState createState() => _PdfViewerWidgetState();
}

class _PdfViewerWidgetState extends State<PdfViewerWidget> {

  Widget _buildBody(ResourceViewModel viewModel){
    switch (viewModel.status) {
      case Status.busy:
        return UiHelper.progressIndicator;
        break;
      case Status.free:
        return PdfViewerWrapperWidget(
          viewModel.pathFile,
          onDocumentLoaded: widget.onDocumentLoaded ,
          onPageChanged: widget.onPageChanged,
          controller: widget.controller,
        );
        break;
      default:
        return Text(viewModel.message);
    }
  }

  @override
  Widget build(BuildContext context) {

    return BaseWidget<ResourceViewModel>(
      model: ResourceViewModel(resourceService: Provider.of(context), customCacheManager: Provider.of(context)),
      onModelReady: (model){
        model.consultarRecursoPdf(Provider.of<UserModel>(context),widget.url)
        .then((value){
          util.unathorized(context, model.status,()=>null);
        });
      },
      builder: (context,model,child)=> _buildBody(model),
    );
  }
}

class PdfViewerWrapperWidget extends StatefulWidget {
  final String pathPdf;
  final void Function(PdfDocument) onDocumentLoaded;
  final void Function(PdfController) controller;
  final void Function(int) onPageChanged;

  PdfViewerWrapperWidget(this.pathPdf,{Key key,@required this.onDocumentLoaded, this.controller, @required this.onPageChanged}) : super(key: key);

  @override
  _PdfViewerWrapperWidgetState createState() => _PdfViewerWrapperWidgetState();
}

class _PdfViewerWrapperWidgetState extends State<PdfViewerWrapperWidget>{
  PdfController _controller;

  @override
  void initState() {
    _controller = PdfController(
      document: PdfDocument.openFile(widget.pathPdf)
    );

    widget.controller?.call(_controller);

    super.initState();
  }

  @override
  void dispose() { 
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final style = const TextStyle(color: Colors.white70,);

    return PdfView(
      documentLoader: new Center(child: new Text("Mostrando documento, disculpe la demora...", style: style,)),
      pageLoader: new Center(child: new Text("Cargando página...", style: style),),
      controller: _controller,
      onDocumentLoaded: widget.onDocumentLoaded,
      onPageChanged: widget.onPageChanged
    );
  }
}