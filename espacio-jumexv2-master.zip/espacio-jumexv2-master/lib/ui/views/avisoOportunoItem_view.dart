import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/yammerView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/yammerItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart' as launcher;

class AvisoOportunoItemView extends StatefulWidget {
  final YammerModel yammerModel;
  final bool contact;
  const AvisoOportunoItemView({Key key, this.yammerModel, this.contact = true})
      : super(key: key);

  @override
  _AvisoOportunoItemViewState createState() => _AvisoOportunoItemViewState();
}

class _AvisoOportunoItemViewState extends State<AvisoOportunoItemView> {
  bool _showActionButton = true;

  Widget _buildBody(YammerViewModel model) {
    if (model.status == Status.busy)
      return UiHelper.progressIndicator;
    else if (model.status == Status.error)
      return new Center(
        child: new Text(model.message),
      );
    else {
      return ListView(
        padding: UiHelper.listItemPadding,
        children: <Widget>[
          YammerItemWidget(
            yammerModel: model.aviso,
          )
        ],
      );
    }
  }

  void _setActionButton(bool value) {
    setState(() {
      _showActionButton = value;
    });
  }

  void _openUrlString(String urlString) async {
    if (await launcher.canLaunch(urlString)) {
      await launcher.launch(urlString);
    } else {
      util.showAlertPopup(
          context, "¡Alerta!", 'No fué posible abrir la aplicación');
    }
  }

  @override
  Widget build(BuildContext context) {
    var user = Provider.of<UserModel>(context);

    return BaseWidget<YammerViewModel>(
      model: new YammerViewModel(
          yammerService: Provider.of(context),
          localdbService: Provider.of(context)),
      onModelReady: (model) {
        model
            .consultaMiPublicacion(
                Provider.of<UserModel>(context), widget.yammerModel.id)
            .then((_) {
          util.unathorized(context, model.status, () => null);
        });
      },
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          title: Text("Yammer"),
          centerTitle: false,
        ),
        body: _buildBody(model),
        floatingActionButton: model.aviso?.usuario == user.usuario ||
                !widget.contact ||
                !_showActionButton ||
                model.aviso == null
            ? null
            : Builder(
                builder: (context) => new FloatingActionButton(
                    child: Icon(Icons.message),
                    onPressed: () {
                      var encodedTitle =
                          Uri.encodeComponent('${model.aviso.title}');
                      var encodedText = Uri.encodeComponent(
                          '¿${model.aviso.title} todavía está disponible?');

                      var showBottomSheetController = showBottomSheet(
                          context: context,
                          builder: (context) => Container(
                                height: 100.0,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(15)),
                                    boxShadow: [
                                      BoxShadow(
                                          blurRadius: 10,
                                          color: Colors.grey[300],
                                          spreadRadius: 5)
                                    ]),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    FlatButton(
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                        //_openUrlString("whatsapp://send?phone=${model.aviso.telefono}&text=$encodedText");
                                        //_openUrlString("https://wa.me/${model.aviso.telefono}?text=$encodedText");
                                        _openUrlString(model.aviso.telefono);
                                      },
                                      child: Row(
                                        children: <Widget>[
                                          Icon(Icons.phone),
                                          Text("Llamar")
                                        ],
                                      )
                                    ),
                                    FlatButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                          _openUrlString("${model.aviso.correo}?subject=$encodedTitle&body=$encodedText");
                                        },
                                        child: Row(
                                          children: <Widget>[
                                            Icon(Icons.alternate_email),
                                            Text("Enviar correo")
                                          ],
                                        )),
                                  ],
                                ),
                              ));

                      _setActionButton(false);

                      showBottomSheetController.closed.then((value) {
                        _setActionButton(true);
                      });
                    })),
      ),
    );
  }
}
