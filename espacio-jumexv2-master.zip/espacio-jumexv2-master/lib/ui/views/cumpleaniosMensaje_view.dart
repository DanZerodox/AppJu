import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/userView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class CumpleaniosMensajeView extends StatefulWidget {
  final List<ColaboradorModel> colaboradores;
  CumpleaniosMensajeView({Key key,this.colaboradores}) : super(key: key);

  @override
  _CumpleaniosMensajeViewState createState() => _CumpleaniosMensajeViewState();
}

class _CumpleaniosMensajeViewState extends State<CumpleaniosMensajeView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  final _mensajeController = new TextEditingController.fromValue(TextEditingValue(text: "¡Feliz cumpleaños!"));
  
  ProgressDialog _progressDialog;

  @override
  void dispose() { 
    _mensajeController.dispose();
    super.dispose();
  }

  Widget _buildForm(UserViewModel viewModel){

    final form = Container(
      margin: EdgeInsets.only(top: 12.0),
      child: Center(
        child: Column(
          children: <Widget>[
            Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  SizedBox(
                    height: 5.0,
                  ),
                  Padding(
                    padding: UiHelper.formItemsPadding,
                    child: TextFormField(
                      decoration: InputDecoration(
                        labelText: "Mensaje"
                      ),
                      minLines: 1,
                      maxLines: 2,
                      validator: (val)=> val== null || val.isEmpty ? "Ingresar un mensaje" : null,
                      controller: _mensajeController,
                    ),
                  )
                ],
              ),      
            )
          ],
        ),
      )
    );

    return form;
  }

  Widget _buildSubmitButton(UserViewModel viewModel){
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Felicitar",
        onSubmit: (){
          _onSubmit(viewModel);
        },
      ),
    );
  }

  void _onSubmit(UserViewModel viewModel) async{
    final formState = _formKey.currentState;
    if(formState.validate()){
      formState.save();
      final userModel = Provider.of<UserModel>(context,listen: false);
      
      await _progressDialog.show();
      final success = await viewModel.enviarFelicitacionesCumpleanios(userModel,_mensajeController.text,widget.colaboradores);
      await _progressDialog.hide();

      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop(viewModel.message);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Enviando");

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        centerTitle: false,
        title: Text("Enviar felicitación"),
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: (){
            Navigator.of(context).pop(null);
          },
        ),
      ),
      body: BaseWidget<UserViewModel>(
        model: UserViewModel(userService: Provider.of(context)),
        builder: (context, model, child)=>Container(
          child: ListView(
            padding: UiHelper.listItemPadding,
            children: <Widget>[
              Card(
                child: Column(
                  children: <Widget>[
                    _buildForm(model),
                    UiHelper.verticalSpaceSmall,
                    widget.colaboradores.every((e) => e.hasMobile == 2) ? SizedBox() :  
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 30),
                        child: Text("Algunos colaboradores no tienen la aplicación de Espacio Jumex instalada, posiblemente no reciban este mensaje.", textScaleFactor: 0.7,),
                      ),
                    _buildSubmitButton(model),
                  ],
                ),
              )
            ],
          ),
        ),
      )
    );
  }
}