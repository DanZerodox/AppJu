import 'dart:io';
import 'package:dotted_border/dotted_border.dart';
import 'package:espacio_jumex/core/models/request/avisoOportunoReq_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/application_service.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/yammerView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class AvisoOportunoAddView extends StatefulWidget {
  AvisoOportunoAddView({Key key}) : super(key: key);

  @override
  _AvisoOportunoAddViewState createState() => _AvisoOportunoAddViewState();
}

class _AvisoOportunoAddViewState extends State<AvisoOportunoAddView> {
  final _formKey = new GlobalKey<FormState>();

  final _titleController = new TextEditingController();
  final _descripcionController = new TextEditingController();
  final _telefonoController = new TextEditingController();
  final _correoController = new TextEditingController();

  final _titleNode = FocusNode();
  final _telefonoNode = FocusNode();
  final _correoNode = FocusNode();
  final _descripcionNode = FocusNode();

  final maxImages = 4;
  final List<PickedFile> images = <PickedFile>[];

  ProgressDialog _progressDialog;
  AvisoOportunoReqModel _avisoOportunoReq = AvisoOportunoReqModel();
  bool _permissions = false;
  ApplicationService _applicationService;

  String _codigoPais = "52";

  @override
  void initState() {
    Future.microtask(() async {
      final user = Provider.of<UserModel>(context);
      _correoController.text = user.correo;
      _avisoOportunoReq.correo = user.correo;
      _avisoOportunoReq.codigoPais = _codigoPais;

      _applicationService = Provider.of<ApplicationService>(context);
      final permissions = await _applicationService.checkPermission();
      setState(() {
        _permissions = permissions;
        print("$_permissions");
      });
    });

    _titleController.addListener(() => _avisoOportunoReq = _avisoOportunoReq.copyWith(titulo: _titleController.text));
    _descripcionController.addListener(() => _avisoOportunoReq.descripcion = _descripcionController.text);
    _telefonoController.addListener(() => _avisoOportunoReq.telefono = "${_telefonoController.text}");
    _correoController.addListener(() => _avisoOportunoReq.correo = _correoController.text);

    super.initState();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descripcionController.dispose();
    _telefonoController.dispose();
    _correoController.dispose();

    super.dispose();
  }

  Widget _buildUpdateImage(YammerViewModel viewModel) {
    final sWidth = MediaQuery.of(context).size.width;

    final button = _ButtonAddFoto(addFoto: (file) {
      if (file != null) {
        setState(() {
          images.add(file);
        });
      }
    });

    final width = images.length == 0 ? sWidth - 40.0 : sWidth * 0.36;

    return Column(
      children: <Widget>[
        Container(
            height: 180,
            // color: Colors.blue,
            margin: EdgeInsets.symmetric(horizontal: 5.0),
            child: ListView.builder(
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemCount: images.length < maxImages ? images.length + 1 : images.length,
                itemBuilder: (context, index) => AnimatedContainer(
                      duration: Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      //color: Colors.amber,
                      constraints: BoxConstraints(maxWidth: width),
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      child: (images.length > 0 && index < images.length) || (index == 0 && images.length == 1)
                          ? _FotoWidget(
                              file: images[index],
                              removeFoto: () {
                                setState(() {
                                  images.removeAt(index);
                                });
                              },
                            )
                          : button,
                    ))),
        UiHelper.verticalSpaceSmall,
        Padding(
          padding: UiHelper.compactFormItemsPadding,
          child: Text("Fotos ${images.length}/4"),
        )
      ],
    );
  }

  Widget _buildForm(YammerViewModel viewModel) {
    return Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            Padding(
              padding: UiHelper.compactFormItemsPadding,
              child: TextFormField(
                focusNode: _titleNode,
                textInputAction: TextInputAction.next,
                controller: _titleController,
                validator: (val) => val.isEmpty ? "Debes ingresar el artículo" : null,
                decoration: InputDecoration(
                  labelText: 'Artículo a vender',
                ),
                onFieldSubmitted: (value) {
                  _titleNode.unfocus();
                  FocusScope.of(context).requestFocus(_telefonoNode);
                },
              ),
            ),
            Padding(
              padding: UiHelper.formItemsPadding,
              child: TextFormField(
                focusNode: _telefonoNode,
                textInputAction: TextInputAction.next,
                controller: _telefonoController,
                validator: (val) => val.isEmpty ? "Debes ingresar un número telefonico" : null,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  labelText: 'Tu número de contacto',
                ),
                onFieldSubmitted: (value) {
                  _telefonoNode.unfocus();
                  FocusScope.of(context).requestFocus(_correoNode);
                },
              ),
            ),
            Padding(
              padding: UiHelper.formItemsPadding,
              child: TextFormField(
                focusNode: _correoNode,
                textInputAction: TextInputAction.next,
                controller: _correoController,
                validator: (val) => val.isEmpty ? "Debes ingresar el correo" : null,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Tu correo de contacto',
                ),
                onFieldSubmitted: (value) {
                  _correoNode.unfocus();
                  FocusScope.of(context).requestFocus(_descripcionNode);
                },
              ),
            ),
            Padding(
              padding: UiHelper.formItemsPadding,
              child: TextFormField(
                  focusNode: _descripcionNode,
                  controller: _descripcionController,
                  validator: (val) => val.isEmpty ? "Debes ingresar la descripción" : null,
                  minLines: 1,
                  maxLines: 10,
                  decoration: InputDecoration(labelText: 'Describe tu artículo', hintText: 'Máximo 10 lineas')),
            ),
            Padding(
              padding: UiHelper.formItemsPadding,
              child: _buildSubmitButton(viewModel),
            )
          ],
        ));
  }

  Widget _buildSubmitButton(YammerViewModel viewModel) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: SubmitButtonWidget(
        title: "Enviar",
        onSubmit: () {
          _onSubmit(viewModel);
        },
      ),
    );
  }

  void _onSubmit(YammerViewModel viewModel) async {
    final formState = _formKey.currentState;
    if (formState.validate()) {
      formState.save();
      final userModel = Provider.of<UserModel>(context, listen: false);

      await _progressDialog.show();
      final success = await viewModel.publicarAnuncio(userModel, _avisoOportunoReq, images.map<File>((e) => File(e.path)).toList());
      await _progressDialog.hide();

      if (!success) {
        util.unathorized(context, viewModel.status, () => util.showAlertPopup(context, "¡Atención!", viewModel.message));
      } else {
        Navigator.of(context).pop(viewModel.message);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Enviando");

    final _permissionsButton = Center(
      child: FlatButton(
          onPressed: () async {
            final permissions = await _applicationService.checkPermission();
            setState(() {
              _permissions = permissions;
            });
          },
          child: Text(
            'Permitir acceder a archivos',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20.0),
          )),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text("Publicar"),
        centerTitle: false,
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            Navigator.of(context).pop(null);
          },
        ),
      ),
      body: BaseWidget(
        model: YammerViewModel(yammerService: Provider.of(context), applicationService: Provider.of(context)),
        builder: (context, model, child) => !_permissions
            ? _permissionsButton
            : SingleChildScrollView(
                child: Card(
                    margin: UiHelper.listItemPadding,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[_buildUpdateImage(model), _buildForm(model)],
                    ))),
      ),
    );
  }
}

class _FotoWidget extends StatelessWidget {
  final PickedFile file;
  final int index;
  final VoidCallback removeFoto;

  const _FotoWidget({Key key, this.file, this.index, @required this.removeFoto}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          child: DottedBorder(
            dashPattern: [8, 4],
            strokeWidth: 1,
            borderType: BorderType.RRect,
            radius: Radius.circular(12),
            child: ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(12)),
              child: SizedBox.expand(
                child: Image.file(
                  File(file.path),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.topLeft,
          child: IconButton(color: Colors.red, icon: Icon(Icons.remove_circle), onPressed: () => removeFoto()),
        )
      ],
    );
  }
}

class _ButtonAddFoto extends StatelessWidget {
  final ValueChanged<PickedFile> addFoto;

  const _ButtonAddFoto({Key key, @required this.addFoto}) : super(key: key);

  Future<PickedFile> _pickFoto() {
    return ImagePicker().getImage(
      source: ImageSource.gallery,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: DottedBorder(
        dashPattern: [8, 4],
        strokeWidth: 1,
        child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(12)),
          child: SizedBox.expand(
            child: FlatButton(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.add),
                    UiHelper.verticalSpaceSmall,
                    Text(
                      "Agregar foto",
                      textAlign: TextAlign.center,
                    )
                  ],
                ),
                onPressed: () async => addFoto(await _pickFoto())),
          ),
        ),
      ),
    );
  }
}
