import 'package:espacio_jumex/core/models/recibo_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class ReciboDetalleWidget extends StatelessWidget {
  final ReciboModel reciboModel;
  
  const ReciboDetalleWidget({Key key, this.reciboModel}) : super(key: key);

  Widget _buildTotales(){
  const style = const TextStyle(fontWeight: FontWeight.bold);

    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: double.infinity),
      child: Card(
        child: Padding(
          padding: UiHelper.compactListItemPadding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              UiHelper.verticalSpaceSmall,
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Centro de Costos",style: style),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text("${reciboModel.centroCostos}",style: style, textAlign: TextAlign.right,),
                  ),
                ],
              ),
              UiHelper.verticalSpaceMedium,
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Registro patronal",style: style),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text("${reciboModel.patron.registroPatronal}",style: style, textAlign: TextAlign.right,),
                  ),
                ],
              ),
              UiHelper.verticalSpaceMedium,
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Salario diario",style: style),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text("\$ ${reciboModel.salarioDiario ?? '0.0'}",style: style, textAlign: TextAlign.right,),
                  ),
                ],
              ),
              UiHelper.verticalSpaceMedium,
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Percepciones",style: style),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text("\$ ${reciboModel.percepciones.totalPercepciones}",style: style, textAlign: TextAlign.right,),
                  ),
                ],
              ),
              UiHelper.verticalSpaceMedium,
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Deducciones",style: style),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text("\$ ${reciboModel.deducciones.totalPercepciones}",style: style, textAlign: TextAlign.right,),
                  ),
                ],
              ),
              UiHelper.verticalSpaceMedium,
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Text("Neto a pagar",style: style),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text("\$ ${reciboModel.netoAPagar}",style: style, textAlign: TextAlign.right,),
                  ),
                ],
              ),
              UiHelper.verticalSpaceSmall,
            ],
          ),
        )
      )
    );
  }

  List<Widget> _buildDesglose(){
    final detail = <Widget>[];

    final percepciones = Card(
      child: _buildConcepto("Percepciones",reciboModel.percepciones.detalle),
    );
    final deducciones = Card(
      child: _buildConcepto("Deducciones",reciboModel.deducciones.detalle),
    );
    final saldos = Card(
      child: _buildConcepto("Saldos",reciboModel.saldos),
    );

    detail.add(percepciones);
    detail.add(deducciones);
    detail.add(saldos);
    return detail;
  }

  Widget _buildConcepto(String title,List<ReciboDetalleModel> reciboDetalle){
    return ExpansionTile(
      title: Text(title),
      initiallyExpanded: false,
      children: List.generate(reciboDetalle.length, (index){
        final concepto = reciboDetalle[index];
        return Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.0),
          child: Container(
            margin: EdgeInsets.only(bottom: 14.0),
            decoration: new BoxDecoration(
              border: new Border(
                bottom: BorderSide(color: Colors.grey[300])
              )
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  flex: 3,
                  child: Text(concepto.concepto),
                ),
                Expanded(
                  flex: 3,
                  child: Text(concepto.importe!= null && concepto.importe.trim().isNotEmpty ? concepto.importe: concepto.laborado,textAlign: TextAlign.right,),
                ),
              ]
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {  
    return Column(
        children: <Widget>[
          _buildTotales(),
          ..._buildDesglose()
      ],
    );
  }
}