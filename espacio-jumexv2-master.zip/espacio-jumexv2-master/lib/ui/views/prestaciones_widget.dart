import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/yammerView_model.dart';
import 'package:espacio_jumex/ui/views/accesoExternoItem_widget.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/messageList_widget.dart';
import 'package:espacio_jumex/ui/views/yammerItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PrestacionesWidget extends StatelessWidget {

  final String yammerId; 
  final AccesoModel accesoModel;
  final void Function(YammerModel model) onTap;

  const PrestacionesWidget({
    Key key,
    this.yammerId,
    this.accesoModel,
    this.onTap
  }) : super(key: key);

  List<Widget> _buildSlivers(BuildContext context, YammerViewModel viewModel){

    final accesoExterno = Provider.of<AccesosModel>(context).accesos.where((x)=>x.idAccesoPadre == accesoModel.idAcceso && x.bitAcceso == 1).toList();
    final exitsAccesoExterno = accesoExterno.length > 0;
    
    final plist = SliverList(
      delegate: SliverChildBuilderDelegate(
        (context,index){
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: YammerListItemWidget(yammerModel: viewModel?.yammers[index], onTap: onTap != null ? ()=>onTap(viewModel?.yammers[index]) : null  ,)
          ); 
        },
        childCount: viewModel.itemCount,
        addAutomaticKeepAlives: false,
        addRepaintBoundaries: false
      )
    );

    if(!exitsAccesoExterno){
      return [plist];
    }else{
      return [
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index)=>Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.0),
              child: AccesoExternoItemWidget(accesoModel: accesoExterno[index])
            ),
            childCount: accesoExterno.length,
          ),
        ),
        plist
      ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserModel>(context);

    return BaseWidget<YammerViewModel>(
      model: YammerViewModel(yammerService: Provider.of(context),localdbService: Provider.of(context)),
      builder: (context,model,child)=>MessageListWidget(
        itemCount: model.itemCount,
        pullMore: model.pullMore,
        status: model.status,
        buildSlivers: (context)=>_buildSlivers(context, model),
        onRefresh:(action) async{
          if(action == MessageAction.refresh){
            await model.consultaMensajesNuevos(user,yammerId);
          }else{
            await model.consultaMensajesAnteriores(user,yammerId,olderThan: model.yammers.length >0 ? model.yammers.last.id : "0");
          }
          util.unathorized(context, model.status,()=>null);
          return Future.value(()=>null);
        }
      ),
    );
  }
}
