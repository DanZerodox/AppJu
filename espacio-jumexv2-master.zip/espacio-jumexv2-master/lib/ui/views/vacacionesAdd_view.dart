import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/vacacionesView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/dateTime_formfield.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class VacacionesAddView extends StatefulWidget {
  VacacionesAddView({Key key}) : super(key: key);

  @override
  _VacacionesAddViewState createState() => _VacacionesAddViewState();
}

class _VacacionesAddViewState extends State<VacacionesAddView> {
  final _formKey = GlobalKey<FormState>();
  final _comentarioController = TextEditingController();

  ProgressDialog _progressDialog;
  DateTime _initDate;
  DateTime _endDate;

  @override
  void dispose() { 
    _comentarioController.dispose();
    super.dispose();
  }

  Widget _buildForm(VacacionesViewModel viewModel){

    final inputs =<Widget>[
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: DateTimeFormField(
          dateFormat: viewModel.dateFormatter,
          label: "Seleccionar fecha",
          initialValue: _initDate,
          firstDate: DateTime.now().add(Duration(days: 1)),
          lastDate: DateTime.now().add(Duration(days: 30)),
          validator: (value)=>value==null ? "Ingresar una fecha válida" : null,
          onDateSelected: (value){
            setState(() {
              _initDate = value;
            });
          },
          decoration: InputDecoration(
            suffixIcon: Icon(Icons.calendar_today),
            labelText: "De"
          ),
        )
      ),
      _initDate == null ? SizedBox.shrink() : Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: DateTimeFormField(
          dateFormat: viewModel.dateFormatter,
          label: "Seleccionar fecha",
          initialValue: _endDate,
          firstDate: _initDate,
          lastDate: _initDate.add(Duration(days: 30)),
          validator: (value)=>value==null ? "Ingresar una fecha válida" : null,
          onDateSelected: (value){
            _endDate = value;
          },
          decoration: InputDecoration(
            suffixIcon: Icon(Icons.calendar_today),
            labelText: "A"
          ),
        ),
      ),
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: TextFormField(
           minLines: 1,
           maxLines: 5,
           decoration: InputDecoration(
               labelText: 'Comentarios',
               hintText: 'Agrega un comentario(no es obligatorio)'
           ),
           controller: _comentarioController,
        ),
      )
    ];

    final form = Container(
      margin: UiHelper.formItemsMargin,
      child: Center(
        child: Column(
          children: <Widget>[
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: inputs,
              )
            ),
          ],
        ),
      )
    );

    return form;
  }

  Widget _buildSubmitButton(VacacionesViewModel viewModel){
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Enviar",
        onSubmit: (){    
          _onSubmit(viewModel);
        },
      ),
    );
  }

  void _onSubmit(VacacionesViewModel viewModel) async{
    FocusScope.of(context).requestFocus(new FocusNode());
    final user = Provider.of<UserModel>(context,listen: false);
  
    final form = _formKey.currentState;
    if(form.validate()){

      await _progressDialog.show();
      final success = await viewModel.enviarSolicitudVacaciones(user,_initDate,_endDate,_comentarioController.text);
      await _progressDialog.hide();
      
      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop(viewModel.message);
      }
    } 
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Enviando");

    return BaseWidget<VacacionesViewModel>(
      model: VacacionesViewModel(nominaService: Provider.of(context)),
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          title: Text("Nueva solicitud"),
          centerTitle: false,
          leading: IconButton(
          icon: Icon(Icons.close),
            onPressed: (){
              Navigator.of(context).pop(null);
            },
          ),
        ),
        body: ListView(
          padding: UiHelper.listItemPadding,
          children: <Widget>[
            Card(
              child: Column(
                children: <Widget>[
                  _buildForm(model),
                  _buildSubmitButton(model)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}