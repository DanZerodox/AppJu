import 'package:espacio_jumex/ui/views/directoriorh_widget.dart';
import 'package:espacio_jumex/ui/views/faqs_widget.dart';
import 'package:flutter/material.dart';

class AyudaView extends StatefulWidget {

  @override
  _AyudaViewState createState() => _AyudaViewState();
}

class _AyudaViewState extends State<AyudaView> 
  with SingleTickerProviderStateMixin{

  TabController _tabController;
  ScrollController _scrollController;

  @override
  void initState() { 
    super.initState();
    
    _tabController= TabController(length: 2, vsync: this);
    _scrollController = ScrollController();
    
  }

  @override
  void dispose() { 
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: NestedScrollView(
        controller: _scrollController,
        headerSliverBuilder: (context, innerBoxIsScrolled) => <Widget>[
          SliverAppBar(
            title: Text("Preguntas frecuentes"),
            pinned: true,
            floating: true,
            forceElevated: innerBoxIsScrolled,
            bottom: TabBar(
              controller: _tabController,
              tabs: [
                Tab(
                  text: "Preguntas frecuentes",
                  icon: Icon(Icons.question_answer),
                ),
                Tab(
                  text: "Directorio",
                  icon: Icon(Icons.library_books),
                ),
              ],
            ),
          )
        ],
        body: TabBarView(
          controller: _tabController,
          children: [
            FAQSWidget(),
            DirectorioRHWidget()
          ]
        ),
      ),
    );
  }
}