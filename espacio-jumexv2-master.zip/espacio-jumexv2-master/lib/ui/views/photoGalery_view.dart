import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/pdfView_model.dart';
import 'package:espacio_jumex/core/models/photoItem_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/cachedImage_widget.dart';
import 'package:espacio_jumex/ui/widgets/videoPlayer_widget.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';

class PhotoGaleryView extends StatefulWidget {

  final Color backgroundColor;
  final List<PhotoItemModel> photos;
  final int initialIndex;
  final Map<String, String> headers;
  final PageController pageController;

  PhotoGaleryView({Key key,this.backgroundColor,this.photos,this.initialIndex = 0, this.headers}):
    pageController = PageController(initialPage: initialIndex),
  super(key: key);

  @override
  _PhotoGaleryViewState createState() => _PhotoGaleryViewState();
}

class _PhotoGaleryViewState extends State<PhotoGaleryView> {

  bool _visibleAppbar = true;
  bool _isLocked = false;

  @override
  void initState() { 
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.backgroundColor,
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.black
        ),
        constraints: BoxConstraints.expand(
          height: MediaQuery.of(context).size.height
        ),
        child: Stack(
          children: <Widget>[
            PageView.builder(
              controller: widget.pageController,
              itemCount: widget.photos.length,
              itemBuilder: (context, index) => _PhotoGalleryItem( item: widget.photos[index], headers: widget.headers,onProceeding:(v){
                 setState(() {
                   _isLocked = v;
                   _visibleAppbar = !v;
                });
              },),
              physics: _isLocked  ? const NeverScrollableScrollPhysics() : null,
            ),
            !_visibleAppbar? SizedBox.shrink() : Positioned(
              top: 0.0,
              left: 0.0,
              right: 0.0,
              child:AppBar(
                elevation: 0.2,
                backgroundColor: widget.backgroundColor,
              )
            ),          
          ],
        ),
      ),
    );
  }
}

class _PhotoGalleryItem extends StatelessWidget {
  final PhotoItemModel item;
  final Map<String, String> headers;
  final ValueChanged<bool> onProceeding;

  const _PhotoGalleryItem({Key key, @required this.item, this.headers, this.onProceeding}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if(item.type == MediaType.image){

      return PhotoView.customChild(
        initialScale: PhotoViewComputedScale.covered,
        minScale: PhotoViewComputedScale.contained * 0.5,
        maxScale: PhotoViewComputedScale.covered * 2.5,
        heroAttributes: PhotoViewHeroAttributes(tag: item.id, transitionOnUserGestures: true),
        gestureDetectorBehavior: HitTestBehavior.opaque,
        scaleStateChangedCallback: (scaleState) {
          onProceeding?.call( scaleState != PhotoViewScaleState.initial);
        },
        child: CachedImageWidget(
          url: item.url,
          headers: headers,
          errorWidget: (_,__,___)=>Center(
            child: Icon(Icons.broken_image),
          ),
        )
      );
    }else if(item.type == MediaType.video2Factor){
      return VideoPlayerWidgetWrap(url: item.url, listenPlayer: (state) {
        onProceeding?.call(state == VideoPlayerStatus.play);
      },);
    }else if(item.type == MediaType.video){
      return VideoPlayerWidget(url: item.url, listenPlayer: (state) {
        onProceeding?.call(state == VideoPlayerStatus.play);
      },);
    }else if(item.type == MediaType.pdf || (item.type == MediaType.document && item.url.contains("pdf")) ){
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CachedImageWidget(
            url: item.thumbnail,
            headers: headers,
            errorWidget: (_,__,___)=>Center(
              child: Icon(Icons.broken_image),
            ),
          ),
          UiHelper.verticalSpaceSmall,
          RaisedButton(
            onPressed: () async{
              Navigator.of(context).pushNamed(RoutePath.VisualizarPdf, arguments: new PdfViewModel(
                url: item.url,
                title: item.info
              ));
            },
            child: Text("Abrir documento")
          )
        ],
      );
    }else{
      return Center(
        child: Text("Contenido no soportado"),
      );
    }
  }
}