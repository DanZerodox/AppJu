import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/ui/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


class LandingView extends StatefulWidget{ 
  LandingView({Key key}):super(key: key);

  @override
  State<StatefulWidget> createState() => _LandingViewtate();
}

class _LandingViewtate extends State<LandingView>{
  @override
  void initState() { 
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp
    ]);

    Future.delayed(Duration(seconds: 2),(){
      Navigator.pushReplacementNamed(context, RoutePath.PreHome);
    });

    super.initState();
  }

  @override
  void dispose() { 
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight
    ]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var pageSize = MediaQuery.of(context).size;

    return Scaffold(
      body: LoadingWidget(size: pageSize)
    );
  }
}