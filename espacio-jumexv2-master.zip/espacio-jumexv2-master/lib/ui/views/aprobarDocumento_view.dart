import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/documento_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/aprobarDocumentoView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/pdfViewer_view.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class AprobarDocumentoView extends StatefulWidget {
  AprobarDocumentoView({Key key}) : super(key: key);

  @override
  _AprobarDocumentoViewState createState() => _AprobarDocumentoViewState();
}

class _AprobarDocumentoViewState extends State<AprobarDocumentoView> {
  final _pageController = PageController(initialPage: 0);

  int _index = 0;
  bool _ready = false;

  @override
  void initState() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp
    ]);
    
    super.initState();
  }

  @override
  void dispose() {
    _pageController.dispose();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight
    ]);
    
    super.dispose();
  }

  void _aprobe(AprobarDocumentoViewModel viewModel, DocumentoModel document) async{
    final progress = util.progressDialogBuilder(context, "Enviando ...");

    final user = Provider.of<UserModel>(context);

    await progress.show();
    final success = await viewModel.aprobarAvisoLegal(user,document);
    await progress.hide();

    if(!success){
      util.unathorized(context, viewModel.status, ()=>util.showAlertPopup(context, "¡Advertencia!", viewModel.message));
    }else{
      if(viewModel.aprobar == 0)
        Navigator.of(context).pushNamedAndRemoveUntil(RoutePath.PreHome,(x)=>false);
      else {
        setState(() {
          _ready = false;
        });
        _pageController.animateToPage(0, duration: Duration(milliseconds: 400 ), curve: Curves.easeOut);
      }
    }
  }

  void _openExternalUrl(String url) async{
    await showDialog(
      context: context,
      builder: (_)=>AlertDialog(
        title: new Text("¡Importante!"),
        content: new Text("Está por salidar del aplicativo de Espacio Jumex, ¿desaea continuar?"),
        actions: <Widget>[
          new FlatButton(
            child: new Text("Ir"),
            onPressed: ()async{
              if (await canLaunch(url)) {
                await launch(url);
                Navigator.of(context).pop();
              } else {
                util.showAlertPopup(context,"¡Atención!","No es posible abrir el enlace");
              }
            },
          )
        ],
      )
    );
  }

  List<Widget> _buildListChildren(AprobarDocumentoViewModel model){
    var children =
    <Widget>[
      DocumentosListWidget(
        documentos: model.documentos,
        onTap: (index){
          if(model.documentos[index].type == 'LOCAL'){
            _pageController.animateToPage(1, duration: Duration(milliseconds: 400 ), curve: Curves.easeOut);
            _index = index;
          }else{
            _openExternalUrl(model.documentos[index].url);
          }
        },
      ),
    ];

      if((model.documentos?.length ??0) > 0)

      children.add(PdfViewerWidget(
        model.documentos[_index].url,
        onDocumentLoaded: (d){
          setState(() {
            _ready = true;
          });
        },
      ));

      return children;
  }
  
  @override
  Widget build(BuildContext context) {
    return BaseWidget<AprobarDocumentoViewModel>(
      model: AprobarDocumentoViewModel(userService: Provider.of(context)),
      onModelReady: (model){
        model.consultarAvisosLegales(Provider.of<UserModel>(context));
      },
      builder: (context,model,child)=> 
        Scaffold(
          appBar: AppBar(
            title: Text("Aprobar"),
            centerTitle: false,
          ),
          body: model.status == Status.busy ? UiHelper.progressIndicator : 
          PageView(
            physics: NeverScrollableScrollPhysics(),
            pageSnapping: false,
            controller: _pageController,
            children: _buildListChildren(model)
          ),  
          floatingActionButton: !_ready ? null : FloatingActionButton(
            heroTag: "ok",
            child: Icon(Icons.check),
            onPressed: (){
              _aprobe(model, model.documentos[_index]);
            }
          ),
          bottomNavigationBar: BottomAppBar(
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                 IconButton(
                  icon: Icon(Icons.list), 
                  onPressed: (){
                    _pageController.animateToPage(0, duration: Duration(milliseconds: 400 ), curve: Curves.easeOut);
                    setState(() {
                      _ready = false;
                    });
                  }
                )
              ],
            ),
          ),
        )
    );
  }
}

class DocumentosListWidget extends StatelessWidget {
  final List<DocumentoModel> documentos;
  final void Function(int) onTap;

  const DocumentosListWidget({Key key,this.documentos, this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: UiHelper.listItemPadding,
      itemCount: documentos.length,
      itemBuilder: (context,index)=>ListItemWidget(
        child: ListTile(
          title: Text(documentos[index].name)
        ),
        onTap: ()=>onTap(index),
      )
    );
  }
}