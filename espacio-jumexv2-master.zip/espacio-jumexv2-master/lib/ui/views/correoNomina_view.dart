import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class CorreoNominaView extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _CorreoNominaViewState();
}

class _CorreoNominaViewState extends State<CorreoNominaView>{
  final _keyForm = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  String _email;
  ProgressDialog _progressDialog;

  Widget _buildForm(){
    return Form(
      key: _keyForm,
      child: Column(
        children: <Widget>[
          TextFormField(
            decoration: InputDecoration(
              labelText: "Correo nuevo"
            ),
            keyboardType: TextInputType.emailAddress,
            validator: (val){
              if( util.isNullOrEmpty(val) ){
                return "El valor es requerido";
              }
              else if( val != null && !RegExp(Constants.regexpEmail).hasMatch(val) ){
                return "El correo no tiene formato inválido";
              }
              return null;
            },
            onSaved: (val)=>_email=val,
          ),
        ],
      ),
    );
  }

  Widget _buildSubmitButton(NominaViewModel viewModel){
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Actualizar",
        onSubmit: (){
          FocusScope.of(context).requestFocus(FocusNode());
          _submit(viewModel);
        },
      ),
    );
  }
  
  void _submit(NominaViewModel viewModel) async{
    final formState = _keyForm.currentState;
    if(formState.validate()){
      formState.save();
      
      await _progressDialog.show();
      final success = await viewModel.actualizarCorreoNomina(Provider.of<UserModel>(context),_email);
      await _progressDialog.hide();

      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop(viewModel.message);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Actualizando");

    return BaseWidget<NominaViewModel>(
      model:  NominaViewModel(nominaService: Provider.of(context)),
      builder: (context,model,child)=>Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          centerTitle: false,
          title: Text("Correo de nómina"),
          leading: IconButton(
          icon: Icon(Icons.close),
            onPressed: (){
              Navigator.of(context).pop(null);
            },
          ),
        ),body: Container(
          child: ListView(
            padding: UiHelper.listItemPadding,
            children: <Widget>[
              Card(
                child: Padding(
                  padding: UiHelper.formItemsPadding,
                  child: Column(
                    children: <Widget>[
                      _buildForm(),
                      UiHelper.verticalSpaceSmall,
                      _buildSubmitButton(model),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    ); 
  }
}
