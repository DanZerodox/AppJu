import 'dart:convert';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/appView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/copyable_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PerfilView extends StatelessWidget {
  const PerfilView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Perfil"),
      ),
      body: PerfilWidget(),
    );
  }
}

class PerfilWidget extends StatelessWidget {

  const PerfilWidget({Key key}):super(key: key);

  List<Widget> _buildItemsList(BuildContext context, UserModel user, AccesosModel accesosModel){
    final items = <Widget>[
      Padding(
        padding: EdgeInsets.symmetric(vertical: 20),
        child: Container(
          width: 140.0,
          height: 140.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage(
              image: MemoryImage(Base64Decoder().convert(user.fotografia)),
              fit: BoxFit.fill
            )
          ),
        ),
      ),
      ListTile(
        title: Text("Nombre", ),
        subtitle: Text(user?.nombre, ),
      ),
      CopyableWidget(
        text: user?.correo,
        onCopy: (){
           Scaffold.of(context).showSnackBar(SnackBar(content: new Text("Copiado al portapapeles"),));
         },
        child: ListTile(
          title: Text("Correo", ),
          subtitle: Text(user?.correo, ),
          trailing: Icon(Icons.content_copy),
        )
      ),
      ListTile(
        title: Text("Sociedad", ),
        subtitle: Text("${user.denominacionS}", ),
      ),
      user.nombreJefe != null ? ListTile(
        title: Text("Jefe Inmediato", ),
        subtitle: Text(user.nombreJefe ?? "--", ),
      ) : SizedBox.shrink(),
      ListTile(
        title: Text("Fecha de alta", ),
        subtitle: Text("${user.fechaAlta}", ),
      ),
    ];

    if(accesosModel.accesos.any((x)=>x.rutaAcceso == "/" && x.bitAcceso == 1)){
      items.insert(3, 
       CopyableWidget(
         text: user?.ceco,
         onCopy: (){
           Scaffold.of(context).showSnackBar(SnackBar(content: new Text("Copiado al portapapeles"),));
         },
         child: ListTile(
          title: Text("Centro de costos", ),
          trailing: Icon(Icons.content_copy),
          subtitle: Text(user?.ceco, ),
         )
       ));

      items.insert(4, 
       ListTile(
        title: Text("División", ),
        subtitle: Text(user?.divisionPDes, ),
      ));
    }

    return items;
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserModel>(context,listen: false);
    final accesosModel = Provider.of<AccesosModel>(context,listen: false);

    return BaseWidget<AppViewModel>(
      model: AppViewModel(userService: Provider.of(context)),
      builder: (context,model,child)=>model.status == Status.busy ? UiHelper.progressIndicator : ListView(
        padding: UiHelper.listItemPadding,
        children: <Widget>[
          Card(
            child: Column(
              children: <Widget>[
                ..._buildItemsList(context, user,accesosModel)
              ],
            ),
          )
        ],
      ),
    );
  }
}