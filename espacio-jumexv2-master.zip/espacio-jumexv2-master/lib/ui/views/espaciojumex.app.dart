import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/providers_setup.dart';
import 'package:espacio_jumex/ui/views/routes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'package:flutter/foundation.dart' show kDebugMode;

class EspacioJumexApp extends StatefulWidget {
  final String title;
  final ThemeData theme;
  final GlobalKey<NavigatorState> navigatorKey;

  static final analytics = new FirebaseAnalytics();
  static final observer = new FirebaseAnalyticsObserver(analytics: analytics);

  EspacioJumexApp({Key key, this.title, this.theme, this.navigatorKey}) : super(key: key);

  @override
  _EspacioJumexAppState createState() => _EspacioJumexAppState();
}

class _EspacioJumexAppState extends State<EspacioJumexApp> {
  @override
  void initState() {
    _initFlutterFire();
    super.initState();
  }

  void _initFlutterFire() async {
    await _initializeFlutterFire();
  }

  Future<void> _initializeFlutterFire() async {
    // Wait for Firebase to initialize
    await Firebase.initializeApp();

    if (kDebugMode) {
      // Force enable crashlytics collection enabled if we're testing it.
      await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
    } else {
      // Else only enable it in non-debug builds.
      // You could additionally extend this to allow users to opt-in.
      await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(!kDebugMode);
    }

    // Pass all uncaught errors to Crashlytics.
    Function originalOnError = FlutterError.onError;
    FlutterError.onError = (FlutterErrorDetails errorDetails) async {
      await FirebaseCrashlytics.instance.recordFlutterError(errorDetails);
      // Forward to original handler.
      originalOnError(errorDetails);
    };
  }

  @override
  Widget build(BuildContext context) {
    final platform = Theme.of(context).platform;

    return MultiProvider(
      providers: ProvidersSetup(targetPlatform: platform).buildProviders(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        localizationsDelegates: [
          // ... app-specific localization delegate[s] here
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          const _FallbackCupertinoLocalisationsDelegate()
        ],
        supportedLocales: [
          const Locale('en'), // English
          const Locale('es'), // Spanish
          // ... other locales the app supports
        ],
        locale: new Locale('es'),
        title: widget.title,
        theme: widget.theme,
        navigatorKey: widget.navigatorKey,
        initialRoute: RoutePath.Landing,
        onGenerateRoute: Routes.generateRoute,
        navigatorObservers: <NavigatorObserver>[EspacioJumexApp.observer],
      ),
    );
  }
}

class _FallbackCupertinoLocalisationsDelegate extends LocalizationsDelegate<CupertinoLocalizations> {
  const _FallbackCupertinoLocalisationsDelegate();

  @override
  bool isSupported(Locale locale) => true;

  @override
  Future<CupertinoLocalizations> load(Locale locale) => DefaultCupertinoLocalizations.load(locale);

  @override
  bool shouldReload(_FallbackCupertinoLocalisationsDelegate old) => false;
}
