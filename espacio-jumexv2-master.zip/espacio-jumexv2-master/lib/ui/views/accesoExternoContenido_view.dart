import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/accesoExternoContenido_model.dart';
import 'package:espacio_jumex/core/models/photoItem_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/appView_model.dart';
import 'package:espacio_jumex/slideRightRoute.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/customWeb_view.dart';
import 'package:espacio_jumex/ui/widgets/copyable_widget.dart';
import 'package:espacio_jumex/ui/widgets/thumbnail_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class AccesoExternoContenidoView extends StatelessWidget {
  final AccesoModel accesoModel;

  AccesoExternoContenidoView({Key key, this.accesoModel}) : super(key: key);

  final _scaffoldKey = GlobalKey<ScaffoldState>();

  Widget _buildBody(BuildContext context, AppViewModel viewModel) {
    switch (viewModel.status) {
      case Status.busy:
        return UiHelper.progressIndicator;
        break;
      case Status.error:
        return Center(
          child: Text(viewModel.message),
        );
        break;
      default:
        return ListView(
          padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 10),
          children: <Widget>[
            Card(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ..._buildReadableElements(viewModel.contenidoModel),
                  ..._buildCopiableElements(viewModel.contenidoModel),
                  ..._buildLaunchableElements(context, viewModel.contenidoModel),
                  ..._buildPresentableElements(viewModel.contenidoModel),
                ],
              ),
            )
          ],
        );
    }
  }

  List<Widget> _buildReadableElements(List<AccesoExternoContenidoModel> list) {
    var items = <Widget>[];

    for (var item in list.where((x) => x.tipo == AccesoExternoType.readable)) {
      var layout = <Widget>[
        !util.isNullOrEmpty(item.texto)
            ? Padding(
                padding: EdgeInsets.only(top: 20.0),
                child: Text(item.texto),
              )
            : UiHelper.verticalSpaceSmall,
        UiHelper.verticalSpaceMedium,
        Padding(
            padding: UiHelper.listInternalItemPadding,
            child: Text(item.objetivo))
      ];
      items.addAll(layout);
    }

    if (items.length > 0) items.add(UiHelper.verticalSpaceMedium);
    return items;
  }

  List<Widget> _buildCopiableElements(List<AccesoExternoContenidoModel> list) {
    var items = <Widget>[];

    for (var item in list.where((x) => x.tipo == AccesoExternoType.copiable)) {
      var layout = <Widget>[
        Padding(
          padding: EdgeInsets.only(top: 20.0),
          child: Text(item.texto),
        ),
        UiHelper.verticalSpaceXSmall,
        Padding(
          padding: UiHelper.listInternalItemPadding,
          child: CopyableWidget(
            text: item.objetivo,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Flexible(
                  flex: 1,
                  child: Text(
                    item.objetivo,
                    style: TextStyle(fontSize: 18.0),
                  ),
                ),
                UiHelper.horizontalSpaceSmall,
                Icon(Icons.content_copy),
              ],
            ),
            onCopy: () {
              _scaffoldKey.currentState.showSnackBar(SnackBar(
                content: Text("Copiado al portapapeles"),
              ));
            },
          ),
        )
      ];
      items.addAll(layout);
    }

    if (items.length > 0) items.add(UiHelper.verticalSpaceMedium);
    return items;
  }

  List<Widget> _buildLaunchableElements(BuildContext context, List<AccesoExternoContenidoModel> list) {
    var items = <Widget>[];

    for (var item in list.where((x) => x.tipo == AccesoExternoType.launchable)) {
      items.add(
        Padding(
          padding: EdgeInsets.only(top: 20.0),
          child: Center(
            child: RaisedButton(
              child: Text(item.texto),
              onPressed: () async {
                if(item.subTipo == MediaType.http){
                   Navigator.of(context).push(SlideRightRoute(
                    settings: RouteSettings(name: "webView"),
                    widget: CustomWebView(
                      title: item.texto,
                      url: item.objetivo,
                    )
                  ));
                }else{
                  if (await canLaunch(item.objetivo)) {
                    await launch(item.objetivo);
                  } else {
                    util.showAlertPopup(context, "¡Alerta!", 'No fué posible abrir ${item.objetivo}');
                  }
                }
              }
            )
          ),
        ),
      );
    }

    if (items.length > 0) items.add(UiHelper.verticalSpaceMedium);
    return items;
  }

  List<Widget> _buildPresentableElements(List<AccesoExternoContenidoModel> list) {
    var items = <Widget>[];

    var presentables =
        list.where((x) => x.tipo == AccesoExternoType.presentable)?.toList();

    if (presentables != null && presentables.length > 0) {
      final photos = List.generate(presentables.length, (index) {
        var x = presentables[index];

        return PhotoItemModel(
          id: index.toString(),
          url: "${ApiConstant.apiServer}/Content/img/app/${x.objetivo}",
          thumbnail: "${ApiConstant.apiServer}/Content/img/app/${x.objetivo}",
          type: x.subTipo
        );
      }).toList();

      items.add(
        Padding(
          padding: EdgeInsets.symmetric(vertical: 25.0, horizontal: 18.0),
          child: ThumbnailWidget(items: photos),
        ),
      );

      items.add(UiHelper.verticalSpaceMedium);
    }
    return items;
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserModel>(context);

    return BaseWidget<AppViewModel>(
      model: AppViewModel(userService: Provider.of(context)),
      onModelReady: (model) {
        model.consultaContenidoAcceso(user, accesoModel);
      },
      builder: (context, model, child) => Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          centerTitle: false,
          title: Text(accesoModel.nombreAcceso),
        ),
        body: _buildBody(context, model)),
    );
  }
}
