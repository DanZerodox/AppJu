import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:espacio_jumex/core/models/selectableItem.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/appView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class NotificacionesWidget extends StatelessWidget {
  const NotificacionesWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<NotificacionModel>(
      builder: (context, notificationModel, child) => NotificacionesListWidget(notificationModel),
    );
    // return NotificacionesListWidget(null);
  }
}

class NotificacionesListWidget extends StatefulWidget {
  final NotificacionModel notificacionModel;
  NotificacionesListWidget(this.notificacionModel);

  @override
  _NotificacionesListWidgetState createState() => _NotificacionesListWidgetState();
}

class _NotificacionesListWidgetState extends State<NotificacionesListWidget> {
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();

  final _tipoNotificaciones = [
    const DropdownMenuItem(
      child: const Text("Todas"),
      value: "--",
    ),
    const DropdownMenuItem(
      child: const Text("Vacaciones"),
      value: RoutePath.Vacaciones,
    ),
    const DropdownMenuItem(child: const Text("Incidencias"), value: RoutePath.Preevaluacion),
    const DropdownMenuItem(
      child: const Text("Cumpleaños"),
      value: RoutePath.Cumpleanios,
    ),
  ];

  @override
  void initState() {
    Future.microtask(() {
      var viewModel = Provider.of<AppViewModel>(context);
      viewModel.consultarNotificaciones(Provider.of<UserModel>(context), widget.notificacionModel);
      util.unathorized(context, viewModel.status, () => null);
    });

    super.initState();
  }

  @override
  void didUpdateWidget(NotificacionesListWidget oldWidget) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _refreshIndicatorKey.currentState.show();
    });

    super.didUpdateWidget(oldWidget);
  }

  Widget _buildItem(SelectableItem<NotificacionModel> item, AppViewModel viewModel) {
    var e = item.item;

    return ListItemWidget(
      margin: EdgeInsets.symmetric(horizontal: 8.0),
      child: Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: new ListTile(
            title: Text(
              e.title,
              style: TextStyle(fontWeight: item.isSelected ? FontWeight.bold : FontWeight.normal),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                UiHelper.verticalSpaceXSmall,
                Text(
                  e.date,
                  textScaleFactor: .8,
                  style: TextStyle(fontStyle: FontStyle.italic),
                ),
                UiHelper.verticalSpaceXSmall,
                Text(e.body)
              ],
            ),
            trailing: e.type != NotificationType.simple ? Icon(Icons.chevron_right) : null,
          )),
      onTap: () async {
        viewModel.onSelectNotificacion(e);
        if (e.type == NotificationType.ruta) {
          Navigator.of(context).pushNamed(e.subType, arguments: e.value);
        } else if (e.type == NotificationType.externo) {
          if (await canLaunch(e.value)) {
            await launch(e.value);
          } else {
            util.showAlertPopup(context, "¡Alerta!", 'No fué posible abrir ${e.value}');
          }
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    var viewModel = Provider.of<AppViewModel>(context);
    final items = viewModel.notificaciones;

    return RefreshIndicator(
        key: _refreshIndicatorKey,
        child: ListView.builder(
          itemCount: (items?.length ?? 0) + 1,
          itemBuilder: (context, index) {
            if (index == 0) {
              return Card(
                  child: new Form(
                      child: new Column(
                children: <Widget>[
                  Padding(
                    padding: UiHelper.formItemsPadding,
                    child: FormField<String>(
                      validator: (val) => val == '--' ? "Selecciona una opción" : null,
                      builder: (state) => new DropdownButton(
                        isExpanded: true,
                        value: viewModel.tipoNotificacion,
                        items: _tipoNotificaciones,
                        onChanged: viewModel.setTipoNotificacion,
                      ),
                    ),
                  ),
                ],
              )));
            } else {
              final e = items[index - 1];
              return _buildItem(e, viewModel);
            }
          },
        ),
        onRefresh: () async {
          viewModel.consultarNotificaciones(Provider.of<UserModel>(context), widget.notificacionModel);
          util.unathorized(context, viewModel.status, () => null);
          return Future.value(() => null);
        });
  }
}

class ListItems extends StatefulWidget {
  final List<SelectableItem<NotificacionModel>> items;
  final GlobalKey<RefreshIndicatorState> refreshIndicatorKey;
  final NotificacionModel notificacionModel;

  ListItems({Key key, this.items, this.refreshIndicatorKey, this.notificacionModel}) : super(key: key);

  @override
  _ListItemsState createState() => _ListItemsState();
}

class _ListItemsState extends State<ListItems> {
  @override
  void didUpdateWidget(ListItems oldWidget) {
    if (widget.notificacionModel != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        widget.refreshIndicatorKey.currentState.show();
      });
    }

    super.didUpdateWidget(oldWidget);
  }

  Widget _buildItem(SelectableItem<NotificacionModel> item, AppViewModel viewModel) {
    var e = item.item;

    return ListItemWidget(
      margin: EdgeInsets.symmetric(horizontal: 8.0),
      child: Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: new ListTile(
            title: Text(
              e.title,
              style: TextStyle(fontWeight: item.isSelected ? FontWeight.bold : FontWeight.normal),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                UiHelper.verticalSpaceXSmall,
                Text(
                  e.date,
                  textScaleFactor: .8,
                  style: TextStyle(fontStyle: FontStyle.italic),
                ),
                UiHelper.verticalSpaceXSmall,
                Text(e.body)
              ],
            ),
            trailing: e.type != NotificationType.simple ? Icon(Icons.chevron_right) : null,
          )),
      onTap: () async {
        viewModel.onSelectNotificacion(e);
        if (e.type == NotificationType.ruta) {
          Navigator.of(context).pushNamed(e.subType, arguments: e.value);
        } else if (e.type == NotificationType.externo) {
          if (await canLaunch(e.value)) {
            await launch(e.value);
          } else {
            util.showAlertPopup(context, "¡Alerta!", 'No fué posible abrir ${e.value}');
          }
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    var viewModel = Provider.of<AppViewModel>(context);

    return Column(
      children: widget.items.map((e) => _buildItem(e, viewModel)).toList(),
    );
  }
}
