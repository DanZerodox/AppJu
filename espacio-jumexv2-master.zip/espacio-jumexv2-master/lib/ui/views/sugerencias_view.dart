import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class SugerenciasView extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _SugerenciasState();
}

class _SugerenciasState extends State<SugerenciasView>{
  final _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  final _sugerenciaController = new TextEditingController();
  final _emailController = new TextEditingController();

  String _sugerencia;
  String _email;

  ProgressDialog _progressDialog;

  @override
  void initState() { 
    _sugerenciaController.addListener(()=>_sugerencia = _sugerenciaController.text);
    _emailController.addListener(()=>_email = _emailController.text);
    super.initState();
  }

  @override
  void dispose() { 
    _sugerenciaController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  Widget _buildForm(NominaViewModel viewModel){
    final userModel = Provider.of<UserModel>(context,listen: false);

    final inputs =<Widget>[
      Padding(
        padding: UiHelper.formItemsPadding,
        child: new TextFormField(
          controller: _sugerenciaController,
          validator: (val) => val.isEmpty ? "Debes ingresar alguna sugerencia" : null,
          minLines: 1,
          maxLines: 5,
          decoration: InputDecoration(
            labelText: 'Escribe tu sugerencia'
          )
        )
      ),
      Padding(
        padding: UiHelper.formItemsPadding,
        child: Text("El mensaje enviado es confidencial y anónimo.",textScaleFactor: 0.8,),
      )
    ];

    if(userModel.correo == null || userModel.correo.isEmpty){
      inputs.insertAll(1,<Widget>[
        Padding(
          padding: UiHelper.formItemsPadding,
          child: new TextFormField(
            controller: _emailController,
            validator: (val) => val.isEmpty ? "Debes ingresar un correo de contacto" : null,
            decoration: InputDecoration(
              labelText: 'Escribe un correo de contacto'
            )
          )
        )
      ]);
    }

    final form = Container(
      margin: UiHelper.formItemsMargin,
      child: Center(
        child: Column(
          children: <Widget>[
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: inputs,
              )
            ),
          ],
        ),
      )
    );

    return form;
  }

  Widget _buildSubmitButton(NominaViewModel viewModel){
    FocusScope.of(context).requestFocus(new FocusNode());
    
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Enviar",
        onSubmit: (){
          _onSubmit(viewModel);
        },
      ),
    );
  }

  void _onSubmit(NominaViewModel viewModel) async{
    final formState = _formKey.currentState;
    if(formState.validate()){
      formState.save();
      final userModel = Provider.of<UserModel>(context,listen: false);
      
      await _progressDialog.show();
      final success = await viewModel.enviarSugerencias(userModel, _sugerencia, _email);
      await _progressDialog.hide();

      if(!success){
        _sugerenciaController.clear();
        _emailController.clear();
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop(viewModel.message);
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Enviando");

    return BaseWidget(
      model: NominaViewModel(nominaService:Provider.of(context)),
      builder: (context,NominaViewModel model, child)=>Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          centerTitle: false,
          title: Text("Sugerencias"),
        ),
        body:ListView(
          padding: UiHelper.listItemPadding,
          children: <Widget>[
            Card(
              child: Column(
                children: <Widget>[
                  _buildForm(model),
                  _buildSubmitButton(model)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}