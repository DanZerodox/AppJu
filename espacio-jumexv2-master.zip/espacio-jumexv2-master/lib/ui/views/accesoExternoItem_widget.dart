import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/slideRightRoute.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/customWeb_view.dart';
import 'package:espacio_jumex/ui/widgets/cachedImage_widget.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart' as launcher;

class AccesoExternoItemWidget extends StatefulWidget {
  final AccesoModel accesoModel;

  AccesoExternoItemWidget({Key key, @required this.accesoModel})
      : assert(accesoModel != null),
        super(key: key);

  @override
  _AccesoExternoItemWidgetState createState() => _AccesoExternoItemWidgetState();
}

class _AccesoExternoItemWidgetState extends State<AccesoExternoItemWidget> {
  @override
  Widget build(BuildContext context) {
    final item = widget.accesoModel;

    return ListItemWidget(
      onTap: () async {
        if (item.bitConsumeApi == 1) {
          Navigator.of(context).pushNamed(RoutePath.ContenidoExterno, arguments: widget.accesoModel);
        } else {
          if (item.subTipo == MediaType.http) {
            Navigator.of(context).push(SlideRightRoute(
                settings: RouteSettings(name: "webView"),
                widget: CustomWebView(
                  title: item.nombreAcceso,
                  url: item.urlLaunch,
                )));
          } else {
            if (await launcher.canLaunch(item.urlLaunch)) {
              await launcher.launch(item.urlLaunch);
            } else {
              util.showAlertPopup(context, "¡Atención!", "No es posible abrir el enlace");
            }
          }
        }
      },
      child: Center(
        child: ListTile(
          title: Row(children: [
            Padding(
                padding: EdgeInsets.all(5.0),
                child: SizedBox(
                    width: 52.0,
                    child: item.appIcon.isEmpty
                        ? Image.asset("assets/images/espaciojumex.png")
                        : CachedImageWidget(
                            url: "${ApiConstant.apiServer}/Content/img/app/${item.appIcon}",
                            errorWidget: (_, __, ___) => Center(
                              child: Icon(Icons.broken_image),
                            ),
                          ))),
            UiHelper.horizontalSpaceMedium,
            Flexible(child: Text(item.nombreAcceso))
          ]),
        ),
      ),
    );
  }
}
