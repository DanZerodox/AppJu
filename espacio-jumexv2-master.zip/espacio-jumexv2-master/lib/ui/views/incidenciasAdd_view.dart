import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/ui/views/IncidenciaAddFecha_widget.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/incidenciaAddForm_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class IncidenciasAddView extends StatefulWidget {
  IncidenciasAddView({Key key}) : super(key: key);

  @override
  _IncidenciasAddViewState createState() => _IncidenciasAddViewState();
}

class _IncidenciasAddViewState extends State<IncidenciasAddView> {

  int _index = 0;
  PageController _pageController;

  @override
  void initState() { 
    super.initState();
    _pageController = new PageController(initialPage: _index);
  }

  @override
  void dispose() { 
    _pageController.dispose();

    super.dispose();
  }

  Widget _buildContent(){
    final views = <Widget>[
      IncidenciaAddFechaWidget(
        key: PageStorageKey<int>(0)
      ),
      IncidenciaAddFormWidget(
        key: PageStorageKey<int>(1)
      ),
    ];

    return PageView(
      controller: _pageController,
      physics: NeverScrollableScrollPhysics(),
      onPageChanged: (index){
        setState(() {
          _index = index;
        });
      },
      children: views,
    );
  }

  Widget _buildText(IncidenciasViewModel viewModel){
    final fecha = viewModel.fechaConsulta;
    
    if(_index == 0 && fecha != null && fecha.difference(DateTime.now()).inHours <=  0){
      return  viewModel.maxDiasIncidencia == 0 ? Text("${viewModel.fechasIncidencia.length}") : Text("${viewModel.fechasIncidencia.length}/${viewModel.maxDiasIncidencia}");
    }else{
      return SizedBox.shrink();
    }
  }

  Widget _buildBtnSiguiente(IncidenciasViewModel viewModel){
    if(_index <1 ){
      final fecha = viewModel.fechaConsulta;
      final action = viewModel.incidencia?.valor != ""  && fecha != null
        && (  (fecha.difference(DateTime.now()).inHours <=  0 && viewModel.fechasIncidencia.length >0)
              || (fecha.difference(DateTime.now()).inHours > 0 &&  viewModel.fechaFin != null )
          );

      return FlatButton(
        color: Colors.white,
        child: Row(
          children: [
            Text("Siguiente"),
            Icon(Icons.chevron_right),
          ],
        ),
        onPressed: action ? (){
          _pageController.animateToPage(_index + 1, duration: Duration(milliseconds: 400 ), curve: Curves.easeOut);
        } : null
      );
    }else{
      return SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BaseWidget<IncidenciasViewModel>(
      model: IncidenciasViewModel(nominaService: Provider.of(context)),
      builder: (context, model, child) => Scaffold(
        appBar: AppBar(
          title: Text("Nueva incidencia"),
          centerTitle: false,
          leading: IconButton(
            icon: Icon(Icons.close,color: Colors.white,),
            onPressed: (){
              Navigator.of(context).pop(null);
            }
          ),
        ),
        body: _buildContent(),
        bottomNavigationBar: BottomAppBar(
          color: Colors.white,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              FlatButton(
                color: Colors.white,
                child: Row(
                  children: [
                    Icon(Icons.chevron_left),
                    Text("Anterior"),
                  ],
                ),
                onPressed: _index > 0 ? (){
                  _pageController.animateToPage(0, duration: Duration(milliseconds: 400 ), curve: Curves.easeOut);
                } : null
              ),
              _buildText(model),
              _buildBtnSiguiente(model)
            ],
          ),
        ),
      ),
    );
  }
}