import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/incidencia_model.dart';
import 'package:espacio_jumex/core/models/preevaluate_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/dateTime_formfield.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class IncidenciaAddFechaWidget extends StatefulWidget {
  IncidenciaAddFechaWidget({Key key}) : super(key: key);

  @override
  _IncidenciaFechaListWidgetState createState() => _IncidenciaFechaListWidgetState();
}

class _IncidenciaFechaListWidgetState extends State<IncidenciaAddFechaWidget> {
  final _formKey = GlobalKey<FormState>();

  ProgressDialog _progressDialog;

  @override
  void initState() { 
    super.initState();

    Future.microtask(() async{
      final viewModel = Provider.of<IncidenciasViewModel>(context);
      final userModel = Provider.of<UserModel>(context);

      viewModel.consultarIncidenciasCatalogo(userModel).then((value){
        util.unathorized(context, viewModel.status, ()=>null);
      });
    });
  }

  Widget buildBody(IncidenciasViewModel viewModel){
    if(viewModel.status == Status.busy){
      return UiHelper.progressIndicator;
    }else if(viewModel.status == Status.error){
      return Center(
        child: Text(viewModel.message)
      );
    }else{
      return ListView(
        padding: UiHelper.listItemPadding,
        children: <Widget>[
          Card(
            child: Column(
              children: <Widget>[
                _buildForm(viewModel),
              ],
            ),
          ),
          UiHelper.verticalSpaceSmall,
          ..._buildPreevaluate(viewModel)
        ],
      );
    }
  }

  Widget _buildForm(IncidenciasViewModel viewModel){
    final fecha = viewModel.fechaConsulta;
    final diferencia = fecha != null ? fecha.difference(DateTime.now()).inHours : 0;
    final addDias = (viewModel.incidencia?.maxDias ?? 0) == 0 ? 7 : viewModel.incidencia.maxDias;

    final inputs = <Widget>[
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: DropdownButtonFormField<IncidenciaValueModel>(
          isExpanded: true,
          items: viewModel.tipoIncidenciaList.map<DropdownMenuItem<IncidenciaValueModel>>((e) => DropdownMenuItem<IncidenciaValueModel>(
            child: new Text(e.texto, overflow: TextOverflow.ellipsis,),
            value: e
          )).toList(),
          value: viewModel.incidencia,
          decoration: InputDecoration(
            labelText: "Incidencia"
          ),
          validator: (value) => value == null || value.valor == "" ? "Selecciona una opción válida" : null,
          onChanged: (item){
            viewModel.setTipoIncidencia(item);
          },
        )
      ),
      Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: DateTimeField(
          mode: DateFieldPickerMode.date,
          dateFormat: viewModel.dateFormat,
          label: "Selecciona un día",
          firstDate: DateTime.now().add(Duration(days: -30)),
          lastDate: DateTime.now().add(Duration(days: -1)),
          onDateSelected: (value)=>_captureDate(viewModel, value), 
          selectedDate: viewModel.fechaConsulta,
          decoration: InputDecoration(
            suffixIcon: Icon(Icons.calendar_today),
            labelText: diferencia <= 0 ? "Fecha" : "De",
          ),
        )
      ),
      diferencia <= 0 ? SizedBox.shrink(): Padding(
        padding: UiHelper.compactFormItemsPadding,
        child: DateTimeField(
          mode: DateFieldPickerMode.date,
          dateFormat: viewModel.dateFormat,
          label: "Selecciona fecha fin",
          firstDate: viewModel.fechaConsulta,
          lastDate: viewModel.fechaConsulta.add(Duration(days: addDias)),
          selectedDate: viewModel.fechaFin,
          onDateSelected: (value)=>viewModel.setFechaFin(value),
          decoration: InputDecoration(
            suffixIcon: Icon(Icons.calendar_today),
            labelText: "A"
          ),
        )
      ),
      UiHelper.verticalSpaceSmall,
    ];

    final form = Container(
      margin: UiHelper.formItemsMargin,
      child: Center(
        child: Column(
          children: <Widget>[
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: inputs,
              )
            ),
          ],
        ),
      )
    );

    return form;
  }

  void _captureDate(IncidenciasViewModel viewModel, DateTime date) async{
    if(date != null){
      if(date.difference(DateTime.now()).inHours <=0 ){
        await _progressDialog.show();
        final success = await viewModel.consultaFechasPreevaluacion(Provider.of<UserModel>(context), date);
        await _progressDialog.hide();

        if(!success){
          util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
        }
      }else{
        viewModel.setFechaConsulta(date);
      }
    }
  }

  List<Widget> _buildPreevaluate(IncidenciasViewModel viewModel){
    final accesos = Provider.of<AccesosModel>(context);
    final granted = accesos.accesos.any((x)=>(x.rutaAcceso == RoutePath.IncidenciasAdd));

    final preevaluate = viewModel.preevaluate;
    final items = <Widget>[];

    if(preevaluate != null){

      final marcajes = preevaluate.map((x)=>_MarcajeItemWidget(
        marcajeModel: x.item, 
        selected: x.isSelected,
        canAddIncidencia: granted,
        onAddIncidencia: (){
          if(!viewModel.addFechaIncidencia(x.item)){
            util.showAlertPopup(context, "¡Atención!", viewModel.message);
          }
        },
      )).toList();
        
      if(marcajes.length == 0) items.add(Center(
        child: Text("No se encontraron fechas para justificar")
      ));
      else items.addAll(marcajes);
    }

    return items;
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Consultando");

    return Consumer<IncidenciasViewModel>(
      builder: (context, viewModel, child) => buildBody(viewModel),
    );
  }
}

class _MarcajeItemWidget extends StatelessWidget {
  final MarcajeModel marcajeModel;
  final bool canAddIncidencia;
  final bool selected;
  final VoidCallback onAddIncidencia;
  const _MarcajeItemWidget({Key key, this.marcajeModel, this.onAddIncidencia, this.canAddIncidencia, this.selected}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    final detalle = <Widget>[];

    detalle.addAll([
      Padding(
        padding: UiHelper.listFirstInternalItemPadding,
        child: Text("Horario: ${marcajeModel.entrada.substring(0,5)} - ${marcajeModel.salida.substring(0,5)}"),
      ),
      Padding(
        padding: UiHelper.listLastInternalItemPadding,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Text("Entrada: ${marcajeModel.marcaje_1}"),
            UiHelper.horizontalSpaceSmall,
            Text("Salida: ${marcajeModel.marcaje_2}")
          ],
        ),
      ),
    ]);

    final marcaje = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: UiHelper.listHeaderItemPaddingLarge,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              RichText(
                textScaleFactor: 1.1,
                text: TextSpan(
                  text: marcajeModel.dia,
                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                  children: [
                    TextSpan(
                      text: " ${marcajeModel.fecha}",
                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.normal),
                    )
                  ]
                )
              ),
            ],
          ),
        ),
        ...detalle
      ],
    );

    final btnIncidencia =  Align(
      child: FlatButton(
        onPressed: onAddIncidencia ,
        child: selected ? Text("- Quitar") :  Text("+ Agregar"),
      ),
      alignment: Alignment.topRight,
    );

    return ListItemWidget(
      child: canAddIncidencia ?  Stack(
        children: [
          marcaje
          ,btnIncidencia
        ]
      ) : marcaje
    );
  }
}