import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/incidenciasView_model.dart';
import 'package:espacio_jumex/ui/views/incidenciasList_widget.dart';
import 'package:espacio_jumex/ui/views/incidenciasPorAutorizar_widget.dart';
import 'package:espacio_jumex/ui/views/preevaluate_widget.dart';
import 'package:espacio_jumex/ui/widgets/bottomAppBar_widget.dart';
import 'package:flutter/foundation.dart';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PreevaluateView extends StatefulWidget{
  final int index;
  PreevaluateView({Key key, this.index = 0}) : super(key: key);

  @override
  State<StatefulWidget> createState() => new _PreevaluateViewState();
}

class _PreevaluateViewState extends State<PreevaluateView>{
  final _scaffoldKey = new GlobalKey<ScaffoldState>();

  PageController _pageController;
  int _index;

  @override
  void initState() { 
    super.initState();

    _index = widget.index;
    _pageController = new PageController(
      initialPage: _index
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    
    super.dispose();
  }

  void _showMessage(String text){
    if(text!=null && text.isNotEmpty){
      _scaffoldKey.currentState.showSnackBar(new SnackBar(content: Text(text),duration: new Duration(seconds: 2),));
    }
  }

  Widget _buildContent(bool granted){

    final views = <Widget>[
      PreevaluateWidget(
        key: PageStorageKey<int>(0)
      ),
      IncidenciasListWidget(
        key: PageStorageKey<int>(1)
      ),
    ];

    if(granted){
      views.add(
        IncidenciasPorAutorizarWidget(
          key: PageStorageKey<int>(2)
        ),
      );
    }

    return PageView(
      controller: _pageController,
      physics: NeverScrollableScrollPhysics(),
      onPageChanged: (index){
        setState(() {
          _index = index;
        });
      },
      children: views,
    );
  }

  
  List<BottomNavigationBarItem> _viewsButtons(bool granted){
    final itemsBottomBar = <BottomNavigationBarItem>[
      BottomNavigationBarItem(
        icon: Icon(Icons.person_outline),
        label: "Pre evalúate",
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.list),
        label: "Incidencias"
      ),
      
    ];

    if(granted){
      itemsBottomBar.add(BottomNavigationBarItem(
        icon: Icon(Icons.save_alt), 
        label: "Autorizar",
      ),);
    }
    
    return itemsBottomBar;
  }

  @override
  Widget build(BuildContext context) {

    final accesos = Provider.of<AccesosModel>(context);
    final granted = accesos.accesos.any((x)=> x.rutaAcceso == RoutePath.IncidenciasAdd && x.bitAcceso == 1);

    return BaseWidget<IncidenciasViewModel>(
      model: IncidenciasViewModel(nominaService: Provider.of(context)),
      builder: (context,model,child)=>Scaffold(
        key: _scaffoldKey,
        appBar: new AppBar(
          centerTitle: false,
          title: const Text("Pre evalúate"),
        ),
        body: _buildContent(granted),
        floatingActionButton: !granted || _index > 1 ? null : FloatingActionButton.extended(
          label: Text("Incidencia"),
          icon: Icon(Icons.add),
          onPressed: () => Navigator.of(context).pushNamed(RoutePath.IncidenciasAdd)
            .then((value){
              _showMessage(value);
                if(_index == 1){
                  Future.delayed(Duration(milliseconds: 300),()=>model.consultaIncidencias(Provider.of(context), true, true));
                }
            }),
        ),
        bottomNavigationBar: BottomAppBarWidget(
          items: _viewsButtons(granted),
          onTap: (index){
            _pageController.animateToPage(index,duration: new Duration(milliseconds: 500),curve: Curves.easeInOut );
          },
          currentIndex: _index,
        ),
      ),
    );
  }
}