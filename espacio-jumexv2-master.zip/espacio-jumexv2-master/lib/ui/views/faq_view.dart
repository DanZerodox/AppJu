
import 'package:espacio_jumex/core/models/faq_model.dart';
import 'package:flutter/material.dart';

class FAQView extends StatelessWidget {
  static TextStyle textStyle;
  final TextStyle detailStyle = TextStyle(fontStyle: FontStyle.italic);
  final FAQModel _faqModel;

  FAQView({
    @required FAQModel faqModel
  }): assert(faqModel != null),
   _faqModel = faqModel;

  Widget _buildTiles(FAQModel root,[int level = 0]) {
    if (root.respuesta == null || root.respuesta.isEmpty)
      return ListTile(
        title: Text(root.pregunta,style: detailStyle,),
      );

    return ExpansionTile(
      title: level == 0 ? Text(root.pregunta,style: textStyle) : Text(root.pregunta),
      initiallyExpanded: true,
      children: root.respuesta.map((item)=>_buildTiles(item,++level)).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: false,
          title: Text("Preguntas frecuentes"),
        ),
        body: Container(
          padding: EdgeInsets.only(top: 16.0),
          child: ListView.builder(
              itemCount: _faqModel.respuesta.length,
              itemBuilder: (BuildContext context, int index) => _buildTiles(_faqModel.respuesta[index])
          )
        )
    );
  }
}