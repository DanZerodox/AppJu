import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/photoItem_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:espacio_jumex/ui/views/photoGalery_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TarjetaCumpleaniosView extends StatelessWidget {
  final String tempId;
  const TarjetaCumpleaniosView({Key key,this.tempId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserModel>(context);

    return PhotoGaleryView(
      backgroundColor: Colors.transparent,
      photos: <PhotoItemModel>[
        PhotoItemModel(
          id: user.usuario.toString(),
          type: MediaType.image,
          url: "${ApiConstant.apiEndpoint}/User/imagenCumpleanios/${user.usuario}?tempid=$tempId"
        )
      ],
    );
  }
}