import 'dart:ui';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' show isNullOrEmpty;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/appView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/cachedImage_widget.dart';
import 'package:espacio_jumex/ui/widgets/menuGrid_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MenuHomeWidget extends StatelessWidget {
  final bool editing;
  final Status status;
  const MenuHomeWidget({Key key, this.editing = false, this.status}) : super(key: key);

  Widget _buildMenu(BuildContext context, AppViewModel viewModel) {
    final textStyle = Theme.of(context).textTheme.headline6.copyWith(color: Colors.white, fontSize: 16.0);

    final accesosModel = Provider.of<AccesosModel>(context);

    if (accesosModel == null) return SizedBox.shrink();

    final accesoPrincipal = accesosModel.accesos.firstWhere((element) => element.rutaAcceso == RoutePath.Landing);

    final menu = [
      ..._buildAccesosMenuList(accesosModel.accesos, AccesoOrdenType.prior, Color(0xffe85513), textStyle, accesoPrincipal),
      ..._buildAccesosMenuList(accesosModel.accesos, AccesoOrdenType.organizational, Colors.blue[600], textStyle, accesoPrincipal),
      ..._buildAccesosMenuList(accesosModel.accesos, AccesoOrdenType.payroll, Colors.green[400], textStyle, accesoPrincipal),
      ..._buildAccesosMenuList(accesosModel.accesos, AccesoOrdenType.minor, Colors.indigo[300], textStyle, accesoPrincipal),
    ];

    final menuItems = [...menu.map((x) => x.item).toList()];

    return MenuGridWidget(
      editing: editing,
      items: menuItems,
      onTap: (index) {
        var item = menu[index];
        if (item.route == RoutePath.AccesoExterno)
          Navigator.of(context).pushNamed(item.route, arguments: item.idAcceso);
        else if (item.route == RoutePath.ContenidoExterno) {
          var access = accesosModel.accesos.firstWhere((e) => e.idAcceso == item.idAcceso);
          Navigator.of(context).pushNamed(item.route, arguments: access);
        } else
          Navigator.of(context).pushNamed(item.route);
      },
      onChangeVisible: (index, visible) {
        var item = menu[index];
        viewModel.actualizaAcceso(accesosModel, item.idAcceso, visible);
      },
    );
  }

  List<_MenuItem> _buildAccesosMenuList(List<AccesoModel> accesos, AccesoOrdenType orden, Color color, TextStyle textStyle, AccesoModel accesoModel) {
    return accesos
        .where((x) => x.orden == orden && x.idAccesoPadre == accesoModel.idAcceso && x.bitAcceso == 1 && (editing || x.bitVisible == 1))
        .map((f) => _MenuItem(
            route: f.rutaAcceso,
            idAcceso: f.idAcceso,
            item: MenuGridItem(
                visible: f.bitVisible == 1,
                backgroundColor: color,
                widget: (f.iconCover & 2) == 0
                    ? MenuItemWidget(
                        title: Text(
                          f.nombreAcceso,
                          style: textStyle,
                        ),
                        icon: isNullOrEmpty(f.appIcon)
                            ? Image.asset(
                                "assets/images/espaciojumex_light.png",
                                fit: BoxFit.fill,
                              )
                            : CachedImageWidget(
                                fit: BoxFit.fill,
                                url: "${ApiConstant.apiServer}/Content/img/app/${f.appIcon}",
                                errorWidget: (_, __, ___) => Center(
                                  child: Icon(Icons.broken_image),
                                ),
                              ),
                      )
                    : MenuItemWidgetFit(
                        icon: isNullOrEmpty(f.appIcon)
                            ? Image.asset(
                                "assets/images/espaciojumex_light.png",
                                fit: BoxFit.fill,
                              )
                            : CachedImageWidget(
                                fit: BoxFit.fill,
                                url: "${ApiConstant.apiServer}/Content/img/app/${f.appIcon}",
                                errorWidget: (_, __, ___) => Center(
                                  child: Icon(Icons.broken_image),
                                ),
                              )))))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppViewModel>(builder: (context, appModel, child) => status == Status.busy ? UiHelper.progressIndicator : _buildMenu(context, appModel));
  }
}

class _MenuItem {
  final MenuGridItem item;
  final String route;
  final int idAcceso;

  const _MenuItem({this.item, this.route, this.idAcceso});
}
