import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/view/userView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class ContraseniaView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ContraseniaState();
}

class _ContraseniaState extends State<ContraseniaView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  static final _formKey = GlobalKey<FormState>();
  TextEditingController _passwordController;
  TextEditingController _nuevoPasswordController;
  TextEditingController _confirmaPasswordController;

  final _contraseniaAnt = FocusNode();
  final _contraseniaNueva = FocusNode();
  final _contraseniaConfirmacion = FocusNode();

  bool _hidePassword = true;
  bool _hideNewPassword = true;

  String _password;
  String _nuevoPassword;

  ProgressDialog _progressDialog;

  @override
  void initState() {
    super.initState();

    _passwordController = new TextEditingController();
    _nuevoPasswordController = new TextEditingController();
    _confirmaPasswordController = new TextEditingController();

    _passwordController.addListener(() {
      _password = _passwordController.text;
    });
    _nuevoPasswordController.addListener(() {
      _nuevoPassword = _nuevoPasswordController.text;
    });
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _nuevoPasswordController.dispose();
    _confirmaPasswordController.dispose();
    super.dispose();
  }

  Widget _buildForm(UserViewModel model) {
    final padding = UiHelper.formItemsPadding;

    return Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            new Padding(
              padding: padding,
              child: TextFormField(
                decoration: InputDecoration(
                    labelText: "Contraseña actual",
                    suffixIcon: new IconButton(
                      icon: const Icon(Icons.remove_red_eye),
                      onPressed: () {
                        setState(() => _hidePassword = !_hidePassword);
                      },
                    )),
                obscureText: _hidePassword,
                autocorrect: false,
                controller: _passwordController,
                validator: (val) {
                  if (util.isNullOrEmpty(val)) {
                    return "El valor es requerido";
                  }
                  return null;
                },
                focusNode: _contraseniaAnt,
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) {
                  _contraseniaAnt.unfocus();
                  FocusScope.of(context).requestFocus(_contraseniaNueva);
                },
              ),
            ),
            new Padding(
              padding: padding,
              child: TextFormField(
                decoration: InputDecoration(
                    labelText: "Contraseña nueva",
                    suffixIcon: new IconButton(
                      icon: const Icon(Icons.remove_red_eye),
                      onPressed: () {
                        setState(() => _hideNewPassword = !_hideNewPassword);
                      },
                    )),
                autocorrect: false,
                obscureText: _hideNewPassword,
                controller: _nuevoPasswordController,
                validator: (val) {
                  if (util.isNullOrEmpty(val)) {
                    return "El valor es requerido";
                  } else if (val == _password) {
                    return "La contraseña no puede ser igual a la anterior";
                  }
                  return null;
                },
                textInputAction: TextInputAction.next,
                focusNode: _contraseniaNueva,
                onFieldSubmitted: (_) {
                  _contraseniaNueva.unfocus();
                  FocusScope.of(context).requestFocus(_contraseniaConfirmacion);
                },
              ),
            ),
            new Padding(
              padding: padding,
              child: TextFormField(
                decoration: InputDecoration(labelText: "Confirmar contraseña"),
                obscureText: true,
                autocorrect: false,
                controller: _confirmaPasswordController,
                validator: (val) {
                  if (util.isNullOrEmpty(val)) {
                    return "El valor es requerido";
                  } else if (val != _nuevoPassword) {
                    return "No coincide la nueva contraseña";
                  }
                  return null;
                },
                focusNode: _contraseniaConfirmacion,
                onFieldSubmitted: (_) {
                  _contraseniaConfirmacion.unfocus();
                  _submit(model);
                },
              ),
            )
          ],
        ));
  }

  Widget _buildSubmitButton(UserViewModel viewModel) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Actualizar",
        onSubmit: () {
          _submit(viewModel);
        },
      ),
    );
  }

  void _submit(UserViewModel viewModel) async {
    FocusScope.of(context).requestFocus(new FocusNode());
    final user = Provider.of<UserModel>(context);

    final formState = _formKey.currentState;
    if (formState.validate()) {
      formState.save();

      await _progressDialog.show();
      final success = await viewModel.updatePassword(user, _password, _nuevoPassword);
      await _progressDialog.hide();

      if (success) {
        await _showAprobeDialog();
        Navigator.of(context).pushNamedAndRemoveUntil(RoutePath.Login, (_) => false);
      } else {
        util.unathorized(context, viewModel.status, () => util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }
    }
  }

  Future<bool> _showAprobeDialog() async {
    return await showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return ClipRect(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(32.0))),
              title: Text("Contraseña actualizada"),
              content: Text("Se ha actualizado la contraseña. Será necesario volver ingresar tus credenciales."),
              actions: <Widget>[
                FlatButton(
                  child: Text("Continuar"),
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ],
            ),
          ]));
        });
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Validando");

    return BaseWidget<UserViewModel>(
      model: UserViewModel(userService: Provider.of(context), firebaseMessagingService: Provider.of(context)),
      builder: (context, model, child) => Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          title: const Text("Actualizar contraseña"),
          centerTitle: false,
          leading: IconButton(
            icon: Icon(Icons.close),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        body: new ListView(
          padding: UiHelper.listItemPadding,
          children: <Widget>[
            Card(
                child: new Column(
              children: <Widget>[_buildForm(model), _buildSubmitButton(model)],
            ))
          ],
        ),
      ),
    );
  }
}
