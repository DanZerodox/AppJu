import 'package:espacio_jumex/ui/widgets/dateTime_formfield.dart';
import 'package:intl/intl.dart';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class BuzonCapView extends StatefulWidget {
  BuzonCapView({Key key}) : super(key: key);

  @override
  _BuzonCapViewState createState() => _BuzonCapViewState();
}

class _BuzonCapViewState extends State<BuzonCapView> {

  final _formatter = DateFormat(Constants.dateFormat);
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();

  final _emailController = new TextEditingController();
  final _observacionesController = new TextEditingController();

  ProgressDialog _progressDialog;
  String _incidencia = '';
  String _fechaInicio = '';
  String _fechaFin = '';
  String _observaciones = '';
  String _email = '';

  final _incidenciaList = [
    DropdownMenuItem(child: new Text("Seleccionar"), value: "")
    ,DropdownMenuItem(child: new Text("0101 Permiso sin goce de sueldo"), value: "0101 Permiso sin goce de sueldo")
    ,DropdownMenuItem(child: new Text("0200 Vacaciones"), value: "0200 Vacaciones")
    ,DropdownMenuItem(child: new Text("0250 Descuento por horas"), value: "0250 Descuento por horas")
    ,DropdownMenuItem(child: new Text("0255 Desc. en horas por comida"), value: "0255 Desc. en horas por comida")
    ,DropdownMenuItem(child: new Text("0260 Curso"), value: "0260 Curso")
    ,DropdownMenuItem(child: new Text("0261 Curso por horas"), value: "0261 Curso por horas")
    ,DropdownMenuItem(child: new Text("0300 Falta injustificada"), value: "0300 Falta injustificada")
    ,DropdownMenuItem(child: new Text("0301 Permiso por matrimonio"), value: "0301 Permiso por matrimonio")
    ,DropdownMenuItem(child: new Text("0302 Defunción padre"), value: "0302 Defunción padre")
    ,DropdownMenuItem(child: new Text("0303 Permiso por alumbramiento"), value: "0303 Permiso por alumbramiento")
    ,DropdownMenuItem(child: new Text("0304 Defunción madre"), value: "0304 Defunción madre")
    ,DropdownMenuItem(child: new Text("0305 Defunción esposo (a)"), value: "0305 Defunción esposo (a)")
    ,DropdownMenuItem(child: new Text("0306 Defunción hijo (a)"), value: "0306 Defunción hijo (a)")
    ,DropdownMenuItem(child: new Text("0400 Suspensiones"), value: "0400 Suspensiones")
    ,DropdownMenuItem(child: new Text("0402 Asunto sindical"), value: "0402 Asunto sindical")
    ,DropdownMenuItem(child: new Text("0602 Lactancia"), value: "0602 Lactancia")
    ,DropdownMenuItem(child: new Text("0701 Asunto de trabajo"), value: "0701 Asunto de trabajo")
    ,DropdownMenuItem(child: new Text("0702 Asunto de trabajo por horas"), value: "0702 Asunto de trabajo por horas"),
  ];

  @override
  void initState() { 
    super.initState();

    Future.microtask((){
      var userModel = Provider.of<UserModel>(context);
      setState(() {
        _emailController.text = userModel.correo;
      });      
    });

    _emailController.addListener(() { 
        _email = _emailController.text;
    });

    _observacionesController.addListener(() {
      _observaciones = _observacionesController.text;
    });
  }

  @override
  void dispose() { 
    _emailController.dispose();
    _observacionesController.dispose();

    super.dispose();
  }

  Widget _buildForm(NominaViewModel viewModel){
    var userModel = Provider.of<UserModel>(context);

    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: DropdownButtonFormField<String>(
              isExpanded: true,
              items: _incidenciaList,
              value: _incidencia,
              decoration: InputDecoration(
                labelText: "Incidencia"
              ),
              validator: (value) => value == null || value == "" ? "Selecciona una opción válida" : null,
              onChanged: (item){
                setState(() {
                  _incidencia = item;
                });
              },
            )
          ),
          Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: new TextFormField(
              enabled: (userModel.correo ?? '').isEmpty ,
              controller: _emailController,
              validator: (val) => val.isEmpty ? "Debes ingresar un correo de contacto" : null,
              decoration: InputDecoration(
                labelText: "Correo de contacto",
                helperText: 'Escribe un correo de contacto'
              )
            )
          ),   
          Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: DateTimeFormField(
              mode: DateFieldPickerMode.date,
              dateFormat: _formatter,
              label: "Ingresar fecha inicial",
              validator: (value)=>value == null  ? "Indicar una fecha válida" : null,
              firstDate: DateTime.now().add(Duration(days: -24)),
              lastDate: DateTime.now().add(Duration(days: 1)),
              onDateSelected: (value){
                setState(() {
                  _fechaInicio = _formatter.format(value);
                });
              },
              decoration: InputDecoration(
                suffixIcon: Icon(Icons.calendar_today),
                labelText: "Fecha inicial"
              ),
            ),
          ),
          _fechaInicio.isEmpty ? SizedBox()
          :Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: DateTimeFormField(
              mode: DateFieldPickerMode.date,
              dateFormat: _formatter,
              label: "Ingresar fecha fin",
              validator: (value)=>value == null  ? "Indicar una fecha válida" : null,
              firstDate: _formatter.parse(_fechaInicio),
              lastDate: DateTime.now().add(Duration(days: 7)),
              onDateSelected: (value){
                _fechaFin = _formatter.format(value);
              },
              decoration: InputDecoration(
                suffixIcon: Icon(Icons.calendar_today),
                labelText: "Fecha fin"
              ),
            ),
          ),
          Padding(
            padding: UiHelper.formItemsPadding,
            child: TextFormField(
              controller: _observacionesController,
              maxLines: null,
              keyboardType: TextInputType.multiline,
              decoration: InputDecoration(
                  labelText: 'Comentarios',
                  hintText: 'Agrega aquí tus comentarios',
              )
            ),
          ),
        ],
      )
    );
  }

  Widget _buildSubmitButton(NominaViewModel viewModel){
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Enviar",
        onSubmit: (){
          FocusScope.of(context).requestFocus(FocusNode());
          _submit(viewModel);
        },
      ),
    );
  }

  void _submit(NominaViewModel viewModel) async{
    final formState = _formKey.currentState;
    if(formState.validate()){
      formState.save();

      await _progressDialog.show();
      final success = await viewModel.enviarIncidenciaCAP(Provider.of<UserModel>(context),_incidencia, _fechaInicio, _fechaFin, _observaciones, _email);
      await _progressDialog.hide();
      
      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop("Solicitud enviada");
      }

    }
  }

  @override
  Widget build(BuildContext context) {

    _progressDialog = util.progressDialogBuilder(context,"Enviando incidencia");

    return Scaffold(
      key: _scaffoldKey,
      appBar: new AppBar(
        title: Text("Buzón CAP"),
        centerTitle: false,
      ),
      body: BaseWidget<NominaViewModel>(
        model: new NominaViewModel(nominaService: Provider.of(context)),
        builder: (context, model, child) => ListView(
          padding:  UiHelper.listItemPadding,
          children: <Widget>[
            Card(
              child: Column(
                children: <Widget>[
                  _buildForm(model),
                  _buildSubmitButton(model)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}