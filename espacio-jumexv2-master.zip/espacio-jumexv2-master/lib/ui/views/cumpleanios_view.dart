import 'package:animate_do/animate_do.dart';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/selectableItem.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/userView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/cumpleaniosSearch_delegate.dart';
import 'package:espacio_jumex/ui/views/cumpleaniosItem_widget.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CumpleaniosView extends StatelessWidget {
  const CumpleaniosView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseWidget<UserViewModel>(
       model: UserViewModel(userService: Provider.of(context)),
       builder: (context, model, child) => CumpleaniosWidget(),
    );
  }
}

class CumpleaniosWidget extends StatefulWidget{
  CumpleaniosWidget({Key key});

  @override
  State<StatefulWidget> createState() => CumpleaniosWidgetState();
}

class CumpleaniosWidgetState extends State<CumpleaniosWidget> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  
  String _query;

  @override
  void initState() {
    Future.microtask((){
      final model = Provider.of<UserViewModel>(context);

      model.consultaCumpleanios(Provider.of<UserModel>(context))
        .then((value){
            util.unathorized(context, model.status,()=>null);
        });
    });
    super.initState();
  }

  void _showMessage(String text){
    if(text!=null && text.isNotEmpty)
      _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(text),duration: new Duration(seconds: 2), ));
  }

  Widget _buildBody(UserViewModel viewModel){

    if(viewModel.status == Status.busy){
      return UiHelper.progressIndicator;
    }
    if(viewModel.status == Status.error){
      return Center(
        child: Text(viewModel.message),
      );
    }
    return CustomScrollView(
      physics: AlwaysScrollableScrollPhysics(),
      scrollDirection: Axis.vertical,
      slivers: <Widget>[
          _buildSelectedList(viewModel),
          _unselectedList(viewModel)
      ],
    );
  }

  SliverList _unselectedList(UserViewModel viewModel){

    var items = viewModel.colaboradores
      .where((e) => !e.isSelected  &&   (_query == null || _query.isEmpty || (_query.isNotEmpty && _query.contains(e.item.nombre)))).toList();

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context,index){
          final iitem = items[index];
          final item = iitem.item;
          
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: CumpleaniosItemWidget(
              fecha: item.fecha,
              localidad: item.localidad,
              nombre: item.nombre,
              hasMobile: item.hasMobile,
              onTap: (){
                _query = null;
                viewModel.selectColaborador(item);
              },
            )
          );
        },
        childCount: items?.length ?? 0,
      )
    ); 
  }

  SliverGrid _buildSelectedList(UserViewModel viewModel){
    var items = viewModel.colaboradores?.where((e) => e.isSelected)?.toList();

    return SliverGrid(
      delegate: SliverChildBuilderDelegate(
        (context,index){
          return _selectedListItem(items[index]);
        },
        childCount: items?.length ?? 0,
      ), 
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 5/2
      ),
    );
  }

  Widget _selectedListItem(SelectableItem<ColaboradorModel> colaborador){
    var item = colaborador.item;

   return ListItemWidget(
      margin: EdgeInsets.symmetric(horizontal: 5.0),
      boxDecoration: const BoxDecoration(
        color: Colors.white,
        border: const Border(
          bottom: const BorderSide(
            color: UiHelper.colorHorizontalDivider,
          ),
          right: const BorderSide(
            color: UiHelper.colorHorizontalDivider,
          ),
        )
      ),
      child: SizedBox(
        width: 180,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            IconButton(
              icon: Icon(Icons.cancel, size: 20,), 
              onPressed:(){
                setState(() {
                  colaborador.isSelected = false;
                });
              },
              color: Colors.red,
            ),
            Flexible(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(item.nombre,style: TextStyle(fontSize: 12), textAlign: TextAlign.left,),
                  UiHelper.verticalSpaceXSmall,
                  Text(item.localidad ?? "--",textScaleFactor: 0.8,style: TextStyle(fontStyle: FontStyle.italic)),
                ],
              )
            )
          ],
        ),
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<UserViewModel>(context);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Cumpleaños"),
        centerTitle: false,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.search), onPressed: () async{
            final result = await showSearch<String>(context: context,
              delegate: CumpleaniosSearchDelegate(
                list: viewModel.colaboradores,
              )
            );
            setState(() {
              _query = result;
            });
            
          })
        ],
      ),
      body: _buildBody(viewModel),
      floatingActionButton: !viewModel.colaboradores.any((e) => e.isSelected) ? null : 
      ElasticIn(
        animate: true,
        child: FloatingActionButton(
        child: Stack(
          children: [
            Positioned(child: Icon(
              Icons.cake
            ),left: 12,top: 15,),
            Positioned(child: Container(
              child: Text("+${viewModel.colaboradores.where((e) => e.isSelected).length}", style: TextStyle(fontSize: 12.0),),
            ),right: 5, top: 15,)
          ],
        ),
        onPressed: ()  async{
          Navigator.of(context).pushNamed(RoutePath.CumpleaniosMensaje,arguments: viewModel.colaboradores.where((e) => e.isSelected).map((e) => e.item).toList())
             .then((value){
              _showMessage(value);

              if(!util.isNullOrEmpty(value)){
                Future.delayed(Duration(seconds: 2),(){
                  viewModel.resetSelectedColaboradores();
                });
              }
              
             });
        }
      ),
      ),
    );
  }
}