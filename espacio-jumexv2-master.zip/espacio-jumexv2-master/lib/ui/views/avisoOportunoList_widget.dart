import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/services/uploader_service.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/yammerView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/avisoOportunoItem_view.dart';
import 'package:espacio_jumex/ui/views/prestaciones_widget.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class AvisoOportunoListWidget extends StatelessWidget {
  static const yammerId = YammerConstant.yammerAvisoOportunoId;

  const AvisoOportunoListWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
        
    final acceso = Provider.of<AccesosModel>(context).accesos.firstWhere((x)=>x.rutaAcceso == RoutePath.AvisoOportuno);
    
    return PrestacionesWidget(
      yammerId: yammerId,
      accesoModel: acceso,
      onTap: (model){
        Navigator.of(context).push(new MaterialPageRoute(
          settings: RouteSettings(
            name: "YammerDetail"
          ),
          builder: (contx)=>new AvisoOportunoItemView( yammerModel: model, ))
        );
      },
    ); 
  }
}

class AvisoOportunoMyListWidget extends StatefulWidget {
  const AvisoOportunoMyListWidget({Key key}) : super(key: key);

  @override
  _AvisoOportunoMyListWidgetState createState() => _AvisoOportunoMyListWidgetState();
}

class _AvisoOportunoMyListWidgetState extends State<AvisoOportunoMyListWidget> {

  ProgressDialog _progressDialog;

  @override
  void initState() {
    Future.microtask((){
      final user = Provider.of<UserModel>(context);
      Provider.of<YammerViewModel>(context).consultaMisPublicaciones(user);
    });

    super.initState();
  }

  void _eliminarPublicacion(YammerViewModel viewModel, YammerMessagesModel yammerMessagesModel) async{
    _progressDialog.update(message: "Eliminando anuncio");
    _ejecutarAccion(viewModel, yammerMessagesModel);
  }

  void _solicitarBajaPublicacion(YammerViewModel viewModel, YammerMessagesModel yammerMessagesModel) async{
    _progressDialog.update(message: "Solitando la baja del anuncio");
    _ejecutarAccion(viewModel, yammerMessagesModel);
  }

  void _ejecutarAccion(YammerViewModel viewModel, YammerMessagesModel yammerMessagesModel) async{
    final user= Provider.of<UserModel>(context);

    await _progressDialog.show();
    final success = await viewModel.eliminarPublicacion(user, yammerMessagesModel);
    await _progressDialog.hide();

     if(!success){
       util.unathorized(context, viewModel.status, ()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
     }
  }

  List<SliverList> _buildSlivers(YammerViewModel model, UploadTask task){
    var slivers = <SliverList>[];

    if(task != null && !model.avisos.any((e)=> e.titulo == task.title)){
      slivers.add(_buildUpload(task));
    }

    slivers.add(_buildAvisos(model));

    return slivers;
  }

  SliverList _buildUpload(UploadTask task){
    return new SliverList(
      delegate: new SliverChildListDelegate(<Widget>[
        new Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: new ListItemWidget(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: ListTile(
                    title: Text("${task.title ?? "--"}"),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        UiHelper.verticalSpaceSmall,
                        Flexible(child: Text("Estado: ${task.status == Status.busy ? "Publicando" : task.status == Status.free ? "En espera" : "Error"}")),
                        UiHelper.verticalSpaceSmall,
                        task.status == Status.busy ? UiHelper.linearProgressIndicator : UiHelper.verticalSpaceXSmall,
                      ],
                    ),
                  )
                )
              ],
            ),
          ),
        )
      ])
    );
  }

  SliverList _buildAvisos(YammerViewModel model){
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context,index){    
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: ListItemWidget(
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => AvisoOportunoItemView(
                    contact: false,
                    yammerModel: new YammerModel(
                      id: model.avisos[index].messageId
                    ),
                  )
                ));
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: ListTile(
                      trailing: Icon(Icons.arrow_right),
                      title: Text("${model.avisos[index].titulo ?? "--"}"),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          UiHelper.verticalSpaceSmall,
                          Flexible(child: Text("Estado: ${model.avisos[index].estatusDesc}")),
                          UiHelper.verticalSpaceSmall,
                          Flexible(child: Text("Fecha de publicación: ${model.avisos[index].fecha ?? "--"}")),
                          UiHelper.verticalSpaceXSmall,
                        ],
                      ),
                    )
                  ),
                  _buildButton(model, model.avisos[index])
                ],
              ),
            )
          );
        },
        childCount: model.avisos?.length ?? 0,
      )
    );
  }

  Widget _buildButton(YammerViewModel model, YammerMessagesModel aviso){
    if(aviso.estatus == "INIT"){
      return Container(
        margin: EdgeInsets.only(left: 5),
        child: FlatButton(
          child: Text("Eliminar"),
          onPressed:()=>_eliminarPublicacion(model,aviso)
        ),
      );
    }
    else if(aviso.estatus == "PUB"){
      return Container(
        margin: EdgeInsets.only(left: 5),
        child: FlatButton(
          child: Text("Solicitar baja"),
          onPressed:()=>_solicitarBajaPublicacion(model,aviso)
        ),
      );
    }
    else{
      return UiHelper.verticalSpaceXSmall;
    }
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Eliminando");

    return Consumer2<YammerViewModel, UploadTask>(
      child: Center(child: Text("No hay avisos"),),
      builder: (context, yammerModel, taskModel, child){
        if(yammerModel.status == Status.error) return Center(child: Text(yammerModel.message));
        //if(yammerModel.status == Status.busy) return UiHelper.progressIndicator;
        else if((yammerModel.avisos?.length ?? 0) == 0 && taskModel == null) return child;
        else return RefreshIndicator(
          child: CustomScrollView(
            slivers: _buildSlivers(yammerModel, taskModel),
          ),
          onRefresh: ()=>yammerModel.consultaMisPublicaciones(Provider.of<UserModel>(context)),
        );
      }
    );
  }
}