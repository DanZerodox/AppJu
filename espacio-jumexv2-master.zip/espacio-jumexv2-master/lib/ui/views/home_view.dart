import 'dart:ui';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/appView_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/userView_model.dart';
import 'package:espacio_jumex/ui/views/ajustes_view.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/views/menuHome_widget.dart';
import 'package:espacio_jumex/ui/views/notificaciones_view.dart';
import 'package:espacio_jumex/ui/widgets/bottomAppBar_widget.dart';
import 'package:espacio_jumex/ui/widgets/buttonNotification_widget.dart';
import 'package:espacio_jumex/ui/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class PreHomeWidget extends StatelessWidget {
  final int index;

  const PreHomeWidget({Key key, this.index}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var pageSize = MediaQuery.of(context).size;

    return BaseWidget<UserViewModel>(
      model: UserViewModel(
        userService: Provider.of(context),
        localdbService: Provider.of(context),
        firebaseMessagingService: Provider.of(context)
      ),
      onModelReady: (model){
        model.fetchSession().then((success){
          if(success){
            if(model.userModel.avisoLegal>0){
              Navigator.pushReplacementNamed(context, RoutePath.AvisoLegal);
            }
          }else{
            Navigator.pushReplacementNamed(context, RoutePath.Login, arguments: model.message);
          }
        });
      },
      builder: (context, model,child)=> model.status == Status.busy ? 
        Scaffold(
          body: LoadingWidget(size: pageSize,),
        )
      : HomeView(index: index, status: model.status)
    );
  }
}

class HomeView extends StatefulWidget{
  final int index;
  final Status status;

  HomeView({this.index, this.status = Status.free});

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _durationChangePage = 500;

  PageController _pageController;
  bool _editing = false;
  int _page = 0;

  @override
  void initState() { 
    _page = widget.index;
    _pageController = PageController(initialPage: _page);

    super.initState();
  }

  @override
  void dispose() { 
    _pageController.dispose();

    super.dispose();
  }

  void _onTapBarItem(int index){
    if(!_editing && index<3){
      _pageController.animateToPage(index, duration: Duration(milliseconds: _durationChangePage), curve: Curves.easeInOut);
    }else if(_page == 0 && index == 3){
      setState(() {
        _editing = !_editing;
      });
    }
  }

  Widget _buildColaboradorHomeWidget(TextStyle textStyle){

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        centerTitle: false,
        title: Text("Espacio Jumex",style: textStyle),
        leading: null,
      ),
      bottomNavigationBar: BottomAppBarWidget(
        type: BottomNavigationBarType.fixed,
        currentIndex: _page,
        onTap: _onTapBarItem,
        selectedFontSize: 12.0,
        unselectedFontSize: 11.0,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            label: "Inicio",
            icon: Icon(Icons.home),
          ),
          BottomNavigationBarItem(
            label: "Ajustes",
            icon: Icon(Icons.settings)
          ),
          BottomNavigationBarItem(
            label: "Notificaciones",
            icon: ButtonNotificationWidget(
              icon: Icons.notifications_none,
            ),
          ) ,
          BottomNavigationBarItem(
            label: "Personalizar",
            icon: AnimatedSwitcher(
              duration: Duration(milliseconds: 800),
              child: _editing ? Icon(Icons.check) : Icon(Icons.more_vert),
              transitionBuilder: (child, animation)=>ScaleTransition(
                child: child,
                scale: animation,
              ),
            ) 
          )
        ],
      ),
      body: PageView(
        controller: _pageController,
        physics: !_editing ? BouncingScrollPhysics() : NeverScrollableScrollPhysics(),
        onPageChanged: (index){
          setState(() {
            _page = index;
          });
        },
        children: <Widget>[
          MenuHomeWidget( editing: _editing, status: widget.status),
          AjustesWidget( status: widget.status),
          NotificacionesWidget(),
        ],
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    final styleTitle = Theme.of(context).textTheme.headline6.copyWith(color: Colors.white);

    return WillPopScope(
      onWillPop: (){
        return showDialog(
          context: context,
          builder: (context){
            return AlertDialog(
              title: Text('¡Atención!'),
              content: Text('¿Deseas salir de Espacio Jumex?'),
              actions: <Widget>[
                FlatButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: Text('No'),
                ),
                FlatButton(
                  onPressed: (){
                    Navigator.of(context).pop(true);
                  },
                  child: Text('Si'),
                )
              ],
            );
          },
        ) ??
        false;
      },
      child: BaseWidget<AppViewModel>(
        model: AppViewModel(
          firebaseMessagingService: Provider.of(context),
          nominaService: Provider.of(context), 
          localdbService: Provider.of(context), 
          userService: Provider.of(context),
          applicationService: Provider.of(context)
        ),
        child: _buildColaboradorHomeWidget(styleTitle),
        builder: (context,model,c)=>c,
      )
    );
  }
}