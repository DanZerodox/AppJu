part of 'package:espacio_jumex/ui/views/messageList_widget.dart';

class MessageAction{
  final int _value;
  get value => _value;

  const MessageAction._internal(this._value);

  get hashCode => _value;
  operator ==(status) => status._value == this._value;
  toString() => 'MessageAction($_value)';

  static MessageAction from(int value) => MessageAction._internal(value);

  static const refresh = const MessageAction._internal(0);
  static const more = const MessageAction._internal(1);
}