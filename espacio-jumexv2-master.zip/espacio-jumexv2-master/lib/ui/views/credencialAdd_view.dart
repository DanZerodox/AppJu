import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/nominaView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/base_widget.dart';
import 'package:espacio_jumex/ui/widgets/submitButton_widget.dart';
import 'package:flutter/material.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';


class CredencialAddView extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _CredencialAddView();
}

class _CredencialAddView extends State<CredencialAddView>{
  final _scaffoldKey = new GlobalKey<ScaffoldState>();
  final _formKey = new GlobalKey<FormState>();
  final _datosCorregirControler = new TextEditingController();

  final _motivoList = [
    new DropdownMenuItem(child: new Text("Desgaste"),value: "Desgaste",),
    new DropdownMenuItem(child: new Text("Extravío o robo *"),value: "Extravío o robo *",),
    new DropdownMenuItem(child: new Text("Rota, fisura o doblada *"),value: "Rota, fisura o doblada *",),
    new DropdownMenuItem(child: new Text("Datos incorrectos"),value: "Datos incorrectos",),
  ];

  String _motivo;
  String _datosCorregir;
  bool _addMotivo = false;
  ProgressDialog _progressDialog;

  @override
  void initState(){
    _motivo = _motivoList[0].value;
    super.initState();
  }

  @override
  void dispose() {
    _datosCorregirControler.dispose();
    super.dispose();
  }

  Widget _buildForm(NominaViewModel viewModel){

    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          Padding(
            padding: UiHelper.formItemsPadding,
            child: DropdownButton(
              isExpanded: true,
              value: _motivo,
              items: _motivoList,
              onChanged: (item){
                _motivo = item;
                _enableEditor(item == "Datos incorrectos");
              },
            ),
          ),
          Padding(
            padding: UiHelper.formItemsPadding,
            child: TextFormField(
              controller: _datosCorregirControler,
              enabled: _addMotivo,
              onSaved: (val)=>_datosCorregir=val,
              maxLines: null,
              keyboardType: TextInputType.multiline,
              validator: (val)=>_addMotivo && util.isNullOrEmpty(val) ? "Favor de agregar los datos a corregir" : null,
              decoration: InputDecoration(
                  labelText: 'Datos a corregir',
                  hintText: 'Agrega los datos a corregir',
                  enabled: _addMotivo
              )
            ),
          ),
          Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: Text("Al solicitar la credencial por este medio, estoy aceptando el descuento vía nomina por la reposición de la misma.", textScaleFactor: 0.8,),
          ),
          Padding(
            padding: UiHelper.compactFormItemsPadding,
            child: Text("* Para los motivos de reposición marcados con un asterisco el costo del mismo será de \$50.00 pesos MX mismos que serán descontados vía nómina.", textScaleFactor: 0.8),
          )
        ],
      )
    );
  }

  Widget _buildSubmitButton(NominaViewModel viewModel){
    return Container(
      margin: EdgeInsets.symmetric(vertical: 25.0),
      child: SubmitButtonWidget(
        title: "Enviar",
        onSubmit: (){
          FocusScope.of(context).requestFocus(FocusNode());
          _submit(viewModel);
        },
      ),
    );
  }

  void _submit(NominaViewModel viewModel) async{
    final formState = _formKey.currentState;
    if(formState.validate()){
      formState.save();

      await _progressDialog.show();
      final success = await viewModel.enviarSolicitudCredencial(Provider.of<UserModel>(context),_motivo,_datosCorregir);
      await _progressDialog.hide();
      
      if(!success){
        util.unathorized(context, viewModel.status,()=>util.showAlertPopup(context, "¡Atención!", viewModel.message));
      }else{
        Navigator.of(context).pop("Solicitud enviada");
      }

    }
  }

  void _enableEditor(bool flag){
    if(!flag){
      _datosCorregirControler.clear();
    }
    setState(() {
      _addMotivo = flag;
    });
  }

  @override
  Widget build(BuildContext context) {
    _progressDialog = util.progressDialogBuilder(context, "Enviado solicitud");

    return BaseWidget<NominaViewModel>(
      model: NominaViewModel(nominaService: Provider.of(context)),
      builder: (context,model,child)=>Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          title: Text("Solicitar credencial"),
          centerTitle: false,
          leading: IconButton(
          icon: Icon(Icons.close),
            onPressed: (){
              Navigator.of(context).pop(null);
            },
          ),
        ),
        body: Container(
          child: ListView(
            padding: UiHelper.listItemPadding,
            children: <Widget>[
              Card(
                child: new Column(
                  children: <Widget>[
                    _buildForm(model),
                    _buildSubmitButton(model)
                  ],
                )
              )
            ],
          ),
        ),
      ),
    );
  }
}