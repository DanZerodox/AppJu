import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/views/accesoExternoItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AccesoExternoListView extends StatelessWidget {
  final int idAcceso;
  const AccesoExternoListView({Key key, @required this.idAcceso}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final accesos = Provider.of<AccesosModel>(context).accesos;

    final acceso = accesos.firstWhere((e) => e.idAcceso == idAcceso);
    final accessosUsr = accesos
      .where((x)=>x.idAccesoPadre == idAcceso && x.bitAcceso == 1)
      .toList();

    return acceso != null && acceso.bitAcceso == 1 ? Scaffold(
      appBar: AppBar(
        title: Text(acceso.nombreAcceso),
        centerTitle: false,
      ),
      body: ListView.builder(
        padding: UiHelper.listItemPadding,
        itemCount: accessosUsr.length,
        itemBuilder: (context,index)=>AccesoExternoItemWidget(
          accesoModel: accessosUsr[index],
        )
      ),
    ): Scaffold(
      body: Center(
        child: Text("No tienes permisos para ver este contenido"),
      ),
    );
  }
}