import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/vacaciones_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:espacio_jumex/core/viewmodel/view/vacacionesView_model.dart';
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:espacio_jumex/ui/widgets/listItem_widget.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:provider/provider.dart';

class VacacionesListWidget extends StatefulWidget {
  VacacionesListWidget({Key key}) : super(key: key);

  @override
  _VacacionesListWidgetState createState() => _VacacionesListWidgetState();
}

class _VacacionesListWidgetState extends State<VacacionesListWidget> {
  final _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();
  ProgressDialog _progressDialog;

  @override
  void initState() {
    Future.microtask(() {
      final viewModel = Provider.of<VacacionesViewModel>(context);
      viewModel.consultaSolicitudesVacaciones(Provider.of<UserModel>(context), true).then((_) {
        util.unathorized(context, viewModel.status, () => null);
      });
    });

    super.initState();
  }

  final arrastrarWidget = Column(
    children: [Text("Arrastrar"), Icon(Icons.arrow_downward)],
  );

  void _deleteSolicitud(VacacionesViewModel viewModel, SolicitudVacacionesModel solicitud) async {
    final delete = await _showConfirmDialog();

    if (!delete) return;

    final user = Provider.of<UserModel>(context);
    _progressDialog = util.progressDialogBuilder(context, "Eliminando");

    await _progressDialog.show();
    final success = await viewModel.borrarSolicitudVacaciones(user, solicitud);
    await _progressDialog.hide();

    if (!success) {
      util.unathorized(context, viewModel.status, () => util.showAlertPopup(context, "¡Atención!", viewModel.message));
    }
    _refreshIndicatorKey.currentState.show();
  }

  Future<bool> _showConfirmDialog() async {
    return await showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return ClipRect(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(32.0))),
              title: Text("Borrar solictud"),
              content: Text("¿Estás seguro de borrar la solicitud?"),
              actions: <Widget>[
                FlatButton(
                  child: Text("Cerrar"),
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                ),
                FlatButton(
                  child: Text("Borrar"),
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                )
              ],
            ),
          ]));
        });
  }

  Widget _buildBody(VacacionesViewModel viewModel) {
    final accesos = Provider.of<AccesosModel>(context);
    final granted = accesos.accesos.any((x) => x.rutaAcceso == RoutePath.Landing && x.bitAcceso == 1);

    return granted ? _buildSolicitudesList(viewModel) : _buildTomadasList(viewModel.vacaciones?.tomadas);
  }

  Widget _buildSolicitudesList(VacacionesViewModel viewModel) {
    final tsolicitudes = viewModel.vacaciones?.solicitudes?.length ?? 0;

    return ListView.builder(
        padding: UiHelper.listItemPadding,
        physics: AlwaysScrollableScrollPhysics(),
        itemCount: tsolicitudes == 0 ? 1 : tsolicitudes,
        itemBuilder: (context, index) {
          if (tsolicitudes == 0) {
            return arrastrarWidget;
          } else {
            final item = viewModel.vacaciones.solicitudes[index];
            return ListItemWidget(
              child: ExpansionTile(
                key: PageStorageKey<String>(item.id.toString()),
                expandedCrossAxisAlignment: CrossAxisAlignment.start,
                expandedAlignment: Alignment.centerLeft,
                trailing: item.estatus != "pendiente"
                    ? null
                    : IconButton(
                        icon: Icon(Icons.delete),
                        color: Colors.red[400],
                        onPressed: () {
                          _deleteSolicitud(viewModel, item);
                        },
                      ),
                title: Text("${item.fechaInicio} - ${item.fechaFin}",
                    style: TextStyle(
                        color: item.estatus == 'rechazada'
                            ? Colors.red[400]
                            : item.estatusSap == 'guardada'
                                ? Colors.green[400]
                                : Colors.black)),
                initiallyExpanded: item.estatus == "pendiente",
                children: [
                  Padding(
                    padding: UiHelper.listFirstInternalItemPadding,
                    child: Text("Solicitado: ${item.fechaSolicitud}"),
                  ),
                  Padding(
                    padding: UiHelper.listInternalItemPadding,
                    child: Text("Dias: ${item.dias}"),
                  ),
                  Padding(
                    padding: UiHelper.listInternalItemPadding,
                    child: Text("Estatus: ${item.estatus}"),
                  ),
                  !util.isNullOrEmpty(item.comentarios)
                      ? Padding(
                          padding: UiHelper.listInternalItemPadding,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Comentarios: "),
                              Expanded(
                                child: Text(item.comentarios ?? "-"),
                                flex: 2,
                              )
                            ],
                          ),
                        )
                      : SizedBox.shrink(),
                  !util.isNullOrEmpty(item.observaciones)
                      ? Padding(
                          padding: UiHelper.listInternalItemPadding,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Motivo: "),
                              Expanded(
                                child: Text(item.observaciones ?? "-"),
                                flex: 2,
                              )
                            ],
                          ),
                        )
                      : SizedBox.shrink(),
                  Padding(
                    padding: UiHelper.listLastInternalItemPadding,
                    child: Text("Folio: ${item.id}"),
                  ),
                ],
              ),
            );
          }
        });
  }

  Widget _buildTomadasList(List<SolicitudVacacionesModel> vacaciones) {
    final tsolicitudes = vacaciones?.length ?? 0;

    return ListView.builder(
        padding: UiHelper.listItemPadding,
        physics: AlwaysScrollableScrollPhysics(),
        itemCount: tsolicitudes > 0 ? tsolicitudes : 1,
        itemBuilder: (context, index) {
          if (tsolicitudes == 0) {
            return arrastrarWidget;
          } else {
            final item = vacaciones[index];

            return ListItemWidget(
              child: ListTile(
                title: new Text(item.observaciones ?? "--"),
                subtitle: new Text("${item.fechaInicio} - ${item.fechaFin}"),
              ),
            );
          }
        });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<VacacionesViewModel>(
      builder: (context, viewModel, child) => RefreshIndicator(
        key: _refreshIndicatorKey,
        onRefresh: () async {
          final response = await viewModel.consultaSolicitudesVacaciones(Provider.of<UserModel>(context));
          util.unathorized(context, viewModel.status, () => null);
          return Future.value(() => response);
        },
        child: viewModel.statusSolicitudes == Status.busy && viewModel.init ? UiHelper.progressIndicator : _buildBody(viewModel),
      ),
    );
  }
}
