import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util;
import 'package:espacio_jumex/ui/shared/uiHelper.dart';
import 'package:flutter/material.dart';

class TramitesView extends StatelessWidget{
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  
  void _showMessage(BuildContext context, String text){
    if(text!=null && text.isNotEmpty)
      util.showAlertPopup(context, "¡Atención!", text);
  }

  @override
  Widget build(BuildContext context) {

    return new Scaffold(
      key: _scaffoldKey,
      appBar: new AppBar(
        centerTitle: false,
        title: new Text("Trámites"),
      ),
      body: new Container(
        child: new ListView(
          padding: UiHelper.listItemPadding,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(
                    color: UiHelper.colorHorizontalDivider
                  )
                )
              ),
              child: InkWell(
                child: ListTile(
                  title: Text("Solicitar credencial"),
                ),
                onTap: (){
                  Navigator.of(context).pushNamed(RoutePath.Credencial)
                    .then((value)=>_showMessage(context, value));
                },
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(
                    color: UiHelper.colorHorizontalDivider
                  )
                )
              ),
              child: ListTile(
                title: Text("Actualizar correo de nómina"),
                onTap: (){
                  Navigator.of(context).pushNamed(RoutePath.CorreoNomina)
                    .then((value)=>_showMessage(context,value));
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}