import 'package:espacio_jumex/core/models/directorio_model.dart';
import 'package:espacio_jumex/core/models/faq_model.dart';
import 'package:espacio_jumex/core/models/general_model.dart';
import 'package:espacio_jumex/core/models/incidencia_model.dart';
import 'package:espacio_jumex/core/models/preevaluate_model.dart';
import 'package:espacio_jumex/core/models/recibo_model.dart';
import 'package:espacio_jumex/core/models/request/incidenciaReq_model.dart';
import 'package:espacio_jumex/core/models/request/incidenciasCAPReq_model.dart';
import 'package:espacio_jumex/core/models/request/solicitudVacacionesReq_model.dart';
import 'package:espacio_jumex/core/models/solicitudcredencial_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/vacaciones_model.dart';
import 'package:espacio_jumex/core/services/espaciojumex_api.dart';

class NominaService {
 EspacioJumexApi _api;

 NominaService({EspacioJumexApi api}):_api= api; 

  Future<List<FAQModel>> getPreguntasFrecuentes(UserModel userModel) async{
   final response = await _api.getPreguntasFrecuentes(userModel);
   return response?.map<FAQModel>((x)=>FAQModel.fromJson(x))?.toList();
 }

 Future<List<DirectorioModel>> getDirectorioRH(UserModel userModel) async{
   final response = await _api.getDirectoryCH(userModel);
   return response?.map<DirectorioModel>((x)=>DirectorioModel.fromJson(x))?.toList();
 }

 Future<GeneralModel> postSugerencia(UserModel userModel, String sugerencia,String email) async{
   final response = await _api.postSugerencia(userModel, sugerencia, email);
   return GeneralModel.fromJson(response);
 }

 Future<PreevaluateModel> postPreevaluate(UserModel userModel, String date) async{
   final response = await _api.postPreevaluate(userModel,date);
   return PreevaluateModel.fromJson(response);
 }

  Future<ReciboModel> postRecibo(UserModel userModel, String tipoRecibo, String date) async{
    final response = await _api.postRecibo(userModel,tipoRecibo,date);
    return ReciboModel.fromJson(response);
  }

  Future<List<SolicitudCredencialModel>> getSolicitudCredencial(UserModel userModel) async{
    final response = await _api.getSolicitudCredencial(userModel);
    return response?.map<SolicitudCredencialModel>((x)=>SolicitudCredencialModel.fromJson(x))?.toList();
  }

  Future<GeneralModel> postSolicitudCredencial(UserModel userModel, String motivo,String datosACorregir) async{
    final response = await _api.postSolicitudCredencial(userModel,motivo,datosACorregir);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> postActualizarCorreoNomina(UserModel userModel, String correo) async{
    final response = await _api.postActualizarCorreoNomina(userModel,correo);
    return GeneralModel.fromJson(response);
  }

  Future<InformacionVacacionesModel> getVacaciones(UserModel userModel) async{
    final response = await _api.getVacaciones(userModel);
    return InformacionVacacionesModel.fromJson(response);
  }

  Future<SolicitudesVacacionesWrapModel> getSolicitudesVacaciones(UserModel userModel) async{
    final response = await _api.getSolicitudesVacaciones(userModel);
    return SolicitudesVacacionesWrapModel.fromJson(response);
  }

  Future<GeneralModel> getBorrarSolicitudVacaciones(UserModel userModel, SolicitudVacacionesModel solicitudVacaciones) async{
    final response = await _api.getDeleteVacaciones(userModel,solicitudVacaciones);
    return GeneralModel.fromJson(response);
  }
  
  Future<List<SolicitudVacacionesModel>> getVacacionesPorAutorizar(UserModel userModel) async{
    final response = await _api.getVacacionesPendientes(userModel);
    return response.map((x)=>SolicitudVacacionesModel.fromJson(x)).toList().cast<SolicitudVacacionesModel>();
  }

  Future<GeneralModel> postAutorizarVacaciones(UserModel userModel,SolicitudVacacionesModel solicitud) async{
    final response = await _api.getAutorizarVacaciones(userModel,solicitud);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> postRechazarVacaciones(UserModel userModel,SolicitudVacacionesModel solicitud) async{
    final response = await _api.postRechazarVacaciones(userModel,solicitud);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> postSolicitudVacaciones(UserModel userModel,SolicitudVacacionesReqModel solicitud) async{
    final response = await _api.postSolicitudVacaciones(userModel,solicitud);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> postIncidenciaCAP(UserModel userModel,IncidenciasCAPReqModel incidenciasCAPReqModel) async{
    final response = await _api.postIncidenciaCAP(userModel,incidenciasCAPReqModel);
    return GeneralModel.fromJson(response);
  }

  Future<List<IncidenciaModel>> getIncidencias(UserModel userModel) async{
    final response = await _api.getIncidencias(userModel);
    return response?.map<IncidenciaModel>((x)=>IncidenciaModel.fromJson(x))?.toList();
  }
  Future<List<IncidenciaPendienteModel>> getIncidenciasPendientes(UserModel userModel) async{
    final response = await _api.getIncidenciasPendientes(userModel);
    return response?.map<IncidenciaPendienteModel>((x)=>IncidenciaPendienteModel.fromJson(x))?.toList();
  }

  Future<GeneralModel> postIncidencia(UserModel userModel, IncidenciaReqModel incidenciaReq) async{
    final response = await _api.postIncidencia(userModel, incidenciaReq);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> getBorrarIncidencia(UserModel userModel, IncidenciaModel incidenciaModel) async{
    final response = await _api.getBorrarIncidencia(userModel, incidenciaModel);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> getAutorizarIncidencia(UserModel userModel, IncidenciaPendienteModel incidencia) async{
    final response = await _api.getAutorizarIncidencia(userModel, incidencia);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> postRechazarIncidencia(UserModel userModel, IncidenciaRechazoReqModel incidencia) async{
    final response = await _api.postRechazarIncidencia(userModel, incidencia);
    return GeneralModel.fromJson(response);
  }

  Future<List<IncidenciaValueModel>> getIncidenciasCatalogo(UserModel userModel) async{
    final response = await _api.getIncidenciasCatalogo(userModel);
    return response?.map<IncidenciaValueModel>((x)=>IncidenciaValueModel.fromJson(x))?.toList();
  }
}