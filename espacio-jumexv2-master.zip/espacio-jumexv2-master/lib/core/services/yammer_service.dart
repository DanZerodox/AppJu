
import 'package:espacio_jumex/core/contants/app_constants.dart' show ApiConstant;
import 'package:espacio_jumex/core/models/request/avisoOportunoReq_model.dart';
import 'package:espacio_jumex/core/models/avisoOportuno_model.dart';
import 'package:espacio_jumex/core/models/general_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/services/espaciojumex_api.dart';
import 'package:espacio_jumex/core/services/uploader_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_uploader/flutter_uploader.dart' show FileItem;

class YammerService {
  EspacioJumexApi _api;
  UploaderService _uploaderService;

  YammerService({@required EspacioJumexApi api,UploaderService uploaderService}):
    _api= api, _uploaderService = uploaderService; 

  Future<List<YammerModel>> getMensajesYammer(UserModel userModel,String groupId ,{String olderThan = "0", String newerThan = "0" }) async{
    final response = await _api.getMensajesYammer(userModel, groupId, olderThan: olderThan, newerThan: newerThan);
    return response?.map<YammerModel>((x)=>YammerModel.fromJson(x))?.toList();
  }
  
  Future<List<YammerMessagesModel>> getMisPublicaciones(UserModel userModel) async{
    final response = await _api.getMisPublicaciones(userModel);
    return response?.map<YammerMessagesModel>((x)=>YammerMessagesModel.fromJson(x))?.toList();
  }

  Future<AvisoOportunoModel> consultaMiPublicacion(UserModel userModel, String idYammer) async{
    final response = await _api.consultaMiPublicacion(userModel, idYammer);
    return AvisoOportunoModel.fromJson(response);
  }

  Future<GeneralModel> getEliminarPublicacion(UserModel userModel, YammerMessagesModel yammerMessagesModel) async{
    final response = await _api.eliminarPublicacion(userModel, yammerMessagesModel);
    _uploaderService.addQueue(null);
    return GeneralModel.fromJson(response);
  }

  Future<void> postPublicarAnuncio(UserModel userModel, AvisoOportunoReqModel avisoOportunoReq, List<FileItem> files) async {
    await _uploaderService.enqueue(userModel, avisoOportunoReq.titulo, "${ApiConstant.apiEndpoint}/yammer/aviso_oportuno", avisoOportunoReq.toMap(),files: files, );
  }

  void clearUploadQueue() {
    _uploaderService.addQueue(null);
  }

  Future<String>consultarUrlVideo(String url) async{
    return await _api.consultarUrlVideo(url);
  }
}