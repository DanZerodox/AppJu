
import 'package:espacio_jumex/core/services/localdb/appDatabase.dart';
import 'package:espacio_jumex/core/services/localdb/localDatabase.dart';
import 'package:espacio_jumex/core/services/localdb/localdb.dart';

class LocaldbService extends LocalDatabase with UserDatabase,AppDatabase,ConfigurationDatabase, YammerDatabase{
  static LocaldbService _instance;

  factory LocaldbService(){
    if(_instance == null)
      _instance = LocaldbService._();

    return _instance;
  }

  LocaldbService._();

}