
import 'dart:convert';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/incidencia_model.dart';
import 'package:espacio_jumex/core/models/request/incidenciaReq_model.dart';
import 'package:espacio_jumex/core/models/request/incidenciasCAPReq_model.dart';
import 'package:espacio_jumex/core/models/request/solicitudVacacionesReq_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/vacaciones_model.dart';
import 'package:espacio_jumex/core/services/api/network.dart';

mixin NominaApi on Network{
  final _serviceUrl = ApiConstant.apiEndpoint;
  
  Future<dynamic> postPreevaluate(UserModel user, String date){
    return decodePost('$_serviceUrl/Nomina/preevaluate',
        headers:<String,String>{
          'token': user.tokenAcceso
        },
        body: {
          "fecha" :date,
      });
  }

  Future<dynamic> postRecibo(UserModel user, String tipo, String toDate){
    return decodePost('$_serviceUrl/Nomina/recibo',
        headers:<String,String>{
          'token': user.tokenAcceso
        },
        body: {
          "fecha" : toDate,
          "tipo": tipo
      });
  }

  Future<dynamic> postSolicitudVacaciones(UserModel user, SolicitudVacacionesReqModel solicitud){
    return decodePost('$_serviceUrl/Nomina/vacaciones/agregar',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: solicitud.toJson());
  }

  Future<dynamic> getVacaciones(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/vacaciones',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }

  Future<dynamic> getSolicitudesVacaciones(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/vacaciones/solicitudes',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }

  Future<dynamic> getVacacionesPendientes(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/vacaciones/pendientes',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }

  Future<dynamic> getAutorizarVacaciones(UserModel user, SolicitudVacacionesModel solicitud){
    return decodeGet('$_serviceUrl/Nomina/vacaciones/${solicitud.id}/autorizar',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }

  Future<dynamic> postRechazarVacaciones(UserModel user,SolicitudVacacionesModel solicitud){
    return decodePost('$_serviceUrl/Nomina/vacaciones/${solicitud.id}/rechazar',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: {
        "Observaciones": solicitud.observaciones,
    });
  }
  
  Future<dynamic> getDeleteVacaciones(UserModel user,SolicitudVacacionesModel solicitud){
    return decodeGet('$_serviceUrl/Nomina/vacaciones/${solicitud.id}/borrar',
      headers:<String,String>{
        'token': user.tokenAcceso
      },);
  }

  Future<dynamic> postActualizarCorreoNomina(UserModel user, String email){
    return decodePost('$_serviceUrl/Nomina/updateEmail',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: {
        "Email" : email,
      }
    );
  }

  Future<dynamic> postIncidenciaCAP(UserModel user, IncidenciasCAPReqModel incidenciasCAPReqModel){
    return decodePost('$_serviceUrl/Nomina/sendBuzon',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: incidenciasCAPReqModel.toJson()
    );
  }

  Future<dynamic> getIncidencias(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/incidencias',
      headers:<String,String>{
        'token': user.tokenAcceso
      },);
  }

   Future<dynamic> getIncidenciasPendientes(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/incidencias/pendientes',
      headers:<String,String>{
        'token': user.tokenAcceso
      },);
  }

  Future<dynamic> postIncidencia(UserModel user, IncidenciaReqModel incidenciaReqModel){
    final body = json.encode(incidenciaReqModel.toJson());

    return decodePost('$_serviceUrl/Nomina/incidencias/agregar',
      headers:<String,String>{
        'token': user.tokenAcceso,
        'Content-type': 'application/json'
      },
      body: body
    );
  }

  Future<dynamic> getBorrarIncidencia(UserModel user, IncidenciaModel incidenciaModel){
    return decodeGet('$_serviceUrl/Nomina/incidencias/${incidenciaModel.id}/${incidenciaModel.tipo}/borrar',
      headers:<String,String>{
        'token': user.tokenAcceso
      }
    );
  }

  Future<dynamic> getAutorizarIncidencia(UserModel userModel, IncidenciaPendienteModel incidencia) async {
    return decodeGet('$_serviceUrl/Nomina/incidencias/${incidencia.id}/${incidencia.tipo}/autorizar',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      }
    );
  }

  Future<dynamic> postRechazarIncidencia(UserModel userModel, IncidenciaRechazoReqModel incidencia) async {
    return decodePost('$_serviceUrl/Nomina/incidencias/${incidencia.id}/${incidencia.tipo}/rechazar',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      },
      body: incidencia.toJson()
    );
  }

  Future<dynamic> getIncidenciasCatalogo(UserModel userModel) async {
    return decodeGet('$_serviceUrl/Nomina/incidencias/catalogo',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      }
    );
  }
  
}