import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:espacio_jumex/core/exceptions/exceptions.dart';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart' as IOClient;

class Network{
  final JsonDecoder _decoder = new JsonDecoder();

  Network();

  String _resolveResponseString(http.Response httpResponse){
      final responseBody = httpResponse.body;
      final statusCode = httpResponse.statusCode;
      
      final message = responseBody != null && responseBody.isNotEmpty &&
          responseBody.contains('"msg"') || responseBody.contains('"Message"') || responseBody.contains('"responseBody"') ?
          _decoder.convert(responseBody)["msg"] ?? _decoder.convert(responseBody)["Message"] ?? _decoder.convert(responseBody)["responseBody"] as String : null;

      if (statusCode == 400) {
        throw BadRequestException( message ?? "Solictud errónea");
      }

      if (statusCode == 401) {
        throw UnauthorizedException("Sin autorización de acceso");
      }

      if (statusCode == 404) {
        throw NotFoundException(message ?? "No se encontró contenido");
      }

      if (statusCode != 200 ) {
        throw new UnexpectedException(message ?? "Ocurrió un error en el servidor");
      }
      return responseBody;
  }

  http.Response _resolveResponse(http.Response httpResponse){
      final statusCode = httpResponse.statusCode;

      if (statusCode == 400) {
        throw BadRequestException("Solictud errónea");
      }

      if (statusCode == 401) {
        throw UnauthorizedException("Sin autorización de acceso");
      }

      if (statusCode == 404) {
        throw NotFoundException("No se encontró contenido");
      }

      if (statusCode != 200 ) {
        throw new UnexpectedException("Ocurrió un error en el servidor");
      }
      return httpResponse;
  }

  Future<String> httpGet(String url, {Map headers}) {
    var httpClient = HttpClient();
    httpClient.badCertificateCallback = (___, __, _) => true;

    return IOClient.IOClient(httpClient)
        .get(url, headers: headers)
        .then(_resolveResponseString);
  }

  Future<String> httpPost(String url, {Map headers, body, encoding}) {
    var httpClient = HttpClient();
    httpClient.badCertificateCallback = (___, __, _) => true;

    return IOClient.IOClient(httpClient)
        .post(url, body: body, headers: headers, encoding: encoding)
        .then(_resolveResponseString);
  }

  Future<dynamic> decodeGet(String url, {Map headers}) async{
    final response = await httpGet(url,headers: headers);
    return _decoder.convert(response);
  }

  Future<http.Response> get(String url, {Map headers}) async{
     var httpClient = HttpClient();
    httpClient.badCertificateCallback = (___, __, _) => true;

    return IOClient.IOClient(httpClient)
        .get(url, headers: headers)
        .then(_resolveResponse);
  }
  
  Future<dynamic> decodePost(String url, {Map headers,body}) async{
    final response = await httpPost(url,headers: headers,body: body);
    return _decoder.convert(response);
  }
}
