import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/services/api/network.dart';

mixin YammerApi on Network{
  final _serviceUrl = ApiConstant.apiEndpoint;
  
   Future<dynamic> getMensajesYammer(UserModel userModel,String groupId ,{String olderThan = "0", String newerThan = "0" }){
    return decodeGet("$_serviceUrl/Yammer/$groupId?older=$olderThan&newer=$newerThan",
        headers:<String,String>{
          'token': "${userModel.tokenAcceso}"
        });
  }

  Future<dynamic> getMisPublicaciones(UserModel userModel){
    return decodeGet("$_serviceUrl/Yammer/publicaciones/",
        headers:<String,String>{
          'token': "${userModel.tokenAcceso}"
        });
  }

  Future<dynamic> consultaMiPublicacion(UserModel userModel, String idYammer){
    return decodeGet("$_serviceUrl/Yammer/aviso_oportuno/$idYammer",
        headers:<String,String>{
          'token': "${userModel.tokenAcceso}"
        });
  }

  Future<dynamic> eliminarPublicacion(UserModel userModel, YammerMessagesModel yammerMessagesModel){
    return decodeGet("$_serviceUrl/Yammer/borrarPublicacion/${yammerMessagesModel.messageId}",
        headers:<String,String>{
          'token': "${userModel.tokenAcceso}"
        });
  }

  Future<String> consultarUrlVideo(String url) async{
    final response = await get("$_serviceUrl/$url");
    return response.body;
  }
  
}