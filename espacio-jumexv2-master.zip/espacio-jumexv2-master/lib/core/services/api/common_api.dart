import 'dart:async';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/api/network.dart';

mixin CommonApi on Network{
  final _serviceUrl = ApiConstant.apiEndpoint;

  Future<dynamic> getDirectoryCH(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/dirCapitalHumano',
        headers:<String,String>{
          'token': user.tokenAcceso
        });
  }

  Future<dynamic> getPreguntasFrecuentes(UserModel user){
    return decodeGet('$_serviceUrl/Nomina/preguntasFrecuentes',
        headers:<String,String>{
          'token': user.tokenAcceso
        });
  }
  
  Future<dynamic> postSugerencia(UserModel user, String sugerencia,String email){
    return decodePost('$_serviceUrl/User/sendSugerencia',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: {
        "email" : email,
        "mensaje": sugerencia,
        "nombre": user.nombre,
        "localidad": user.divisionPDes
    });
  }

  Future<dynamic> getRevistas(UserModel user){
    return decodeGet('$_serviceUrl/Resource/revista',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }
}