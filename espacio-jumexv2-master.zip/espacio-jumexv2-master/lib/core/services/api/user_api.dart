import 'dart:async';
import 'dart:convert';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/appVersion_model.dart';
import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/configuration_model.dart';
import 'package:espacio_jumex/core/models/device_model.dart';
import 'package:espacio_jumex/core/models/documento_model.dart';
import 'package:espacio_jumex/core/models/request/userReq_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/api/network.dart';


mixin UserApi on Network{
  final _serviceUrl = ApiConstant.apiEndpoint;

  Future<dynamic> reloadSession(UserModel user, String tokenFirebase, DeviceModel deviceModel, AppVersionModel appVersion){
    return decodePost('$_serviceUrl/User/reloadSession',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: {
        "token_firebase": tokenFirebase,
        "appVersion": "${appVersion.version}.${appVersion.buildNumber}"
      });
  }

  Future<dynamic> login(UserReqModel user, DeviceModel deviceModel, AppVersionModel appVersion){
    return decodePost('$_serviceUrl/User/validate',
        headers:<String,String>{
          'User-Agent': '${deviceModel.baseOS} ${deviceModel.manufacturer ?? ''} ${deviceModel.model} ${deviceModel.name ?? ''}'
        },
        body: {
          "numero": user.userNumber,
          "password": user.password,
          "token_firebase": user.firebaseToken,
          "rememberme": "${user.rememberme}",
          "appVersion": "${appVersion.version}.${appVersion.buildNumber}"
        }
    );
  }

  Future<dynamic> singOut(UserModel user, DeviceModel deviceModel){    
    return decodeGet('$_serviceUrl/User/signOut',
      headers:<String,String>{
        'User-Agent': '${deviceModel.baseOS} ${deviceModel.model} ${deviceModel.name ?? ''}',
        'token': user.tokenAcceso
      }
    );
  }

  Future<dynamic> getBirthdays(UserModel user,){
    return decodeGet('$_serviceUrl/User/empleados/cumpleanios',
    headers:<String,String>{
      'token': user.tokenAcceso
    });
  }

  Future<dynamic> postSolicitudCredencial(UserModel user,String motivo,String datosIncorrectos){
    return decodePost('$_serviceUrl/User/credencial/agregar',
        headers:<String,String>{
          'token': user.tokenAcceso
        },
        body: {
          "Motivo": motivo,
          "DatosIncorrectos": datosIncorrectos
      });
  }

  Future<dynamic> getSolicitudCredencial(UserModel user){
    return decodeGet('$_serviceUrl/User/credencial/solicitudes',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }
    
  Future<dynamic> postNuevoPassword(UserModel user, String password,String passwordNuevo){
    return decodePost('$_serviceUrl/User/password/actualizar',
      headers:<String,String>{
        'token': user.tokenAcceso
      },
      body: {
        "password" : password,
        "passwordNuevo": passwordNuevo,
    });
  }

  Future<dynamic> postFelicitacionesCumpleanios(UserModel user,String mensaje,List<ColaboradorModel> colaboradores) {
    final body = json.encode(
      {
        "Mensaje": mensaje,
        "Partners": colaboradores.map((x)=>x.numeroEmpleado.toString()).toList()
      }
    );
    return decodePost('$_serviceUrl/User/empleados/cumpleanios',
      headers: <String, String>{
        'token': user.tokenAcceso,
        'Content-type': 'application/json'
      },
      body: body
    );
  }

  Future<dynamic> getActualizaConfiguracion(UserModel userModel, ConfigurationModel configurationModel) {
    return decodeGet('$_serviceUrl/User/configuracion/${configurationModel.configuracion}/${configurationModel.bitActivo}',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      });
  }

  Future<dynamic> getAccesos(UserModel userModel) {
    return decodeGet('$_serviceUrl/User/configuracion',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      });
  }

  Future<dynamic> getContenidoAcceso(UserModel userModel, AccesoModel accesoModel){
    return decodeGet('$_serviceUrl/User/contenidoAcceso/${accesoModel.idAcceso}',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      });
  }

  Future<dynamic> getAvisos(UserModel userModel){
    return decodeGet('$_serviceUrl/User/avisos/legal',
      headers:<String,String>{
        'token': userModel.tokenAcceso
      });
  }

  Future<dynamic> getAprobarDocumento(UserModel user, DocumentoModel documento){
    return decodeGet('$_serviceUrl/User/avisos/aprobar/${documento.id}',
      headers:<String,String>{
        'token': user.tokenAcceso
      });
  }

  Future<dynamic> getRecuperarContrasenia(String usuario){
    return decodeGet('$_serviceUrl/User/password/restaurar/$usuario');
  }

  Future<dynamic> getNotificaciones(UserModel user){
    return decodeGet('$_serviceUrl/User/notificaciones',
    headers: <String,String>{
      'token': user.tokenAcceso
    });
  }

  Future<dynamic> getNotificacionesSinLeer(UserModel user){
    return decodeGet('$_serviceUrl/User/notificaciones/total',
    headers: <String,String>{
      'token': user.tokenAcceso
    });
  }
}