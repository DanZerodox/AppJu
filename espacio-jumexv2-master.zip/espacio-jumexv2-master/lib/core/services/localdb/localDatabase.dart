import 'dart:async';
import 'dart:io' as io;
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';


class LocalDatabase {
  static Database _db;

  Future<Database> get db async {
    if(_db != null)
      return _db;
    _db = await initDb();
    return _db;
  }

  initDb() async {
    io.Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, "espacio_jumex.db");
    var theDb = await openDatabase(path, version: 6, onCreate: _onCreate, onUpgrade: _onUpgrade);
    return theDb;
  }

  void dispose() async{
    var dab = await db;
    await dab.close();
  }

  void _onCreate(Database db, int version) async {
    // When creating the db, create the table

      await db.execute("CREATE TABLE User(Usuario int PRIMARY KEY, Nombre TEXT, Correo TEXT,DenominacionS TEXT,TokenAcceso TEXT, Fotografia TEXT, DivisionPDes TEXT, Ceco text, FechaAlta text, NombreJefe TEXT)");
      await db.execute("CREATE TABLE Permisos(NombreAcceso TEXT, BitAcceso INT)");
      await db.execute("CREATE TABLE Configuration(Configuracion TEXT, BitActivo int, LastUpdate text)");

      await db.execute("CREATE TABLE Directory_RH(directorio TEXT,nombre text, extension text, email text, area text)");
      await db.execute("CREATE TABLE FAQ(id int, pregunta TEXT,respuesta text, parent_id int)");

      await db.execute("CREATE TABLE Yammer(YammerId text,Id int,ContentParsed text,CreatedAt text, Title TEXT, Nikes int)");
      await db.execute("CREATE TABLE YammerMedia(YammerId text, MessageId int,Id int,Type Text, Name text, VersionId int, Thumbnail text, Content text)");

      await db.execute("CREATE TABLE YammerUpdate(YammerId text,LastUpdate text)");

      await db.execute("CREATE TABLE AppMenu(IdAcceso int, NombreAcceso text, RutaAcceso text, BitAcceso int, IdAccesoPadre int, BitConsumeApi int, AppIcon text, UrlLaunch text, BitVisible int, Orden text, IconCover int, SubTipo string)");

      await db.execute("CREATE TABLE AppExternalValues(IdAcceso int, Tipo text, Objetivo text, Rotulo text)");

      await db.execute("CREATE TABLE Uploads(TaskId text, Title text)");

    print("Created tables");
  }

  void _onUpgrade (Database db, int oldVersion, int newVersion) async{
    await db.execute("DROP TABLE AppMenu");
    await db.execute("CREATE TABLE AppMenu(IdAcceso int, NombreAcceso text, RutaAcceso text, BitAcceso int, IdAccesoPadre int, BitConsumeApi int, AppIcon text, UrlLaunch text, BitVisible int, Orden text, IconCover int, SubTipo string)");
  }
  
}