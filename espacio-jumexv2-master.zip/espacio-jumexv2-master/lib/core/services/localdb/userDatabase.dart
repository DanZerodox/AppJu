import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/localdb/localDatabase.dart';

mixin UserDatabase on LocalDatabase{

  Future<Null> saveUser(UserModel user) async {
    var dbClient = await db;

    await dbClient.transaction((txt)async{
      await txt.delete("User");
      await txt.insert("User",user.toMap());
    });

  }

  Future<UserModel> getUser() async {
    var dbClient = await db;
    var res = await dbClient.query("User");
    var value = res!= null && res.length>0 ? UserModel.fromJson(res.first) : null;
    return value ;
  }

  Future<int> deleteUser() async {
    var dbClient = await db;
    int res = await dbClient.delete("User");
    return res;
  }

  Future<int> logoutUser(UserModel user) async {
    var dbClient = await db;
    int res = await dbClient.update("User",{
      "TokenAcceso":null
    },where: "Usuario = ?",
      whereArgs: [user.usuario]
    );
    return res;
  }
}