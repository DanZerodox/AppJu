import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/services/localdb/localDatabase.dart';

mixin YammerDatabase on LocalDatabase{

  Future<int> clearYammers() async{
    var dbClient = await db;
    var r = await dbClient.delete("Yammer");
     var a = await dbClient.delete("YammerMedia");
    return r*1000 + a;
  }

  Future<DateTime> getLastUpdate(String yammerId) async{
    var dbClient = await db;
    var res = await dbClient.rawQuery("SELECT * FROM YammerUpdate WHERE YammerId = ?",[yammerId]);
    var value = res!= null && res.length>0 ? DateTime.parse(res[0]["LastUpdate"])  : DateTime.now();
    return value ;
  }

  Future<YammerModel> getRecentYammer(String yammerId) async{
    var dbClient = await db;
    var res = await dbClient.rawQuery("SELECT * FROM Yammer WHERE YammerId = ?",[yammerId]);
    var value = res!= null && res.length>0 ? YammerModel.fromJson(res.first) : null;
    return value ;
  }

  Future<void> saveYammer(List<YammerModel> yammers,String yammerId) async {
    var dbClient = await db;

    await dbClient.transaction((txt)async{

      await txt.delete("Yammer", where: "YammerId = ?", whereArgs: [yammerId]);
      await txt.delete("YammerMedia",where: "YammerId = ?",whereArgs: [yammerId]);
      
      for (var yammer in yammers) {
        await txt.insert("Yammer",yammer.copyWith(yammerId: yammerId).toMap()); 

        for (var media in yammer.media ?? []) {
          await txt.insert("YammerMedia",media.copyWith(yammerId: yammerId).toMap()); 
        }
      }

      final rs = await txt.rawQuery("SELECT * FROM YammerUpdate");
      if(rs == null || rs.length == 0){
        await txt.insert("YammerUpdate",{
          "YammerId": yammerId
          ,"LastUpdate" : DateTime.now().toString()
        });
      }else{
        await txt.update("YammerUpdate", {
          "LastUpdate" : DateTime.now().toString()
        },where: "YammerId = ?", whereArgs: [yammerId]);
      }

    });
  }

  Future<List<YammerModel>> getYammers(String yammerId) async{
    List<YammerModel> response = List<YammerModel>();
    var dbClient = await db;
    var res = await dbClient.rawQuery("SELECT * FROM Yammer WHERE YammerId = ?",[yammerId]);
    if(res!= null && res.length>0){
      for (var item in res) {  
        var model = await dbClient.rawQuery("SELECT * FROM YammerMedia WHERE MessageId = ?",[item["Id"]]);
        final media = model?.map((x)=>YammerMediaModel.fromJson(x))?.toList()?.cast<YammerMediaModel>();
        response.add(YammerModel.fromJson(item).copyWith(media: media));
      }
    }

    return response;
  }

  
  Future<int> getAvisoQueue() async{
    var dbClient = await db;
    var result = await dbClient.query("Uploads");
    return result?.length ?? 0; 
  }

  Future<void> deleteAvisoQueue() async{
    var dbClient = await db;
    dbClient.delete("Uploads");
  }

  Future<void> updateAvisoQueue({String task, String title}) async{
    var dbClient = await db;
    final info = {
      "TaskId" : task, 
      "Title": title
    };
    await dbClient.transaction((txt)async{
      final rs = await txt.rawQuery("SELECT * FROM Uploads");
      if(rs == null || rs.length == 0){
        await txt.insert("Uploads",info);
      }else{
        await txt.update("Uploads", info);
      }
    });
  }
}