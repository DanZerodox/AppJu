import 'package:espacio_jumex/core/models/configuration_model.dart';
import 'package:espacio_jumex/core/services/localdb/localDatabase.dart';

mixin ConfigurationDatabase on LocalDatabase{
  
  Future<Configuracion> getConfiguration() async {
    var dbClient = await db;
    var res = await dbClient.query("Configuration");
    var value = res!= null && res.length>0 ? Configuracion.fromJson(res) : null;
    return value;
  }

  Future<void> updateConfiguration(ConfigurationModel configuracionModel) async {
    var dbClient = await db;

    await dbClient.transaction((txt)async{
      final rs = await txt.rawQuery("SELECT * FROM Configuration WHERE Configuracion = ?",[configuracionModel.configuracion]);
      if(rs == null || rs.length == 0){
        await txt.insert("Configuration",configuracionModel.toMap());
      }else{
        await txt.update("Configuration", configuracionModel.toMap(), where: "Configuracion = ?",whereArgs: [configuracionModel.configuracion]);
      }
    });
  }
  
}