import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/directorio_model.dart';
import 'package:espacio_jumex/core/models/faq_model.dart';
import 'package:espacio_jumex/core/services/localdb/localDatabase.dart';
import 'package:sqflite/sqflite.dart';

mixin AppDatabase on LocalDatabase{
  
  Future<Null> saveDirectoryRH(List<DirectorioModel> users) async {
    var dbClient = await db;

    var batch = dbClient.batch();
    batch.delete("Directory_RH");

    for(var i=0;i<users.length; i++){
      for (var item in users[i].contacts) {
         batch.insert("Directory_RH", item.toMap());   
      }
    }

    await batch.commit(noResult: true);
  }

  Future<List<DirectorioModel>> getDirectoryRH() async{
    var dbClient = await db;
    var result = await dbClient.rawQuery("SELECT * FROM Directory_RH GROUP BY nombre");
    var directoriesName = await dbClient.rawQuery("SELECT distinct directorio FROM Directory_RH GROUP BY nombre");

    var value = result.map<ContactoModel>((x)=> ContactoModel.fromEntity(x)).toList();
    var directories = directoriesName.map<String>((x)=> x["directorio"]).toList();

    final directoryRH = directories.map<DirectorioModel>((x)=>DirectorioModel(
      name: x,
      contacts: value.where((y)=>y.directorio == x).toList()
    )).toList();

    return directoryRH;
  }

  Future<Null> savePreguntasFrecuentes(List<FAQModel> faqs) async {
    var dbClient = await db;

    var batch = dbClient.batch();
    batch.delete("FAQ");

    _savePreguntasFrecuentes$1(batch,faqs);

    await batch.commit(noResult: true);
  }

  Future<Null> _savePreguntasFrecuentes$1(Batch batch, List<FAQModel> faqs) async {
    if(faqs == null || faqs.length == 0){
      return;
    }
    if(faqs.length == 1){
      batch.insert("FAQ", faqs[0].toMap());

      _savePreguntasFrecuentes$1(batch, faqs[0].respuesta);

      return;
    }
    _savePreguntasFrecuentes$1(batch, [faqs.first] );
    _savePreguntasFrecuentes$1(batch, faqs.skip(1).toList().cast<FAQModel>());

    
    return;
  }

  Future<List<FAQModel>> getPreguntasFrecuentes() async{
    var dbClient = await db;
    var result = await dbClient.rawQuery("SELECT * FROM FAQ ORDER BY id");
    var aFaqs = result.map<FAQModel>((x)=> FAQModel.fromEntity(x) ).toList();

    final faqs =  aFaqs.where((x)=>x.parentId == 0)
    .map<FAQModel>((x){
      return x.copyWith(
        respuesta: aFaqs.where((y)=>y.parentId == x.id)
        ?.map<FAQModel>((z){
          return z.copyWith(
            respuesta: aFaqs.where((w)=>w.parentId == z.id)
            .map<FAQModel>((v){
              return v.copyWith(
                respuesta: aFaqs.where((u)=>u.parentId == v.id)?.toList()
              );
            })
            ?.toList()
          );
        })
        ?.toList()
      );
    })
    .toList();

    return faqs;
  }

  Future<AccesosModel> getAccesos()async{
    var dbClient = await db;
    var result = await dbClient.query("AppMenu");
    return result!= null && result.length>0 ? AccesosModel.fromJson(result) : AccesosModel(accesos: <AccesoModel>[]);
  }
  
  Future<void> updateAccesos(AccesosModel accesosModel) async {
    final accesos = accesosModel.accesos;
    var dbClient = await db;

    await dbClient.transaction((txt)async{
      final app = await txt.query("AppMenu");
      final laccesos = AccesosModel.fromJson(app);

      final toDelete = laccesos.accesos.where((x)=>!accesos.any((y)=>y.rutaAcceso == x.rutaAcceso));
      for (var item in toDelete) {
        await txt.delete("AppMenu",where: "RutaAcceso = ?", whereArgs: [item.rutaAcceso]);
      }

      for (var item in accesos) {
        await _operation(item, txt);
      }
      return 0;
    });

  }

  Future<void> updateAcceso(AccesoModel accesoModel) async {
    var dbClient = await db;

    await dbClient.transaction((txt)async{
      await _operation(accesoModel, txt);      
      return 0;
    });
  }

  Future<void> _operation(AccesoModel accesoModel, Transaction transaction) async{
    final rs = await transaction.query("AppMenu",where: "RutaAcceso = ?",whereArgs:[accesoModel.rutaAcceso]);
    if(rs == null || rs.length == 0){
      await transaction.insert("AppMenu",accesoModel.toMap());
    }else{
      final accesoLocal = AccesoModel.fromJson(rs[0]);
      await transaction.update("AppMenu", accesoModel.copyWith(bitVisible: accesoLocal.bitVisible).toMap(),where: "RutaAcceso = ?", whereArgs: [accesoModel.rutaAcceso]);
    }
  }
}