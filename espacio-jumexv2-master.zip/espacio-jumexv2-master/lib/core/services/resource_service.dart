import 'package:espacio_jumex/core/models/revistaJumex_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/espaciojumex_api.dart';

class ResourceService{
  EspacioJumexApi _api;
  ResourceService({EspacioJumexApi api}): _api = api;

  Future<List<RevistaJumexModel>> consultarRevistaJumex(UserModel userModel) async{
    final response = await _api.getRevistas(userModel);
    return response?.map<RevistaJumexModel>((x)=>RevistaJumexModel.fromJson(x))?.toList();
  }
}