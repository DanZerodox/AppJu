import 'package:espacio_jumex/core/services/api/apis.dart';
import 'package:espacio_jumex/core/services/api/network.dart';

class EspacioJumexApi extends Network with UserApi, CommonApi, YammerApi, NominaApi{

  static EspacioJumexApi _instance;

  factory EspacioJumexApi(){
    if(_instance == null)
      _instance = EspacioJumexApi._();

    return _instance;
  }

  EspacioJumexApi._();
}