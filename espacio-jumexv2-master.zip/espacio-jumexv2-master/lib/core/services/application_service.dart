import 'dart:async';
import 'dart:io';
import 'package:device_info/device_info.dart';
import 'package:espacio_jumex/core/models/appVersion_model.dart';
import 'package:espacio_jumex/core/models/device_model.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:package_info/package_info.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class ApplicationService {
  static ApplicationService _instance;

  factory ApplicationService({TargetPlatform targetPlatform}) {
    if (_instance == null) _instance = ApplicationService._(targetPlatform: targetPlatform);

    return _instance;
  }

  ApplicationService._({TargetPlatform targetPlatform}) {
    _targetPlatform = targetPlatform;
  }

  static final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  TargetPlatform _targetPlatform;

  Future<Directory> prepareAccessFile() async {
    Directory directory;
    String localPath;

    final permissisonReady = await checkPermission();

    if (permissisonReady) {
      localPath = (await _findLocalPath(_targetPlatform)) + '/EspacioJumex';

      directory = Directory(localPath);
      bool hasExisted = await directory.exists();
      if (!hasExisted) {
        directory.create();
      }
    }
    return directory;
  }

  Future<String> _findLocalPath(TargetPlatform targetPlatform) async {
    final directory = targetPlatform == TargetPlatform.android ? await getExternalStorageDirectory() : await getApplicationDocumentsDirectory();
    return directory.path;
  }

  Future<bool> checkPermission() async {
    if (_targetPlatform == TargetPlatform.android) {
      PermissionStatus permission = await Permission.storage.request();
      if (permission != PermissionStatus.granted) {
        Map<Permission, PermissionStatus> permissions = await [Permission.storage].request();
        if (permissions[Permission.storage] == PermissionStatus.granted) {
          return true;
        }
      } else {
        return true;
      }
    } else {
      return true;
    }
    return false;
  }

  Future<DeviceModel> getPlatformState() async {
    DeviceModel deviceData;
    try {
      if (Platform.isAndroid) {
        deviceData = _readAndroidBuildData(await deviceInfoPlugin.androidInfo);
      } else if (Platform.isIOS) {
        deviceData = _readIosDeviceInfo(await deviceInfoPlugin.iosInfo);
      }
    } on PlatformException {
      deviceData = DeviceModel();
    }

    return deviceData;
  }

  DeviceModel _readAndroidBuildData(AndroidDeviceInfo build) {
    return DeviceModel(
      baseOS: build.version.baseOS,
      codename: build.version.codename,
      device: build.device,
      host: build.host,
      manufacturer: build.manufacturer,
      model: build.model,
      product: build.product,
      versionRelease: build.version.release,
    );
  }

  DeviceModel _readIosDeviceInfo(IosDeviceInfo data) {
    return DeviceModel(
        baseOS: data.systemName,
        codename: data.systemVersion,
        device: data.localizedModel,
        host: data.utsname.nodename,
        manufacturer: data.identifierForVendor,
        model: data.model,
        name: data.name,
        product: data.utsname.machine,
        versionRelease: data.utsname.version);
  }

  Future<AppVersionModel> getAppVersion() async {
    var version = "";
    var buildNumber = "";

    try {
      var packageInfo = await PackageInfo.fromPlatform();
      version = packageInfo.version;
      buildNumber = packageInfo.buildNumber;
    } catch (e) {}

    return AppVersionModel(version: version, buildNumber: buildNumber);
  }
}
