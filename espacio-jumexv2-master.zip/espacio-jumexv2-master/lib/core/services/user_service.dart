import 'dart:async';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/configuration_model.dart';
import 'package:espacio_jumex/core/models/documento_model.dart';
import 'package:espacio_jumex/core/models/general_model.dart';
import 'package:espacio_jumex/core/models/accesoExternoContenido_model.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:espacio_jumex/core/models/request/userReq_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/application_service.dart';
import 'package:espacio_jumex/core/services/espaciojumex_api.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:flutter/cupertino.dart';

class UserService{
  final EspacioJumexApi _api;
  final ApplicationService _applicationService;
  final LocaldbService _localdbService;

  UserService({@required EspacioJumexApi api, ApplicationService applicationService, LocaldbService localdbService}):
    assert(api != null), 
    _api = api,
    _applicationService = applicationService,
    _localdbService = localdbService;

  StreamController<UserModel> _userController = StreamController<UserModel>();
  Stream<UserModel> get user => _userController.stream;

  StreamController<AccesosModel> _accesosController = StreamController<AccesosModel>();
  Stream<AccesosModel> get accesos => _accesosController.stream;

  Future<UserModel> reloadSession(UserModel user,String tokenFirebase) async{
    var response = await _api.reloadSession(user,tokenFirebase,await _applicationService.getPlatformState(), await _applicationService.getAppVersion());
    
    final userModel = UserModel.fromJson(response).copyWith(accessToken: user.tokenAcceso);

    _userController.add(userModel);
    await _localdbService.saveUser(userModel);

    return userModel;
  }

  Future<UserModel> postSignIn(UserReqModel user) async{
    var response = await _api.login(user, await _applicationService.getPlatformState(), await _applicationService.getAppVersion());

    final userModel = UserModel.fromJson(response);
    
    _userController.add(userModel);
    await _localdbService.saveUser(userModel);

    return userModel;
  }

  Future<bool> singOut(UserModel user) async{
    var response = await _api.singOut(user, await _applicationService.getPlatformState());
    var success = GeneralModel.fromJson(response).status.toLowerCase() != "error";
    _localdbService.logoutUser(user);
    return success;
  }

  Future<GeneralModel> postActualizarPassword(UserModel user,String password, String nuevoPassword) async{
    var response = await _api.postNuevoPassword(user,password,nuevoPassword);
    return GeneralModel.fromJson(response);
  }

  Future<List<ColaboradorModel>> getCumpleanios(UserModel user) async{
    var response = await _api.getBirthdays(user);
    return response?.map((x)=>ColaboradorModel.fromJson(x))?.toList()?.cast<ColaboradorModel>();
  }

  Future<void> postFelicitacionesCumpleanios(UserModel user,String mensaje,List<ColaboradorModel> colaboradores) async{
    await _api.postFelicitacionesCumpleanios(user,mensaje,colaboradores);
  }

  Future<bool> getActualizaConfiguracion(UserModel userModel, ConfigurationModel configurationModel) async{
    final response = await _api.getActualizaConfiguracion(userModel, configurationModel);
    final model = GeneralModel.fromJson(response);
    return model.status != "error" ;
  }

  Future<AccesosModel> getAccesos(UserModel userModel) async{
    final response = await _api.getAccesos(userModel);

    final accesos =  AccesosModel.fromJson(response["UserAccesos"]);
    final configurations = Configuracion.fromJson(response["UserConfiguraciones"]);

    _accesosController.add(accesos);
  
    await _localdbService.updateConfiguration(configurations.cumpleanios);
    await _localdbService.updateConfiguration(configurations.cumpleaniosColaborador);
    _localdbService.updateAccesos(accesos);

    return accesos;
  }

  void actualizaAccesos(AccesosModel accesosModel) async{
    _accesosController.add(accesosModel);
    _localdbService.updateAccesos(accesosModel);
  }
  
  Future<List<AccesoExternoContenidoModel>> getContenidoAcceso(UserModel userModel,AccesoModel accesoModel) async{
    final response = await _api.getContenidoAcceso(userModel, accesoModel);
    return response.map<AccesoExternoContenidoModel>((x)=>AccesoExternoContenidoModel.fromJson(x)).toList();
  }

  Future<List<DocumentoModel>> getAvisosLegales(UserModel userModel) async{
    final response = await _api.getAvisos(userModel);
    return response.map<DocumentoModel>((x)=>DocumentoModel.fromJson(x)).toList();
  }

  Future<GeneralModel> aprobarAvisoLegal(UserModel userModel, DocumentoModel documento) async{
    final response = await _api.getAprobarDocumento(userModel, documento);
    return GeneralModel.fromJson(response);
  }

  Future<GeneralModel> recuperarContrasenia(String usuario) async{
    var result = await _api.getRecuperarContrasenia(usuario);
    return GeneralModel.fromJson(result);
  }

  Future<List<NotificacionModel>> getNotificaciones(UserModel userModel) async{
    final response = await _api.getNotificaciones(userModel);
    return response.map<NotificacionModel>((x)=>NotificacionModel.fromJson(x)).toList();
  }

  Future<NotificacionesModel> getNotificacionesSinLeer(UserModel userModel) async{
    final response = await _api.getNotificacionesSinLeer(userModel);
    return NotificacionesModel.fromJson(response);
  }
}