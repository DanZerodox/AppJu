import 'dart:async';

import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter_uploader/flutter_uploader.dart';

class UploaderService{
  final FlutterUploader uploader = FlutterUploader();
  final LocaldbService _localdbService;

  UploaderService({LocaldbService localdbService}): 
  _localdbService = localdbService{
    _progressSubscription = uploader.progress.listen(_progressListener);
    _resultSubscription = uploader.result.listen(_onResult,onError: _onError);
  }

  StreamController<UploadTask> _queueController = StreamController<UploadTask>();
  Stream<UploadTask> get queue => _queueController.stream;

  StreamSubscription _progressSubscription;
  StreamSubscription _resultSubscription;
  String taskId;

  Future<void> enqueue(UserModel userModel, String tag, String url, dynamic data, {List<FileItem> files, UploadMethod uploadMethod = UploadMethod.POST, bool notification = false}) async{

    taskId = await uploader.enqueue(
      url: url,
      method: uploadMethod,
      tag: tag,
      headers: <String,String>{
        'token': "${userModel.tokenAcceso}"
      },
      data: data,
      showNotification: notification,
      files: files,
    );

    _localdbService.updateAvisoQueue(task: taskId, title: tag);
  }

  void _progressListener(UploadTaskProgress task){
    _queueController.add(UploadTask(
      taskId: task.taskId,
      title: task.tag,
      status: _resolveStatus(task.status)
    ));
  }

  Status _resolveStatus(UploadTaskStatus status){
    if(status == UploadTaskStatus.enqueued
      || status == UploadTaskStatus.running
    ){
      return Status.busy;
    }else if(status == UploadTaskStatus.failed 
      ||status == UploadTaskStatus.canceled){
        return Status.error;
    }else{
      return Status.free;
    }
  }

  void _onError(ex, stacktrace){
    addQueue(UploadTask(
      taskId: taskId,
      status: Status.error
    ));
    _localdbService.deleteAvisoQueue();
  }

  void _onResult(UploadTaskResponse result){
    var status  = _resolveStatus(result.status);
    addQueue(UploadTask(
      taskId: result.taskId,
      title: result.tag,
      status: status
    ));

    if(status == Status.free)
      _localdbService.deleteAvisoQueue();
  }

  void dispose() { 
    _progressSubscription?.cancel();
    _resultSubscription?.cancel();
    _queueController?.close();
  }

  void addQueue(UploadTask task){
    _queueController.add(task);
  }
}

class UploadTask{
  final String title;
  final String taskId;
  final Status status;

  const UploadTask({this.title, this.taskId, this.status});
}