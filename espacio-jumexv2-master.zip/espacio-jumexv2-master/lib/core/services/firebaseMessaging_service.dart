import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:espacio_jumex/main.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NavigationService {
  final GlobalKey<NavigatorState> navigatorKey = new GlobalKey<NavigatorState>();

  Future<dynamic> navigateTo(String routeName, {Object args}) {
    return navigatorKey.currentState.pushNamedAndRemoveUntil(routeName, (route) {
      return false;
    }, arguments: args);
  }

  void goBack() {
    return navigatorKey.currentState.pop();
  }
}

class FirebaseMessagingService {
  static FirebaseMessagingService _instance;
  static FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin = new FlutterLocalNotificationsPlugin();

  factory FirebaseMessagingService() {
    if (_instance == null) {
      _instance = FirebaseMessagingService._();
    }
    return _instance;
  }

  FirebaseMessagingService._() {
    // save the client so that it can be used else where
    _firebaseMessaging = FirebaseMessaging();
    // setup listeners
    _firebaseCloudMessagingListeners();
    _localNotificationsInit();
  }

  // get the message stream
  //MessageStream _messageStream = MessageStream.instance;
  final _messagesStreamController = StreamController<NotificacionModel>.broadcast();
  Stream<NotificacionModel> get messages => _messagesStreamController.stream;

  FirebaseMessaging _firebaseMessaging;

  // getter for firebase messaging client
  get firebaseMessaging => _firebaseMessaging;

  // method for getting the messaging token
  Future<String> getToken() async {
    String token = await _firebaseMessaging.getToken();
    return token;
  }

  void _firebaseCloudMessagingListeners() {
    if (Platform.isIOS) getIOSPermission();

    _firebaseMessaging.configure(
        onMessage: (Map<String, dynamic> message) async {
          var model = NotificacionModel.fromMessage(message);

          print('on message $message');
          print('on message $model');

          addMessage(model);
          showNotification(model, RoutePath.Home);
        },
        onResume: (Map<String, dynamic> message) async {
          var model = NotificacionModel.fromMessage(message);

          print('on resume $message');
          print('on resume $model');

          addMessage(model);
        },
        onLaunch: (Map<String, dynamic> message) async {
          var model = NotificacionModel.fromMessage(message);

          print('on launch $message');
          print('on launch $model');

          addMessage(model);
        },
        onBackgroundMessage: Platform.isIOS ? null : myBackgroundMessageHandler);

    for (var topic in ApiConstant.firebaseTopics) {
      _firebaseMessaging.subscribeToTopic(topic).then((_) {
        print("Registered topic $topic");
      });
    }
  }

  void addMessage(NotificacionModel model) {
    _messagesStreamController.sink.add(model);
  }

  void getIOSPermission() {
    _firebaseMessaging.requestNotificationPermissions(IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.onIosSettingsRegistered.listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
  }

  void unsubscribeAllTopics() {
    for (var topic in ApiConstant.firebaseTopics) {
      unsubscribeTopic(topic);
    }
  }

  void unsubscribeTopic(String firebaseTopic) {
    _firebaseMessaging.unsubscribeFromTopic(firebaseTopic).then((_) {
      print("Un Registered topic $firebaseTopic");
    });
  }

  void dispose() {
    _messagesStreamController.close();
  }

  void _localNotificationsInit() {
    var android = new AndroidInitializationSettings("ic_stat");
    var ios = new IOSInitializationSettings();
    var platform = new InitializationSettings(android: android, iOS: ios);
    _flutterLocalNotificationsPlugin.initialize(platform, onSelectNotification: _onSelectNotification);
  }

  Future _onSelectNotification(String payload) async {
    locator<NavigationService>().navigateTo(payload, args: 2);
  }

  static void showNotification(NotificacionModel model, String route) async {
    var vibrationPattern = new Int64List(4);
    vibrationPattern[0] = 0;
    vibrationPattern[1] = 1000;
    vibrationPattern[2] = 5000;
    vibrationPattern[3] = 2000;

    var android = new AndroidNotificationDetails(
      "channel id",
      "channel name",
      "channel description",
      vibrationPattern: vibrationPattern,
    );
    var ios = new IOSNotificationDetails();
    var platform = new NotificationDetails(android: android, iOS: ios);

    await _flutterLocalNotificationsPlugin.show(0, model.title, model.body, platform, payload: route);
  }
}

Future<dynamic> myBackgroundMessageHandler(Map<String, dynamic> message) async {
  // await Firebase.initializeApp();

  var model = NotificacionModel.fromMessage(message);
  print('on backgroundMessage $message');
  print('on backgroundMessage $model');

  FirebaseMessagingService.showNotification(model, RoutePath.PreHome);

  return Future<void>.value();
  // Or do other work.
}
