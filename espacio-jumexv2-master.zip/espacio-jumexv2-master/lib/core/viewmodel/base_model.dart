import 'package:espacio_jumex/core/exceptions/exceptions.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

enum Status{
  busy,
  free,
  error,
  unauthorized,
}

class BaseModel extends ChangeNotifier {
  Status _status = Status.free;
  String _message;

  Status get status => _status;
  get message =>_message;

  void busy() {
    _status = Status.busy;
    notifyListeners();
  }

  void free([String message="",Status status = Status.free]) {
    _status = status;
    _message = message;
    notifyListeners();
  }

  void unauthorized() {
    _status = Status.unauthorized;
    notifyListeners();
  }

  void error(String message){
    _message = message;
    _status = Status.error;
    notifyListeners();
  }

  void errorException(Object e){
    _status = Status.error;
    if(e is UnauthorizedException){
      _message = "La sesión a caducado";
      _status = Status.unauthorized;
    }
    else if(e is EspacioJumexAppException){
      _message = e.cause;
    }else{
       _message = e.toString();
    }
    notifyListeners();
  }
}

class BaseModelIterator extends BaseModel{
  int _itemCount = 0;
  bool _pullMore = false;

  int get itemCount => _itemCount;
  set itemCount(int count){
    _itemCount = count;
    notifyListeners();
  }

  get pullMore => _pullMore;
  set more(int count)=>_pullMore = count>0;

  @override
  void free([String message = "", Status status = Status.free,  int count = 0]) {
    _itemCount = count;
    super.free(message, status);
  }
}