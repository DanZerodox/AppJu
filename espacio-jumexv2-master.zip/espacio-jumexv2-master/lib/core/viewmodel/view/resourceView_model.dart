import 'dart:io';
import 'package:espacio_jumex/core/infrastructure/customCacheManager.dart';
import 'package:espacio_jumex/core/models/revistaJumex_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/resource_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/foundation.dart';

class ResourceViewModel extends BaseModel{
  final ResourceService _resourceService;
  final CustomCacheManager _customCacheManager;

  ResourceViewModel({
    @required ResourceService resourceService,
    @required CustomCacheManager customCacheManager
  }): _resourceService = resourceService,
    _customCacheManager = customCacheManager;

  List<RevistaJumexModel> revistas;
  String pathFile;

  Future<Null> consultaRevistas(UserModel userModel) async{
    busy();
    
    try{
      final resourceRevistas = await _resourceService.consultarRevistaJumex(userModel);
      revistas = resourceRevistas;
      free();

    } catch(e){
      errorException(e);
    }
  }

  Future<Null> consultarRecursoPdf(UserModel userModel, String url) async{
    busy();
    try{

      File f = await _customCacheManager.getSingleFile(url,headers: {
        'token': userModel.tokenAcceso
      });
      pathFile = f.path;
      free();

    } catch(e){
      errorException(e);
    }
  }
}