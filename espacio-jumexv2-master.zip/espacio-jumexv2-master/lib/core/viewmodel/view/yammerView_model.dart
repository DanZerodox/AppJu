import 'dart:io';

import 'package:espacio_jumex/core/models/request/avisoOportunoReq_model.dart';
import 'package:espacio_jumex/core/models/avisoOportuno_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/util/utils.dart' as util show getFileNameWithExtension;
import 'package:espacio_jumex/core/models/yammer_model.dart';
import 'package:espacio_jumex/core/services/application_service.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:espacio_jumex/core/services/yammer_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:flutter_uploader/flutter_uploader.dart' show FileItem;

class YammerViewModel extends BaseModelIterator {
  final YammerService _yammerService;
  final LocaldbService _localdbService;
  final ApplicationService _applicationService;

  YammerViewModel({
    @required YammerService yammerService,
    LocaldbService localdbService,
    ApplicationService applicationService,
  })  : _yammerService = yammerService,
        _localdbService = localdbService,
        _applicationService = applicationService,
        assert(yammerService != null || localdbService != null);

  List<YammerModel> yammers = <YammerModel>[];
  String yammerVideoUrl;
  List<YammerMessagesModel> avisos = <YammerMessagesModel>[];
  bool pendientes = false;
  AvisoOportunoModel aviso;

  bool _first = true;

  Future<void> consultaMensajesNuevos(UserModel userModel, String groupId) async {
    try {
      final lyammer = await _localdbService.getRecentYammer(groupId);
      yammers = await _localdbService.getYammers(groupId);
      var update = await _localdbService.getLastUpdate(groupId);

      if (!_first || lyammer == null || DateTime.now().difference(update).inHours >= 12) {
        var response = await _yammerService.getMensajesYammer(userModel, groupId);

        if (response.length > 0) {
          //Mensajes nuevos
          _localdbService.saveYammer(response, groupId);
        }

        yammers
          ..clear()
          ..addAll(response);
      }

      _first = false;
      more = 1;
      free("", Status.free, yammers.length);
    } catch (e) {
      errorException(e);
    }
  }

  Future<void> consultaMensajesAnteriores(UserModel userModel, String groupId, {String olderThan = "0"}) async {
    busy();
    try {
      final response = await _yammerService.getMensajesYammer(userModel, groupId, olderThan: olderThan);
      if (response != null && yammers != null) {
        yammers.insertAll(yammers.length, response);
      }
      more = response?.length ?? 0;
      free("", Status.free, yammers.length);
    } catch (e) {
      errorException(e);
    }
  }

  Future<void> consultaMisPublicaciones(UserModel userModel) async {
    busy();
    try {
      avisos = await _yammerService.getMisPublicaciones(userModel);
      pendientes = avisos.any((x) => x.estatus == "INIT" || x.estatus == "PENB") || await _localdbService.getAvisoQueue() != 0;
      if (!pendientes) _yammerService.clearUploadQueue();

      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<void> consultaMiPublicacion(UserModel userModel, String messageId) async {
    busy();
    try {
      aviso = await _yammerService.consultaMiPublicacion(userModel, messageId);
      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<void> subiendoAviso() async {
    pendientes = await _localdbService.getAvisoQueue() != 0;
    free();
  }

  Future<bool> eliminarPublicacion(UserModel userModel, YammerMessagesModel yammerMessagesModel) async {
    var success = false;
    try {
      final response = await _yammerService.getEliminarPublicacion(userModel, yammerMessagesModel);
      success = response.status != "error";

      if (success) {
        avisos = await _yammerService.getMisPublicaciones(userModel);
        pendientes = avisos.any((x) => x.estatus == "INIT");
      }

      free(response.mensaje, success ? Status.free : Status.error);
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<bool> publicarAnuncio(UserModel userModel, AvisoOportunoReqModel avisoOportunoReq, List<File> images) async {
    var success = false;
    final List<String> files = <String>[];

    try {
      if (images == null || images.isEmpty) {
        error("Favor de seleccionar por lo menos una foto");
        return success;
      }

      final path = await _applicationService.prepareAccessFile();

      for (var item in images) {
        final bytes = await _compressFile(item);
        final name = await util.getFileNameWithExtension(item);
        files.add(name);
        _writeToFile(bytes, "${path.path}/$name");
      }

      final ufiles = files.map<FileItem>((x) => FileItem(filename: x, savedDir: "${path.path}", fieldname: "file")).toList();

      await _yammerService.postPublicarAnuncio(userModel, avisoOportunoReq, ufiles);

      pendientes = true;
      success = true;

      free("Se está procesando tu artículo", success ? Status.free : Status.error);
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  void _writeToFile(List<int> image, String filePath) {
    final file = File(filePath);
    file.writeAsBytes(image, flush: true, mode: FileMode.write);
  }

  Future<List<int>> _compressFile(File file) async {
    var result = await FlutterImageCompress.compressWithFile(
      file.absolute.path,
      minWidth: 2300,
      minHeight: 1500,
      quality: 95,
    );
    return result;
  }

  String urlVideo;
  Future<String> consultarUrlVideo(String url) async {
    busy();
    try {
      urlVideo = await _yammerService.consultarUrlVideo(url);
      free();
    } catch (e) {
      errorException(e);
    }
    return url;
  }
}
