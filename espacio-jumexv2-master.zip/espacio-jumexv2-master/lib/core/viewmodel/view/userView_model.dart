import 'package:espacio_jumex/core/exceptions/exceptions.dart';
import 'package:espacio_jumex/core/models/colaborador_model.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:espacio_jumex/core/models/request/userReq_model.dart';
import 'package:espacio_jumex/core/models/selectableItem.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/firebaseMessaging_service.dart';
import 'package:espacio_jumex/core/services/user_service.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/foundation.dart';

class UserViewModel extends BaseModel {
  final UserService _userService;
  final LocaldbService _localdbService;
  final FirebaseMessagingService _firebaseMessagingService;

  UserViewModel({
    @required UserService userService,
    LocaldbService localdbService,
    FirebaseMessagingService firebaseMessagingService,
  })  : assert(userService != null),
        _userService = userService,
        _localdbService = localdbService,
        _firebaseMessagingService = firebaseMessagingService;

  List<SelectableItem<ColaboradorModel>> colaboradores = new List<SelectableItem<ColaboradorModel>>();
  UserModel userModel;
  UserReqModel userReqModel = new UserReqModel(rememberme: 1);

  Future<Null> fetchUser() async {
    busy();
    userModel = await _localdbService.getUser();
    userReqModel.userNumber = userModel?.usuario?.toString() ?? "";
    free();
  }

  void setReqUser(String value) {
    userReqModel.userNumber = value;
    free();
  }

  void setReqPassword(String value) {
    userReqModel.password = value;
    free();
  }

  void setReqRememberMe(bool value) {
    userReqModel.rememberme = value ? 1 : 0;
    free();
  }

  Future<bool> fetchSession() async {
    busy();

    try {
      userModel = await _localdbService.getUser();

      if (userModel != null && userModel.tokenAcceso != null) {
        final firebase = await _firebaseMessagingService.getToken();
        final luser = await _userService.reloadSession(userModel, firebase);

        if (luser != null) {
          userModel = luser;
          await _userService.getAccesos(userModel);

          var total = await _userService.getNotificacionesSinLeer(userModel);
          if (total.totalUnread > 0) {
            _firebaseMessagingService.addMessage(NotificacionModel());
          }

          free();
          return true;
        }
      }
      unauthorized();
    } on UnauthorizedException catch (e) {
      _firebaseMessagingService.unsubscribeAllTopics();
      _localdbService.logoutUser(userModel);
      error(e.cause);
    } catch (e) {
      errorException(e);
    }

    return false;
  }

  Future<bool> signIn() async {
    var success = false;
    try {
      final firebaseToken = await _firebaseMessagingService.getToken();
      userReqModel.firebaseToken = firebaseToken;

      userModel = await _userService.postSignIn(userReqModel);
      success = userModel != null;

      if (success) {
        await _userService.getAccesos(userModel);
      }

      free();
    } on UnauthorizedException {
      error("Usuario o contraseña incorrecta");
    } catch (e) {
      errorException(e);
    }
    return success;
  }

  Future<bool> updatePassword(UserModel userModel, String password, String nuevoPassword) async {
    busy();
    var success = false;
    try {
      var response = await _userService.postActualizarPassword(userModel, password, nuevoPassword);
      success = response.status != "error";
      if (success) {
        _firebaseMessagingService.unsubscribeAllTopics();
        success = await _userService.singOut(userModel);
      }

      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<Null> consultaCumpleanios(UserModel userModel) async {
    busy();
    try {
      var result = await _userService.getCumpleanios(userModel);
      colaboradores = result.map((e) => SelectableItem(item: e)).toList();
      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<bool> enviarFelicitacionesCumpleanios(UserModel userModel, String mensaje, List<ColaboradorModel> colaboradoresList) async {
    var success = false;
    try {
      await _userService.postFelicitacionesCumpleanios(userModel, message, colaboradoresList);
      success = true;
      free("Mensaje enviado");
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  void selectColaborador(ColaboradorModel colaborador) {
    colaboradores.firstWhere((e) => e.item.numeroEmpleado == colaborador.numeroEmpleado).isSelected = true;
    free();
  }

  void resetSelectedColaboradores() {
    colaboradores.forEach((e) {
      e.isSelected = false;
    });
    free();
  }

  Future<bool> recuperarContrasenia(String usuario) async {
    busy();

    var success = false;
    try {
      var result = await _userService.recuperarContrasenia(usuario);
      success = result.status != "error";
      free(result.mensaje);
    } catch (e) {
      errorException(e);
    }

    return success;
  }
}
