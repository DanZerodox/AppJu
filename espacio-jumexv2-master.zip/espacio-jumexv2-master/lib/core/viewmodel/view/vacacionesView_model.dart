
import 'package:async/async.dart';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/request/solicitudVacacionesReq_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/models/vacaciones_model.dart';
import 'package:espacio_jumex/core/services/nomina_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:intl/intl.dart';

class VacacionesViewModel extends BaseModel{
  NominaService _nominaService;

  VacacionesViewModel({NominaService nominaService}):
    _nominaService = nominaService;

  InformacionVacacionesModel informacionVacaciones;
  SolicitudesVacacionesWrapModel vacaciones;
  List<SolicitudVacacionesModel> solicitudesPorAutorizar;
  bool init = true;

  AsyncMemoizer _memoizerDatos = AsyncMemoizer();
  AsyncMemoizer _memoizerSolicitudes = AsyncMemoizer();
  AsyncMemoizer _memoizerPendientes = AsyncMemoizer();

  Status statusSolicitudes = Status.busy;
  Status statusPendientes = Status.busy;

  final dateFormatter = DateFormat(Constants.dateFormat);

  Future<Null> consultaDatosVacaciones(UserModel userModel) async{
    try{
      busy();

      informacionVacaciones = await _memoizerDatos.runOnce(() =>  _nominaService.getVacaciones(userModel));
      init = true;

      free();

    } catch(e){
      errorException(e);
    }
  }

  Future<Null> consultaSolicitudesVacaciones(UserModel userModel, [bool pinit = false, bool refresh = false]) async{
    
    try{

      init = pinit;
      statusSolicitudes = Status.busy;
      free();

      if(!pinit || refresh) _memoizerSolicitudes = AsyncMemoizer();

      vacaciones = await _memoizerSolicitudes.runOnce(() => _nominaService.getSolicitudesVacaciones(userModel));
      init = false;
      statusSolicitudes = Status.free;

      free();

    } catch(e){
      errorException(e);
    }
  }

  Future<Null> consultaVacacionesPorAutorizar(UserModel userModel,[bool pinit = false]) async{
    try{
      init = pinit;
      statusPendientes = Status.busy;
      free();

      if(!pinit) _memoizerPendientes = AsyncMemoizer();

      solicitudesPorAutorizar= await _memoizerPendientes.runOnce(() => _nominaService.getVacacionesPorAutorizar(userModel));
      init = false;
      statusPendientes = Status.free;

      free();

    } catch(e){
      errorException(e);
    }
  }

  Future<bool> enviarSolicitudVacaciones(UserModel userModel,DateTime fechaInicio,DateTime fechaFin,String comentarios) async{
    busy();
    var success = false;
    try{
      final response = await _nominaService.postSolicitudVacaciones(userModel, SolicitudVacacionesReqModel(
        fechaInicio: dateFormatter.format(fechaInicio),
        fechaFin: dateFormatter.format(fechaFin),
        comentarios: comentarios
      ));

      // final response = await Future.delayed(Duration(seconds: 2),()=>GeneralModel(status: "ok", mensaje: "Error al enviar"));
      success = response.status != "error";

      free(response.mensaje);

    } catch(e){
      errorException(e);
    }
    return success;
  }

  Future<bool> borrarSolicitudVacaciones(UserModel userModel,SolicitudVacacionesModel solicitudVacaciones) async{

    var success = false;
    try{
      final response = await _nominaService.getBorrarSolicitudVacaciones(userModel,solicitudVacaciones);
      success = response.status != "error";
      free(response.mensaje);

    } catch(e){
      errorException(e);
    }
    return success;
  }

  Future<bool> autorizarVacaciones(UserModel userModel,SolicitudVacacionesModel solicitudVacaciones) async{

    var success = false;
    try{
      final response = await _nominaService.postAutorizarVacaciones(userModel,solicitudVacaciones);
      // final response = await Future.delayed(Duration(seconds: 2),()=>GeneralModel(status: "ok", mensaje: "Error al enviar"));
      success = response.status != "error";
      free(response.mensaje);

    } catch(e){
      errorException(e);
    }

    return success;
  }

  Future<bool> rechazarVacaciones(UserModel userModel,SolicitudVacacionesModel solicitudVacaciones) async{

    var success = false;
    try{
      final response = await _nominaService.postRechazarVacaciones(userModel,solicitudVacaciones);
      success = response.status != "error";
      free(response.mensaje);

    } catch(e){
      errorException(e);
    }
    return success;
  }
}