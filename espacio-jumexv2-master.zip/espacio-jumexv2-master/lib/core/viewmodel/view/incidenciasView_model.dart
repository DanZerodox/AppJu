import 'package:async/async.dart';
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/incidencia_model.dart';
import 'package:espacio_jumex/core/models/preevaluate_model.dart';
import 'package:espacio_jumex/core/models/request/incidenciaReq_model.dart';
import 'package:espacio_jumex/core/models/selectableItem.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/nomina_service.dart';
import 'package:espacio_jumex/core/util/utils.dart' show toDouble;
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class IncidenciasViewModel extends BaseModel {
  NominaService _nominaService;

  IncidenciasViewModel({NominaService nominaService}) : _nominaService = nominaService;

  final dateFormat = DateFormat(Constants.dateFormat);
  final hourFormat = DateFormat("HH:mm");

  Comparator<MarcajeModel> fechaComparator = (a, b) {
    final f = DateFormat(Constants.dateFormat);
    return f.parse(a.fecha).compareTo(f.parse(b.fecha));
  };

  List<IncidenciaValueModel> tipoIncidenciaList = <IncidenciaValueModel>[];
  AsyncMemoizer _memoizerInciCatalog = AsyncMemoizer();

  List<SelectableItem<MarcajeModel>> preevaluate;
  List<MarcajeModel> fechasIncidencia = new List<MarcajeModel>();

  DateTime fechaFin;
  DateTime fechaConsulta;
  DateTime horaInicio;
  DateTime horaFin;
  IncidenciaValueModel incidencia;
  int maxDiasIncidencia = 0;
  String comentarios = "";

  Future<Null> consultarIncidenciasCatalogo(UserModel userModel) async {
    busy();
    try {
      tipoIncidenciaList = await _memoizerInciCatalog.runOnce(() => _nominaService.getIncidenciasCatalogo(userModel));
      if (!tipoIncidenciaList.any((element) => element.valor == "")) {
        tipoIncidenciaList.insert(0, new IncidenciaValueModel(texto: "Selecciona una opción", valor: ""));
      }
      incidencia = incidencia ?? tipoIncidenciaList[0];
      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<bool> consultaFechasPreevaluacion(UserModel userModel, DateTime date) async {
    var success = false;
    try {
      fechaConsulta = date;
      preevaluate = null;

      if (date.difference(DateTime.now()).inHours <= 0) {
        var result = await _nominaService.postPreevaluate(userModel, dateFormat.format(date));

        preevaluate = result?.marcajes?.where((x) {
          final showFecha = dateFormat.parse(x.fecha).difference(DateTime.now()).inDays * -1 < 30;

          return showFecha && x.entrada.trim() != "DESC" && x.incidencia.trim().isEmpty && x.observacion.trim().isEmpty;
        })?.map((e) {
          final selected = fechasIncidencia.any((l) => l.fecha == e.fecha);

          return SelectableItem<MarcajeModel>(item: e, isSelected: selected);
        })?.toList();
      }

      success = true;
      free();
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  bool addFechaIncidencia(MarcajeModel marcajeModel) {
    var success = true;

    if (fechasIncidencia.indexOf(marcajeModel) >= 0) {
      fechasIncidencia.remove(marcajeModel);
      preevaluate.firstWhere((element) => element.item.fecha == marcajeModel.fecha).isSelected = false;
      free();
    } else {
      if (incidencia.maxDias == 0 || fechasIncidencia.length < incidencia.maxDias) {
        fechasIncidencia.add(marcajeModel);
        preevaluate.firstWhere((element) => element.item.fecha == marcajeModel.fecha).isSelected = true;

        fechasIncidencia.sort((a, b) => a.fecha.compareTo(b.fecha));

        free();
      } else {
        success = false;
        free("Esta incidencia sólo puedes justificar hasta ${incidencia.maxDias} dia(s)");
      }
    }

    fechasIncidencia.sort(fechaComparator);
    return success;
  }

  void setTipoIncidencia(IncidenciaValueModel value) {
    incidencia = value;
    maxDiasIncidencia = value.maxDias;

    free();
  }

  void setFechaConsulta(DateTime value) {
    fechaConsulta = value;
    fechaFin = null;

    preevaluate = null;
    fechasIncidencia.clear();

    free();
  }

  void setFechaFin(DateTime value) {
    fechaFin = value;
    free();
  }

  void setHoraInicio(DateTime value) {
    horaInicio = value;
    free();
  }

  void setHoraFin(DateTime value) {
    horaFin = value;
    free();
  }

  void setComentarios(String value) {
    comentarios = value;
    free();
  }

  Future<bool> agregarIncidencia(UserModel userModel) async {
    var success = false;
    var errorFlag = false;
    var detalleError = "";

    try {
      if (incidencia.capturarHoras > 0) {
        if (_validaHorario(horaInicio, horaFin)) {
          fechasIncidencia.forEach((e) {
            if (!_validaHorario((e.entrada ?? '').isNotEmpty ? hourFormat.parse(e.entrada.substring(0, 5)) : null, horaInicio) ||
                !_validaHorario(horaFin, (e.salida ?? '').isNotEmpty ? hourFormat.parse(e.salida.substring(0, 5)) : null)) {
              errorFlag |= true;
              detalleError = "La hora seleccionada está fuera del horario laboral (error en fecha: ${e.fecha} ${e.entrada.substring(0, 5)} - ${e.salida.substring(0, 5)}).";
            }
          });
        } else {
          errorFlag = true;
          detalleError = "La hora de termino no puede ser previa a la de inicio";
        }
      }

      if (fechasIncidencia.length > incidencia.maxDias) {
        errorFlag = true;
        detalleError = "Se han seleccionado más fechas que los que permite la incidencia, favor de validar.";
      }

      if (!errorFlag) {
        var result = await _nominaService.postIncidencia(
            userModel,
            new IncidenciaReqModel(
                fechas: fechasIncidencia.map((e) => e.fecha).toList(),
                horaInicio: incidencia.capturarHoras > 0 ? hourFormat.format(horaInicio) : "",
                horaFin: incidencia.capturarHoras > 0 ? hourFormat.format(horaFin) : "",
                comentarios: comentarios ?? "",
                tipo: incidencia.valor));
        //var result = await Future.delayed(Duration(seconds: 2),()=>new GeneralModel(status: "ok", mensaje: "Incidencia agregada"));

        success = result.status != 'error';

        if (!success)
          error(result.mensaje);
        else
          free(result.mensaje);
      } else {
        error(detalleError);
      }
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  bool _validaHorario(DateTime horaA, DateTime horaB) {
    if (horaA != null && horaB != null) {
      var i = TimeOfDay.fromDateTime(horaA);
      var f = TimeOfDay.fromDateTime(horaB);

      return toDouble(i) < toDouble(f);
    } else {
      return true;
    }
  }

  PreevaluateModel preevaluacion;
  DateTime fechaPreevaluar;
  final _formatter = DateFormat(Constants.dateFormat);

  AsyncMemoizer _memoizerIncidencias = AsyncMemoizer();
  AsyncMemoizer _memoizerInciPendientes = AsyncMemoizer();

  Status statusInci;
  Status statusInciPendientes;
  bool initIncidencias = true;
  List<IncidenciaModel> incidencias = new List<IncidenciaModel>();
  List<IncidenciaPendienteModel> incidenciasPorAutorizar = new List<IncidenciaPendienteModel>();

  Future<bool> consultaPreevaluacion(UserModel userModel, DateTime date) async {
    var success = false;
    try {
      fechaPreevaluar = date;
      preevaluacion = await _nominaService.postPreevaluate(userModel, _formatter.format(fechaPreevaluar));
      preevaluacion = preevaluacion.copyWith(marcajes: preevaluacion.marcajes.where((x) => x.entrada.trim() != "DESC").toList());
      success = true;
      free();
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<Null> consultaIncidencias(UserModel userModel, [bool pinit = false, bool refresh = false]) async {
    try {
      initIncidencias = pinit;
      statusInci = Status.busy;
      free();

      if (!pinit || refresh) _memoizerIncidencias = AsyncMemoizer();

      incidencias = await _memoizerIncidencias.runOnce(() => _nominaService.getIncidencias(userModel));
      initIncidencias = false;
      statusInci = Status.free;

      free();
    } catch (e) {
      statusInciPendientes = Status.error;
      errorException(e);
    }
  }

  Future<Null> consultaIncidenciasPendientes(UserModel userModel, [bool pinit = false]) async {
    try {
      initIncidencias = pinit;
      statusInciPendientes = Status.busy;
      free();

      if (!pinit) _memoizerInciPendientes = AsyncMemoizer();

      incidenciasPorAutorizar = await _memoizerInciPendientes.runOnce(() => _nominaService.getIncidenciasPendientes(userModel));
      initIncidencias = false;
      statusInciPendientes = Status.free;

      free();
    } catch (e) {
      statusInciPendientes = Status.error;
      errorException(e);
    }
  }

  Future<bool> borrarIncidencia(UserModel userModel, IncidenciaModel incidenciaModel) async {
    var success = false;
    try {
      final response = await _nominaService.getBorrarIncidencia(userModel, incidenciaModel);
      success = response.status != "error";
      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }
    return success;
  }

  Future<bool> autorizarIncidencia(UserModel userModel, IncidenciaPendienteModel solicitud) async {
    var success = false;
    try {
      final response = await _nominaService.getAutorizarIncidencia(userModel, solicitud);
      // final response = await Future.delayed(Duration(seconds: 2),()=>GeneralModel(status: "ok", mensaje: "Error al enviar"));
      success = response.status != "error";
      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<bool> rechazarIncidencia(UserModel userModel, IncidenciaPendienteModel incidencia, String comentarios) async {
    var success = false;
    try {
      final response = await _nominaService.postRechazarIncidencia(userModel, new IncidenciaRechazoReqModel(id: incidencia.id, tipo: incidencia.tipo, motivo: comentarios));
      // final response = await Future.delayed(Duration(seconds: 2),()=>GeneralModel(status: "ok", mensaje: "Error al enviar"));
      success = response.status != "error";
      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }

    return success;
  }
}
