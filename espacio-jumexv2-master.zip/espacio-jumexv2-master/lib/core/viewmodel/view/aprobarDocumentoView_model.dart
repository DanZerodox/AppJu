import 'package:espacio_jumex/core/models/documento_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/user_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/foundation.dart';

class AprobarDocumentoViewModel extends BaseModelIterator{
  UserService _userService;

  AprobarDocumentoViewModel({
    @required UserService userService
  }):
    _userService = userService,
    assert(userService != null);

  List<DocumentoModel> documentos;
  int aprobar = 0;

  Future<Null> consultarAvisosLegales(UserModel userModel) async{
    busy();
    try {
      documentos = await _userService.getAvisosLegales(userModel);

      aprobar = documentos.length;
      free("", Status.free,documentos.length);
    } catch (e) {
      errorException(e);
    }
  }

  Future<bool> aprobarAvisoLegal(UserModel userModel, DocumentoModel documento) async{
    var success = false;
    try {
      var result = await _userService.aprobarAvisoLegal(userModel,documento);
      success = result.status!= "error";

      if(success) {
        documentos = await _userService.getAvisosLegales(userModel);

        aprobar-=1;
      }
      free(result.mensaje);
    } catch (e) {
      errorException(e);
    }
    return success;
  }
  
}