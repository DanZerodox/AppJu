import 'dart:async';
import 'package:espacio_jumex/core/infrastructure/customCacheManager.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/accesoExternoContenido_model.dart';
import 'package:espacio_jumex/core/models/configuration_model.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:espacio_jumex/core/models/selectableItem.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/application_service.dart';
import 'package:espacio_jumex/core/services/firebaseMessaging_service.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:espacio_jumex/core/services/nomina_service.dart';
import 'package:espacio_jumex/core/services/user_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';

class AppViewModel extends BaseModel {
  final LocaldbService _localdbService;
  final UserService _userService;
  final NominaService _nominaService;
  final FirebaseMessagingService _firebaseMessagingService;
  final ApplicationService _applicationService;

  AppViewModel(
      {UserService userService,
      LocaldbService localdbService,
      NominaService nominaService,
      FirebaseMessagingService firebaseMessagingService,
      ApplicationService applicationService})
      : _localdbService = localdbService,
        _userService = userService,
        _nominaService = nominaService,
        _firebaseMessagingService = firebaseMessagingService,
        _applicationService = applicationService;

  List<AccesoExternoContenidoModel> contenidoModel;
  Configuracion configuracion;
  String appVersion;

  List<SelectableItem<NotificacionModel>> _cnotificaciones = [];
  List<SelectableItem<NotificacionModel>> notificaciones = [];
  bool init = false;

  String tipoNotificacion = "--";

  Future<bool> signOut(UserModel user) async {
    var success = false;
    try {
      _firebaseMessagingService.unsubscribeAllTopics();
      success = await _userService.singOut(user);
      free();
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<bool> actualizaAcceso(AccesosModel accesosModel, int idAcceso, bool visible) async {
    var success = true;
    final access = accesosModel.accesos.firstWhere((e) => e.idAcceso == idAcceso);
    final uacceso = access.copyWith(bitVisible: visible ? 1 : 0);
    accesosModel.update(uacceso);
    _userService.actualizaAccesos(accesosModel);
    //free();
    return success;
  }

  Future<Null> consultaContenidoAcceso(UserModel userModel, AccesoModel accesoModel) async {
    busy();
    try {
      if (accesoModel.bitConsumeApi == 1) {
        contenidoModel = await _userService.getContenidoAcceso(userModel, accesoModel);
        if (contenidoModel == null)
          error("No se encontró información relacionada");
        else
          free();
      } else {
        free();
      }
    } catch (e) {
      errorException(e);
    }
  }

  Future<Null> configuracionLocal() async {
    busy();
    try {
      configuracion = await _localdbService.getConfiguration();
      var packageInfo = await _applicationService.getAppVersion();
      appVersion = "${packageInfo.version} ${packageInfo.buildNumber}";
      free();
    } catch (e) {
      error(e.toString());
    }
  }

  Future<bool> actualizaConfiguracion(UserModel userModel, ConfigurationModel configurationModel, int value) async {
    bool success = false;

    try {
      final config = configurationModel.copyWih(bitActivo: value);
      success = await _userService.getActualizaConfiguracion(userModel, config);
      if (success) {
        configuracion.add(config);
      }
      free();
    } catch (e) {
      errorException(e);
    }
    return success;
  }

  Future<bool> sincronizarInformacion(UserModel userModel) async {
    var success = true;
    try {
      final faqs = await _nominaService.getPreguntasFrecuentes(userModel);
      final directorio = await _nominaService.getDirectorioRH(userModel);
      await _userService.getAccesos(userModel);

      await _localdbService.savePreguntasFrecuentes(faqs);
      await _localdbService.saveDirectoryRH(directorio);

      free();
    } catch (e) {
      success = false;
      errorException(e);
    }

    return success;
  }

  Future<Null> limpiarCache() {
    return Future.microtask(() {
      CustomCacheManager().emptyCache();
      _localdbService.clearYammers();
      return null;
    });
  }

  void consultarNotificaciones(UserModel user, NotificacionModel notificacionModel) async {
    try {
      if (notificacionModel != null) {
        _firebaseMessagingService.addMessage(null);
      } else {
        final notificacionesr = await _userService.getNotificaciones(user);
        _cnotificaciones = notificacionesr.map((e) => new SelectableItem(item: e, isSelected: e.readed == 0)).toList();
        notificaciones = _cnotificaciones;

        free();
      }
    } catch (e) {
      errorException(e);
    }
  }

  void setTipoNotificacion(String value) {
    tipoNotificacion = value;
    notificaciones = _cnotificaciones.where((e) => e.item.subType == value || value == "--").toList();
    free();
  }

  void onSelectNotificacion(NotificacionModel model) {
    _cnotificaciones.firstWhere((element) => element.item.id == model.id).isSelected = false;
    init = false;
    free();

    if (_cnotificaciones.every((e) => !e.isSelected)) _firebaseMessagingService.addMessage(null);
  }
}
