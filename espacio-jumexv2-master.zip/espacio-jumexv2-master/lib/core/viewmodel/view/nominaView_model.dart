import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/models/directorio_model.dart';
import 'package:espacio_jumex/core/models/faq_model.dart';
import 'package:espacio_jumex/core/models/recibo_model.dart';
import 'package:espacio_jumex/core/models/request/incidenciasCAPReq_model.dart';
import 'package:espacio_jumex/core/models/solicitudcredencial_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:espacio_jumex/core/services/nomina_service.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

/// NominaViewModel
/// Clase BaseModel que contoene la logica de negocio que corresponde a la nómina
class NominaViewModel extends BaseModel {
  NominaService _nominaService;
  LocaldbService _localdbService;

  NominaViewModel({@required NominaService nominaService, LocaldbService localdbService})
      : assert(nominaService != null),
        _nominaService = nominaService,
        _localdbService = localdbService;

  List<FAQModel> faqs;
  List<DirectorioModel> directorio;
  List<SolicitudCredencialModel> solicitudCredenciales;
  ReciboModel recibo;

  final dateFormatter = DateFormat(Constants.dateFormat);

  Future<bool> enviarSugerencias(UserModel userModel, String sugerencia, String email) async {
    busy();
    var success = false;
    try {
      final response = await _nominaService.postSugerencia(userModel, sugerencia, email);
      success = response.status != "error";

      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<Null> consultaPreguntasFrecuentes(UserModel userModel) async {
    busy();
    try {
      faqs = await _localdbService.getPreguntasFrecuentes();

      if (faqs == null || faqs.length == 0) {
        faqs = await _nominaService.getPreguntasFrecuentes(userModel);
        await _localdbService.savePreguntasFrecuentes(faqs);
      }

      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<Null> consultaDirectorioRH(UserModel userModel) async {
    busy();
    try {
      directorio = await _localdbService.getDirectoryRH();

      if (directorio == null || directorio.length == 0) {
        directorio = await _nominaService.getDirectorioRH(userModel);
        await _localdbService.savePreguntasFrecuentes(faqs);
      }

      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<bool> consultaRecibo(UserModel userModel, String tipoRecibo, DateTime pDate) async {
    var success = false;
    try {
      final date = pDate != null ? dateFormatter.format(pDate) : "";
      recibo = await _nominaService.postRecibo(userModel, tipoRecibo, date);
      success = true;
      free();
    } catch (e) {
      recibo = null;
      errorException(e);
    }

    return success;
  }

  Future<Null> consultaSolicitudesCredencial(UserModel userModel) async {
    busy();
    try {
      solicitudCredenciales = await _nominaService.getSolicitudCredencial(userModel);
      free();
    } catch (e) {
      errorException(e);
    }
  }

  Future<bool> enviarSolicitudCredencial(UserModel userModel, String motivo, String datosCorregir) async {
    busy();
    var success = false;
    try {
      final response = await _nominaService.postSolicitudCredencial(userModel, motivo, datosCorregir);

      success = response.status != "error";
      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }

    return success;
  }

  Future<bool> actualizarCorreoNomina(UserModel userModel, String correo) async {
    busy();
    var success = false;
    try {
      final response = await _nominaService.postActualizarCorreoNomina(userModel, correo);

      success = response.status != "error";
      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }
    return success;
  }

  Future<bool> enviarIncidenciaCAP(UserModel userModel, String incidencia, String fechaInicio, String fechaFin, String observaciones, email) async {
    busy();
    var success = false;
    try {
      final response = await _nominaService.postIncidenciaCAP(
          userModel, IncidenciasCAPReqModel(incidencia: incidencia, fechaInicio: fechaInicio, fechaFin: fechaFin, observaciones: observaciones, email: email));
      success = response.status != "error";
      free(response.mensaje);
    } catch (e) {
      errorException(e);
    }
    return success;
  }
}
