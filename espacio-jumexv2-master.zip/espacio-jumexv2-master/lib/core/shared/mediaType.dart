class MediaType{
  final String _valor;
  String get valor =>_valor;

  const MediaType._internal(this._valor);
  static MediaType from(String valor)=>MediaType._internal((valor?? "").toUpperCase());

  @override
  int get hashCode =>valor.hashCode;

  @override
  bool operator ==(other) => valor == other._valor;

  toString() => '$_valor';

  static const MediaType image = const MediaType._internal("IMAGE");
  static const MediaType video = const MediaType._internal("VIDEO");
  static const MediaType video2Factor = const MediaType._internal("VIDEO2");
  static const MediaType document =  const MediaType._internal("DOCUMENT");
  static const MediaType file =  const MediaType._internal("FILE");
  static const MediaType pdf =  const MediaType._internal("PDF");
  static const MediaType http =  const MediaType._internal("HTTP");
}