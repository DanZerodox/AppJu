class RoutePath {
  static const String Landing = '/';
  static const String Login = 'Login';
  static const String PreHome = 'PreHome';
  static const String Home = 'Home';

  static const String Contrasena = 'Contrasena';

  static const String Sugerencias = 'Sugerencias';

  static const String Preguntas = "Preguntas";
  static const String FAQ = "PreguntaFrecuente";

  static const String BuzonCap = "BuzonCAP";

  static const String Preevaluacion = "Preevaluate";

  static const String Recibo = "Recibo";
  // static const String ReciboDetalle = "ReciboDetalle";

  static const String Tramites = "Tramites";
  static const String Credencial = "Credencial";
  static const String CredencialAdd = "CredencialAdd";
  static const String CorreoNomina = "CorreoNomina";

  static const String Cumpleanios = "Cumpleanios";
  static const String CumpleaniosMensaje = "CumpleaniosMensaje";
  static const String TarjetaCumpleanios = "TarjetaCumpleanios";

  static const String Vacaciones = "Vacaciones";
  static const String VacacionesAdd = "VacacionesAdd";

  static const String Bienvenida = "Bienvenida";
  static const Normatividad = "Normatividad";
  static const AvisoOportuno = "AvisoOportuno";
  static const AvisoOportunoAdd = "AvisoOportunoAdd";
  static const Beneficios = "Beneficios";
  static const Noticias = "Noticias";
  static const Vacantes = "Vacantes";
  static const Revista = "Revista";

  static const YammerDetail = "YammerDetail";
  static const VisualizarPdf = "VisualizarRecurso";

  static const Perfil = "Perfil";
  static const String RestablecerContrasena = 'RestablecerContrasena';

  static const ContenidoExterno = "ContenidoExterno";
  static const AccesoExterno = "AccesoExterno";

  static const AvisoLegal = "AprobarDocumento";

  static const String IncidenciasAdd = "IncidenciasAdd";
}

class YammerConstant {
  static const yammerNoticiasId = "comunicacion_interna";
  static const yammerAvisoOportunoId = "aviso_oportuno";
  static const yammerVacantesId = "vacantes";
  static const yammerNormatividadId = "normatividad";
  static const yammerBeneficiosId = "beneficios";
  static const yammerBienvenidaId = "bienvenida";
}

class ApiConstant {
  static const apiServer = "https://manzana.jumex.com.mx:4438";
  // static const apiServer = "http://192.168.224.168:44388/qa_kiosko_api";
  // static const apiServer = "https://192.168.200.78:4433/qa_kiosko_api";

  static const apiEndpoint = "$apiServer/api";
  static const firebaseTopics = <String>["notificaciones"];
}

class BreakpointLayout {
  //Breackpoints layouts
  static const breakPointWidth500 = 500.0;
  static const breakPointHeight360 = 360.0;
  static const breakPointHeight600 = 600.0;
}

class Constants {
  static const regexpDate = r"^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$";
  static const regexpEmail =
      r"^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$";
  static const dateFormat = "dd/MM/yyyy";

  static const cached = 30;
}
