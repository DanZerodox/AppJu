import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/services/application_service.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart';

class CustomCacheManager extends BaseCacheManager  {

  static const key = "espacioJumexCache";
  final ApplicationService _permissionsService;

  static CustomCacheManager _instance;

  factory CustomCacheManager({ ApplicationService applicationService}) {
    if (_instance == null) {
      _instance = new CustomCacheManager._(applicationService);
    }
    return _instance;
  }

  CustomCacheManager._(ApplicationService permissionsService) : _permissionsService = permissionsService,
   super(key,
      maxAgeCacheObject: Duration(days: Constants.cached),
      maxNrOfCacheObjects: 800
    );

  @override
  Future<String> getFilePath() async {
    var path = await _permissionsService.prepareAccessFile();
    return (path ?? await getTemporaryDirectory())?.path;
  }
}