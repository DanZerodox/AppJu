class DeviceModel{
  final String versionRelease;
  final String baseOS;
  final String codename;

  final String device;
  final String host;
  final String model;

  final String manufacturer;
  final String product;
  final String name;

  const DeviceModel({
    this.baseOS,
    this.codename,
    this.device,
    this.host,
    this.manufacturer,
    this.model,
    this.name,
    this.product,
    this.versionRelease
  });
}