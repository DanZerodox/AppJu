
import 'package:espacio_jumex/core/shared/mediaType.dart';
import 'package:flutter/foundation.dart';

class PhotoItemModel<T>{
  final String url;
  final String thumbnail;
  final String id;
  final MediaType type;
  final T info;

  const PhotoItemModel({
    @required this.id,
    @required this.url,
    this.thumbnail,
    @required this.type,
    this.info
  });
}