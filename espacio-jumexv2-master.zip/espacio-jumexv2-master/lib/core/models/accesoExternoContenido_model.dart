import 'dart:core';

import 'package:espacio_jumex/core/shared/mediaType.dart';

class AccesoExternoContenidoModel {
  final AccesoExternoType tipo;
  final MediaType subTipo;
  final String objetivo;
  final String texto;

  const AccesoExternoContenidoModel({
    this.tipo,
    this.objetivo,
    this.texto,
    this.subTipo
  });

  factory AccesoExternoContenidoModel.fromJson(dynamic data) {
    return new AccesoExternoContenidoModel(
      tipo: AccesoExternoType.from(data["Tipo"]),
      objetivo: data["Valor"],
      texto: data["Titulo"],
      subTipo: data["SubTipo"] != null ? MediaType.from(data["SubTipo"]) : null,
    );
  }

  dynamic map()=>{
    "Tipo": this.tipo.valor,
    "Objetivo": this.objetivo,
    "Rotulo":this.texto,
    "SubTipo":this.subTipo,
  };


}

class AccesoExternoType{
  final String _valor;
  String get valor =>_valor;

  const AccesoExternoType._internal(this._valor);
  static AccesoExternoType from(String valor)=>AccesoExternoType._internal(valor);

  @override
  int get hashCode =>valor.hashCode;

  bool operator ==(other) => valor == other._valor;

  toString() => 'AccesoExternoType($_valor)';

  static const AccesoExternoType launchable =   const AccesoExternoType._internal("LAUNCHABLE");
  static const AccesoExternoType copiable =     const AccesoExternoType._internal("COPIABLE");
  static const AccesoExternoType presentable =  const AccesoExternoType._internal("GALLERY");
  static const AccesoExternoType readable =     const AccesoExternoType._internal("READABLE");
}