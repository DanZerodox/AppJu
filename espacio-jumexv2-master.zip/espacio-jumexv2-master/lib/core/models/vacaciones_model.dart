class InformacionVacacionesModel
{
    final String numeroJefe;
    final String nombreJefe;
    final int derechoVacacional;
    final int liquidacionVacacional;
    final int saldoVacacional;
    final String fechaAlta;
    final String sociedad;
    final String divisionPersonal;
    final VacacionesPeriodoModel periodo;
    final VacacionesPeriodoModel periodoProximo;

  InformacionVacacionesModel(
    {
      this.numeroJefe,
      this.nombreJefe,
      this.derechoVacacional, 
      this.liquidacionVacacional, 
      this.saldoVacacional, 
      this.fechaAlta, 
      this.sociedad, 
      this.divisionPersonal, 
      this.periodo, 
      this.periodoProximo
    });

    factory InformacionVacacionesModel.fromJson(dynamic data){
    return new InformacionVacacionesModel(
      derechoVacacional: data["DerechoVacacional"],
      liquidacionVacacional: data["LiquidacionVacacional"],
      nombreJefe: data["NombreJefe"],
      numeroJefe: data["NumeroJefe"],
      fechaAlta: data["FechaAlta"],
      saldoVacacional: data["SaldoVacacional"],
      periodo: VacacionesPeriodoModel.fromJson(data["Periodo"]),
      periodoProximo: VacacionesPeriodoModel.fromJson(data["PeriodoProximo"]),
      sociedad: data["Sociedad"],
      divisionPersonal: data["DivisionPersonal"],
    );
  }
}

class VacacionesPeriodoModel {
  final String periodoInicio;
  final String periodoFin;
  final String vencimiento;

  VacacionesPeriodoModel({
    this.periodoInicio, 
    this.periodoFin, 
    this.vencimiento
  });

  factory VacacionesPeriodoModel.fromJson(dynamic data){
    return VacacionesPeriodoModel(
      periodoInicio: data["PeriodoInicio"],
      periodoFin: data["PeriodoFin"],
      vencimiento: data["Vencimiento"],
    );
  }
}

class SolicitudesVacacionesWrapModel{
  final List<SolicitudVacacionesModel> tomadas;
  final List<SolicitudVacacionesModel> solicitudes;

  SolicitudesVacacionesWrapModel({this.tomadas,this.solicitudes});

  static SolicitudesVacacionesWrapModel fromJson(dynamic data){
    return new SolicitudesVacacionesWrapModel(
      tomadas: data["Tomadas"].map((x)=>SolicitudVacacionesModel.fromJson(x)).toList().cast<SolicitudVacacionesModel>(),
      solicitudes: data["MisSolicitudes"].map((x)=>SolicitudVacacionesModel.fromJson(x)).toList().cast<SolicitudVacacionesModel>(),
    );
  }
}

class SolicitudVacacionesModel
{
  final int id;
  final String estatus;
  final String fechaInicio;
  final String fechaFin;
  final String fechaSolicitud;
  final int dias;
  final String comentarios;
  final int numeroColaborador;
  final String nombreColaborador;
  final String observaciones;
  final String estatusSap;

  SolicitudVacacionesModel({
    this.id, 
    this.estatus, 
    this.fechaInicio, 
    this.fechaFin, 
    this.fechaSolicitud, 
    this.dias, 
    this.comentarios, 
    this.numeroColaborador, 
    this.nombreColaborador, 
    this.observaciones, 
    this.estatusSap
  });

  factory SolicitudVacacionesModel.fromJson(dynamic data){
    return new SolicitudVacacionesModel(
      dias: data["Dias"],
      estatus: data["Estatus"],
      fechaFin: data["FechaFin"],
      fechaInicio: data["FechaInicio"],
      fechaSolicitud: data["FechaSolicitud"],
      id: data["Id"],
      nombreColaborador: data["NombreColaborador"],
      numeroColaborador: data["NumeroColaborador"],
      comentarios: data["Comentarios"],
      observaciones: data["Observaciones"],
      estatusSap: data["EstatusSap"],
    );
  }

  SolicitudVacacionesModel copyWith(
    {
      int id,
      String estatus,
      String fechaInicio,
      String fechaFin,
      String fechaSolicitud,
      int dias,
      String comentarios,
      int numeroColaborador,
      String nombreColaborador,
      String observaciones,
      String estatusSap,
    }
  ){
    return SolicitudVacacionesModel(
      id : this.id ?? id,
      estatus : this.estatus ?? estatus,
      fechaInicio : this.fechaInicio ?? fechaInicio,
      fechaFin : this.fechaFin ?? fechaFin,
      fechaSolicitud : this.fechaSolicitud ?? fechaSolicitud,
      dias : this.dias ?? dias,
      comentarios : this.comentarios ?? comentarios ,
      numeroColaborador: this.numeroColaborador ?? numeroColaborador,
      nombreColaborador: this.nombreColaborador ?? nombreColaborador,
      observaciones : this.observaciones ?? observaciones,
      estatusSap: this.estatusSap ?? estatusSap,
    );
  }
}
