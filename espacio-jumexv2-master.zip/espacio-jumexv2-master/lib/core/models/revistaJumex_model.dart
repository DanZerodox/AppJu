import 'package:espacio_jumex/core/shared/mediaType.dart';

class RevistaJumexModel {
  final String id;
  final String nombre;
  final MediaType type;
  final List<RevistaJumexModel> resourceModels;

  RevistaJumexModel({this.id, this.nombre, this.type, this.resourceModels});

  factory RevistaJumexModel.fromJson(dynamic data) {
    return RevistaJumexModel(
        id: data["Id"],
        nombre: data["Nombre"],
        type: MediaType.from(data["Type"]),
        resourceModels: data["Content"]?.map<RevistaJumexModel>((x) => RevistaJumexModel.fromJson(x))?.toList());
  }
}
