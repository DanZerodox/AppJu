class AppVersionModel{
  final String version;
  final String buildNumber;

  AppVersionModel({this.buildNumber, this.version});

}