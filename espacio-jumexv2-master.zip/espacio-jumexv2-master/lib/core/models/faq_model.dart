class FAQModel {
  final int id;
  final int parentId;
  final String pregunta;
  final List<FAQModel> respuesta;

  FAQModel({
    this.id,
    this.parentId,
    this.pregunta,
    this.respuesta,
  });

  dynamic toMap(){
    return {
        'id': this.id,
        'pregunta':this.pregunta,
        'parent_id': this.parentId
    };
  }

  static FAQModel fromEntity(dynamic data){
    return new FAQModel(
      id: data["id"],
      parentId: data["parent_id"],
      pregunta: data["pregunta"],
      respuesta: data["respuesta"],
    );
  }

  factory FAQModel.fromJson(dynamic data){
    return new FAQModel(
      id: data["Id"],
      parentId: data["ParentId"],
      pregunta: data["Pregunta"],
      respuesta: data["Respuesta"]?.map((x)=>FAQModel.fromJson(x).copyWith(parent:data["Id"]) )?.toList()?.cast<FAQModel>(),
    );
  }

  FAQModel copyWith({
    int id,
    int parent,
    String pregunta,
    List<FAQModel> respuesta,
  }){
    return new FAQModel(
      id: id ?? this.id,
      parentId: parent ?? this.parentId,
      pregunta: pregunta ?? this.pregunta,
      respuesta: respuesta ?? this.respuesta,
    );
  } 
}