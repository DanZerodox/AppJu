class ReciboModel
{
  final ReciboPatronModel patron;
  final String curp;
  final String areaDePersonal;
  final String rfc;
  final String nss;
  final String centroCostos;
  final String fechaPago;
  final String periodoPago;
  final String periodoPago2;
  final String periodoPago3;
  final String salarioDiario;
  final String netoAPagar;
  final String netoAPagarLetra;
  final ReciboPercepcionModel percepciones;
  final ReciboPercepcionModel deducciones;
  final List<ReciboDetalleModel> saldos;

  final String html;

  ReciboModel({
    this.patron, 
    this.curp, 
    this.areaDePersonal, 
    this.rfc, 
    this.nss, 
    this.centroCostos, 
    this.fechaPago, 
    this.periodoPago, 
    this.periodoPago2, 
    this.periodoPago3, 
    this.salarioDiario, 
    this.netoAPagar, 
    this.netoAPagarLetra, 
    this.percepciones, 
    this.deducciones, 
    this.saldos,
    this.html,
  });

  factory ReciboModel.fromJson(dynamic data){
    return ReciboModel(
      patron : ReciboPatronModel.fromJson(data["Patron"]), 
      curp: data["CURP"], 
      areaDePersonal: data["AreaDePersonal"], 
      rfc: data["RFC"], 
      nss: data["NSS"], 
      centroCostos: data["CentroCostos"], 
      fechaPago: data["FechaPago"], 
      periodoPago: data["PeriodoPago"], 
      periodoPago2: data["PeriodoPago2"], 
      periodoPago3: data["PeriodoPago3"], 
      salarioDiario: data["SalarioDiario"], 
      netoAPagar: data["NetoAPagar"], 
      netoAPagarLetra: data["NetoAPagarLetra"], 
      percepciones: ReciboPercepcionModel.fromJson(data["Percepciones"]), 
      deducciones: ReciboPercepcionModel.fromJson(data["Deducciones"]), 
      saldos: data["Saldos"]?.map((x)=>ReciboDetalleModel.fromJson(x))?.toList()?.cast<ReciboDetalleModel>(), 
      html:data["Html"]
    );

  }
}
class ReciboPatronModel {
  final String nombre;
  final String registroPatronal;
  final String rfc;

  ReciboPatronModel({
    this.nombre, 
    this.registroPatronal, 
    this.rfc
  });

  factory ReciboPatronModel.fromJson(dynamic data){
    return ReciboPatronModel(
      nombre: data["Nombre"],
      registroPatronal: data["RegistroPatronal"],
      rfc: data["RFC"],
    );
  }
}

class ReciboPercepcionModel
{
  final List<ReciboDetalleModel> detalle;
  final String totalPercepciones;

  ReciboPercepcionModel({
    this.detalle, 
    this.totalPercepciones
  });

  factory ReciboPercepcionModel.fromJson(dynamic data){
    return ReciboPercepcionModel(
      totalPercepciones: data["TotalPercepciones"],
      detalle: data["Detalle"]?.map((x)=>ReciboDetalleModel.fromJson(x))?.toList()?.cast<ReciboDetalleModel>()
    );
  }
}

class ReciboDetalleModel {
  final String concepto;
  final String laborado;
  final String importe;

  ReciboDetalleModel({
    this.concepto, 
    this.laborado, 
    this.importe
  });

  factory ReciboDetalleModel.fromJson(dynamic data){
    return new ReciboDetalleModel(
      concepto: data["Concepto"],
      importe: data["Importe"],
      laborado: data["Laborado"]
    );
  }
}