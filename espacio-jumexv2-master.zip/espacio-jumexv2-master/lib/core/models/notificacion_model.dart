class NotificationType {
  final String _valor;
  String get valor => _valor;

  const NotificationType._internal(this._valor);
  static NotificationType from(String valor) =>
      NotificationType._internal(valor.toUpperCase());

  @override
  int get hashCode => valor.hashCode;

  @override
  bool operator ==(other) => valor == other._valor.toUpperCase();

  toString() => 'FirebaseType($_valor)';

  static const NotificationType ruta =
      const NotificationType._internal("ROUTE");
  static const NotificationType simple =
      const NotificationType._internal("SIMPLE");
  static const NotificationType externo =
      const NotificationType._internal("EXTERNAL");
}

class NotificacionesModel {
  final int totalUnread;

  NotificacionesModel({this.totalUnread});

  factory NotificacionesModel.fromJson(dynamic data) {
    return NotificacionesModel(totalUnread: data["Unread"]);
  }
}

class NotificacionModel {
  final String title;
  final String body;
  final NotificationType type;
  final String subType;
  final String value;
  final String key;
  final String date;
  final int readed;
  final int id;

  NotificacionModel(
    {
      this.title,
      this.body,
      this.type,
      this.value,
      this.subType,
      this.key,
      this.date,
      this.readed,
      this.id = -1
    });

  toString() =>
      'FirebaseMessageModel(title:$title, body:$body, type:$type, subTipo:$subType, valor:$value)';

  factory NotificacionModel.fromMessage(Map<String, dynamic> message) {
    final notification = message["notification"];
    final data = message["data"] ?? message;
    final tipo =
        data["type"] != null ? NotificationType.from(data["type"]) : null;

    return new NotificacionModel(
      title: data["title"] ?? notification["title"],
      body: data["body"] ?? notification["body"],
      type: tipo,
      subType: data["subType"],
      value: data["value"]
    );
  }

  factory NotificacionModel.fromJson(dynamic data) {
    return new NotificacionModel(
      title: data["Title"],
      body: data["Body"],
      type: NotificationType.from(data["Type"]),
      subType: data["SubType"],
      value: data["Value"],
      date: data["Date"],
      readed: data["Readed"],
      id: data["Id"]
    );
  }
}
