class PreevaluateModel{
  final String periodoInicio;
  final String periodoFin;
  final List<MarcajeModel> marcajes;
  final String html;

  PreevaluateModel({
    this.periodoInicio,
    this.periodoFin,
    this.marcajes,
    this.html
  });

  factory PreevaluateModel.fromJson(dynamic data){
    return new PreevaluateModel(
      periodoInicio: data["PeriodoInicio"],
      periodoFin: data["PeriodoFin"],
      marcajes: data["Marcajes"].map<MarcajeModel>((x)=>MarcajeModel.fromJson(x)).toList(),
      html: data["Html"]
    );
  }

  PreevaluateModel copyWith({
    String periodoInicio,
    String periodoFin,
    List<MarcajeModel> marcajes,
    String html,
  }){
    return new PreevaluateModel(
      periodoInicio: periodoInicio ?? this.periodoInicio,
      periodoFin: periodoFin ?? this.periodoFin,
      marcajes: marcajes ?? this.marcajes,
      html: html ?? this.html
    );
  }
}
class MarcajeModel{
  final String fecha;
  final String dia;
  final String turno;
  final String salida;
  final String entrada;
  final String marcaje_1;
  final String marcaje_2;
  final String observacion;
  final String incidencia;

  MarcajeModel({
    this.fecha, 
    this.dia, 
    this.turno, 
    this.salida, 
    this.entrada, 
    this.marcaje_1, 
    this.marcaje_2, 
    this.observacion, 
    this.incidencia
  });

  factory MarcajeModel.fromJson(dynamic data){
    return MarcajeModel(
      dia: data["Dia"],
      entrada: data["Entrada"],
      fecha: data["Fecha"],
      incidencia: data["Incidencia"],
      marcaje_1: data["Marcaje_1"],
      marcaje_2: data["Marcaje_2"],
      observacion: data["Observacion"],
      salida: data["Salida"],
      turno: data["Turno"]
    );
  }

  @override
  int get hashCode =>
      fecha.hashCode;


  bool operator ==(Object other) =>
      identical(this, other) ||
          other is MarcajeModel &&
              runtimeType == other.runtimeType &&
              fecha == other.fecha;
}