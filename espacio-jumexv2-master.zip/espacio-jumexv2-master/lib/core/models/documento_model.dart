class DocumentoModel{
  final String type;
  final String id;
  final String url;
  final String name;

  DocumentoModel({
    this.id,
    this.url,
    this.name,
    this.type
  });

  factory DocumentoModel.fromJson(dynamic data){
    return DocumentoModel(
      id: data["Id"],
      url: data["Url"],
      name: data["Name"],
      type: data["Type"]
    );
  }
}