class GeneralModel {
  final String status;
  final String mensaje;

  GeneralModel({this.status,this.mensaje});

  factory GeneralModel.fromJson(dynamic data){
    return GeneralModel(
      mensaje: data["msg"] ?? data["message"] ?? data["mensaje"] ?? data["Message"]?? data["Mensaje"],
      status: data["Status"]
    );
  }
}