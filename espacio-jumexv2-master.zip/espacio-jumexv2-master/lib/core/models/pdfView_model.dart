class PdfViewModel{
  String title;
  String url;

  PdfViewModel({this.title, this.url});

  factory PdfViewModel.fromJson(dynamic data){
    return PdfViewModel(
      title: data["Title"],
      url: data["Url"]
    );
  }
}