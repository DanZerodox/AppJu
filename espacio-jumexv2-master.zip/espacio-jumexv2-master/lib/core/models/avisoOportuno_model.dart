import 'package:espacio_jumex/core/models/yammer_model.dart';

class AvisoOportunoModel extends YammerModel{
  final String estatus;
  final String estatusDesc;
  final String messageId;
  final String correo;
  final String telefono;
  final int usuario;

  AvisoOportunoModel({this.correo,this.estatus,this.estatusDesc,this.messageId, this.telefono, this.usuario
    ,String title, String createdAt, String content, String contentParsed, String contentRich, List<YammerMediaModel> media, int likes
  })
  :super(title: title, createdAt: createdAt, content: content, contentParsed: contentParsed, contentRich: contentRich, media: media, likes: likes);

  factory AvisoOportunoModel.fromJson(dynamic data){
    return new AvisoOportunoModel(
      content: data["Content"],
      contentParsed: data["ContentParsed"],
      contentRich: data["ContentRich"],
      createdAt: data["CreatedAt"],
      likes: data["Nikes"],
      media:  data["Media"]?.map((x)=>YammerMediaModel.fromJson(x))?.toList()?.cast<YammerMediaModel>(),
      title: data["Title"],
      correo: data["Correo"],
      telefono: data["Telefono"],
      estatus: data["Estatus"],
      messageId: data["MessageId"],
      usuario: data["Usuario"]
    );
  }
}