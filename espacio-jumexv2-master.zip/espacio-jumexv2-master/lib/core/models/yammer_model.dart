import 'package:espacio_jumex/core/shared/mediaType.dart';

class YammerModel {
  final String id;
  final String title;
  final String createdAt;
  final String abstractMessage;
  final String content;
  final String contentParsed;
  final String contentRich;
  final String contentMovil;
  final List<YammerMediaModel> media;
  final int likes;
  final String yammerId;

  YammerModel(
      {this.id, this.title, this.createdAt, this.content, this.contentParsed, this.contentRich, this.contentMovil, this.media, this.likes, this.abstractMessage, this.yammerId});

  static YammerModel fromJson(dynamic data) {
    return new YammerModel(
        content: data["Content"],
        contentParsed: data["ContentParsed"],
        contentRich: data["ContentRich"],
        contentMovil: data["ContentMobile"],
        createdAt: data["CreatedAt"],
        id: data["Id"]?.toString(),
        likes: data["Nikes"],
        media: data["Media"]?.map((x) => YammerMediaModel.fromJson(x))?.toList()?.cast<YammerMediaModel>(),
        title: data["Title"],
        abstractMessage: data["Introduction"]);
  }

  YammerModel copyWith({
    String id,
    String title,
    String createdAt,
    String abstractMessage,
    String content,
    String contentParsed,
    String contentRich,
    String contentMovil,
    List<YammerMediaModel> media,
    int likes,
    String yammerId,
  }) {
    return new YammerModel(
        id: id ?? this.id,
        title: title ?? this.title,
        createdAt: createdAt ?? this.createdAt,
        abstractMessage: abstractMessage ?? this.abstractMessage,
        content: content ?? this.content,
        contentParsed: contentParsed ?? this.contentParsed,
        contentRich: contentRich ?? this.contentRich,
        contentMovil: contentMovil ?? this.contentMovil,
        media: media ?? this.media,
        likes: likes ?? this.likes,
        yammerId: yammerId ?? this.yammerId);
  }

  dynamic toMap() {
    return {"ContentParsed": this.contentParsed, "CreatedAt": this.createdAt, "Id": this.id, "Nikes": this.likes, "Title": this.title, "YammerId": this.yammerId};
  }
}

class YammerMediaModel {
  final String name;
  final MediaType type;
  final int id;

  final String thumbnail;
  final String urlContent;

  final int messageId;
  final int versionId;

  final String yammerId;

  YammerMediaModel({this.id, this.name, this.type, this.thumbnail, this.urlContent, this.messageId, this.versionId, this.yammerId});

  static YammerMediaModel fromJson(dynamic data) {
    final type = MediaType.from(data["Type"]);
    final name = data["Name"];
    final version = data["VersionId"];
    final id = data["Id"];

    return new YammerMediaModel(
        name: name,
        id: id,
        type: type,
        thumbnail: data["Thumbnail"],
        urlContent: type == MediaType.video ? data["Content2"] ?? data["Content"] : data["Content"],
        versionId: version,
        messageId: data["MessageId"],
        yammerId: data["YammerId"]);
  }

  YammerMediaModel copyWith({String name, MediaType type, int id, String url, String urlContent, int messageId, int versionId, String stream, String yammerId}) {
    return YammerMediaModel(
        name: name ?? this.name,
        id: id ?? this.id,
        messageId: messageId ?? this.messageId,
        type: type ?? this.type,
        thumbnail: url ?? this.thumbnail,
        urlContent: urlContent ?? this.urlContent,
        versionId: versionId ?? this.versionId,
        yammerId: yammerId ?? this.yammerId);
  }

  dynamic toMap() {
    return {
      "MessageId": this.messageId,
      "Id": this.id,
      "Type": this.type.valor,
      "Name": this.name,
      "VersionId": this.versionId,
      "Thumbnail": this.thumbnail,
      "Content": this.urlContent,
      "YammerId": this.yammerId
    };
  }
}

class YammerMessagesModel {
  final int usuario;
  final String titulo;
  final String repliedToId;
  final String messageId;
  final String pubType;
  final String estatus;
  final String fecha;
  final String estatusDesc;

  const YammerMessagesModel({this.estatus, this.fecha, this.messageId, this.pubType, this.repliedToId, this.titulo, this.usuario, this.estatusDesc});

  factory YammerMessagesModel.fromJson(dynamic data) {
    return YammerMessagesModel(
        estatus: data["Estatus"],
        estatusDesc: data["EstatusDesc"],
        fecha: data["Fecha"],
        messageId: data["MessageId"],
        pubType: data["PubType"],
        repliedToId: data["RepliedToId"],
        titulo: data["Titulo"],
        usuario: data["Usuario"]);
  }

  @override
  int get hashCode => messageId.hashCode;

  bool operator ==(Object other) => identical(this, other) || other is YammerMessagesModel && runtimeType == other.runtimeType && messageId == other.messageId;
}
