// import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/shared/mediaType.dart';

class AccesosModel {
  final List<AccesoModel> accesos;

  AccesosModel({this.accesos});

  factory AccesosModel.fromJson(dynamic data) {
    var list = data.map<AccesoModel>((x) => AccesoModel.fromJson(x)).where((x) => x.bitAcceso == 1).toList();

    return AccesosModel(accesos: list);
  }

  void update(AccesoModel accesoModel) {
    final index = accesos.indexOf(accesoModel);
    accesos[index] = accesoModel;
  }
}

class AccesoModel {
  final String nombreAcceso;
  final String rutaAcceso;
  final int bitAcceso;

  final int idAcceso;
  final int idAccesoPadre;
  final int bitConsumeApi;
  final String urlLaunch;

  final String appIcon;
  final int iconCover;

  final AccesoOrdenType orden;

  final int bitVisible;

  final MediaType subTipo;

  AccesoModel(
      {this.nombreAcceso,
      this.bitAcceso,
      this.rutaAcceso,
      this.bitVisible = 1,
      this.idAccesoPadre,
      this.bitConsumeApi,
      this.urlLaunch,
      this.appIcon,
      this.idAcceso,
      this.orden,
      this.iconCover,
      this.subTipo});

  factory AccesoModel.fromJson(dynamic data) {
    return AccesoModel(
        bitAcceso: data["BitAcceso"],
        nombreAcceso: data["NombreAcceso"],
        rutaAcceso: data["RutaAcceso"],
        bitVisible: data["BitVisible"] ?? 1,
        idAccesoPadre: data["IdAccesoPadre"],
        bitConsumeApi: data["BitConsumeApi"] ?? 0,
        urlLaunch: data["UrlLaunch"],
        appIcon: data["AppIcon"],
        idAcceso: data["IdAcceso"],
        orden: AccesoOrdenType.from(data["Orden"]),
        iconCover: data["IconCover"],
        subTipo: MediaType.from(data["SubTipo"]));
  }

  dynamic toMap() {
    return {
      "BitAcceso": this.bitAcceso,
      "NombreAcceso": this.nombreAcceso,
      "RutaAcceso": this.rutaAcceso,
      "BitVisible": this.bitVisible,
      "IdAccesoPadre": this.idAccesoPadre,
      "BitConsumeApi": this.bitConsumeApi,
      "UrlLaunch": this.urlLaunch,
      "AppIcon": this.appIcon,
      "IdAcceso": this.idAcceso,
      "Orden": this.orden.valor,
      "IconCover": this.iconCover,
      "SubTipo": subTipo.valor
    };
  }

  AccesoModel copyWith({
    String nombreAcceso,
    String rutaAcceso,
    int bitAcceso,
    int bitVisible,
    int idAccesoPadre,
    int bitConsumeApi,
    String urlLaunch,
    String appIcon,
    int idAcceso,
    AccesoOrdenType orden,
    int iconCover,
    MediaType subTipo,
  }) {
    return AccesoModel(
        bitAcceso: bitAcceso ?? this.bitAcceso,
        bitVisible: bitVisible ?? this.bitVisible,
        nombreAcceso: nombreAcceso ?? this.nombreAcceso,
        rutaAcceso: rutaAcceso ?? this.rutaAcceso,
        idAccesoPadre: idAccesoPadre ?? this.idAccesoPadre,
        bitConsumeApi: bitConsumeApi ?? this.bitConsumeApi,
        urlLaunch: urlLaunch ?? this.urlLaunch,
        appIcon: appIcon ?? this.appIcon,
        idAcceso: idAcceso ?? this.idAcceso,
        orden: orden ?? this.orden,
        iconCover: iconCover ?? this.iconCover,
        subTipo: subTipo ?? this.subTipo);
  }

  @override
  int get hashCode => rutaAcceso.hashCode + 32;

  bool operator ==(Object other) => other is AccesoModel && other.runtimeType == this.runtimeType && other.idAcceso == this.idAcceso;
}

class AccesoOrdenType {
  final String _valor;

  get valor => _valor;

  const AccesoOrdenType._internal(this._valor);

  static AccesoOrdenType from(String valor) => AccesoOrdenType._internal(valor);

  @override
  int get hashCode => valor.hashCode;

  bool operator ==(Object other) => identical(this, other) || other is AccesoOrdenType && runtimeType == other.runtimeType && valor == other.valor;

  toString() => 'AccesoOrdenType($_valor)';

  static const AccesoOrdenType prior = AccesoOrdenType._internal("PRIOR");
  static const AccesoOrdenType minor = AccesoOrdenType._internal("MINOR");
  static const AccesoOrdenType organizational = AccesoOrdenType._internal("ORGAN");
  static const AccesoOrdenType payroll = AccesoOrdenType._internal("PAYR");
}
