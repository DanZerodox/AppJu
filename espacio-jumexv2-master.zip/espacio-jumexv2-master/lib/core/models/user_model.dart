
class UserModel{
  final int usuario;
  final String correo;
  final String nombre;
  final String tokenAcceso;
  final String fotografia;
  final String denominacionS;
  final String divisionPDes;
  final String fechaAlta;
  final String nombreJefe;

  final int avisoLegal;
  final String ceco;

  UserModel({
    this.usuario,
    this.nombre,
    this.denominacionS,
    this.divisionPDes,
    this.tokenAcceso,
    this.correo,
    this.fotografia,
    this.fechaAlta,
    this.avisoLegal,
    this.nombreJefe,
    this.ceco
  });

  dynamic toMap(){
    return {
        "Usuario": this.usuario,
        "Correo": this.correo,
        "Nombre":this.nombre,
        "Fotografia": this.fotografia,
        "TokenAcceso":this.tokenAcceso,
        "DenominacionS": this.denominacionS,
        "DivisionPDes": this.divisionPDes,
        "FechaAlta": this.nombreJefe,
        "Ceco": this.ceco,
    };
  }

  factory UserModel.fromJson(dynamic data){
    return UserModel(
        nombre: data["Nombre"] ?? "No registrado",
        tokenAcceso: data["TokenAcceso"] ?? data["accessToken"] as String,
        correo: data["Correo"] as String,
        fotografia: data["Fotografia"] as String,
        usuario: data["Usuario"],
        denominacionS: data["DenominacionS"],
        divisionPDes: data["DivisionPDes"],
        avisoLegal: data["AvisoLegal"] ?? 0,
        fechaAlta:  data["FechaAlta"],
        nombreJefe: data["NombreJefe"],
        ceco: data["Ceco"],
    );
  }

  UserModel copyWith({
    String email,
    String userName,
    String accessToken,
    String picture,
    String userNumber,
    String divisionPersonal,
    int isCorporativo,
    int avisoLegal,
    int hasUrbancheck,
    String fechaAlta,
    String nombreJefe,
    String ceco
  }){
    return UserModel(
      correo: email ?? this.correo,
      nombre: userName?? this.nombre,
      tokenAcceso: accessToken?? this.tokenAcceso,
      fotografia: picture?? this.fotografia,
      usuario: userNumber?? this.usuario,
      denominacionS: denominacionS ?? this.denominacionS,
      divisionPDes: divisionPersonal ?? this.divisionPDes,
      avisoLegal: avisoLegal ?? this.avisoLegal,
      fechaAlta: fechaAlta ?? this.fechaAlta,
      nombreJefe: nombreJefe ?? this.nombreJefe,
      ceco: ceco ?? this.ceco
    );
  }

  @override
  int get hashCode =>
      correo.hashCode ^
      nombre.hashCode ^
      tokenAcceso.hashCode ^
      usuario.hashCode;


  bool operator ==(Object other) =>
      identical(this, other) ||
          other is UserModel &&
              runtimeType == other.runtimeType &&
              correo == other.correo &&
              nombre == other.nombre &&
              tokenAcceso == other.tokenAcceso &&
              usuario == other.usuario;

  @override
  String toString() {
    return 'UserModel{user: $usuario, userName: $nombre, email:$correo }';
  }

}