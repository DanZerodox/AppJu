class StatusModel{
  String mensaje;

  StatusModel({this.mensaje});
}