class ColaboradorModel{
  final String nombre;
  final String fecha;
  final String localidad;
  final int numeroEmpleado;
  final int hasMobile;
  final String correo;

  ColaboradorModel({
    this.fecha,
    this.localidad,
    this.nombre,
    this.numeroEmpleado,
    this.hasMobile,
    this.correo,
  });

  factory ColaboradorModel.fromJson(dynamic data){
    return ColaboradorModel(
      fecha: data["Fecha"],
      localidad: data["Localidad"],
      nombre: data["Nombre"],
      numeroEmpleado : data["Numero"],
      hasMobile: data["HasMobile"],
      correo: data["Correo"]
    );
  }

   @override
  int get hashCode => numeroEmpleado;


  bool operator ==(Object other) =>
      identical(this, other) ||
          other is ColaboradorModel &&
              runtimeType == other.runtimeType &&
              numeroEmpleado == other.numeroEmpleado;

}