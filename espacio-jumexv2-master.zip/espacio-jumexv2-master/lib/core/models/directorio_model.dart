class DirectorioModel{
  final String name;
  final List<ContactoModel> contacts;
  DirectorioModel({this.name,this.contacts});

  factory DirectorioModel.fromJson(dynamic data){
    final directorio = data["Nombre"];
    return new DirectorioModel(
      name: directorio,
      contacts: data["Contactos"].map<ContactoModel>((x)=>ContactoModel.fromJson(x).copyWith(directorio: directorio)).toList()
    );
  }
}

class ContactoModel {
  final String area;
  final String nombre;
  final String extension;
  final String email;
  final String directorio;

  ContactoModel({
    this.nombre,
    this.area,
    this.email,
    this.extension,
    this.directorio
  });

  static ContactoModel fromEntity(dynamic data){
    return new ContactoModel(
      directorio: data["directorio"],
      area: data["area"],
      nombre: data["nombre"],
      email: data["email"],
      extension: data["extension"]
    );
  }

  factory ContactoModel.fromJson(dynamic data){
    return new ContactoModel(
      area: data["Area"],
      nombre: data["Nombre"],
      email: data["Email"],
      extension: data["Extension"]
    );
  }

  ContactoModel copyWith({
    String name,
    String area,
    String email,
    String extension,
    String directorio
  }){
    return new ContactoModel(
      area: area ?? this.area,
      directorio: directorio ?? this.directorio,
      email: email ?? this.email,
      extension: extension ?? this.extension,
      nombre: name ?? this.nombre
    );
  } 

  dynamic toMap(){
    return {
      "nombre": this.nombre,
      "area": this.area,
      "email": this.email,
      "extension": this.extension,
      "directorio": this.directorio
    };
  }
}
