class IncidenciaModel{
  final String concepto;
  final String cantidad;
  final String fechaInicio;
  final String fechaFin;
  final String horaInicio;
  final String horaFin;
  final String observaciones;
  final String motivo;
  final String fechaRegistro;
  final String estatus;
  final String estatusDesc;
  final String tipo;
  final int id;

  IncidenciaModel({this.cantidad, 
    this.concepto, 
    this.estatus, 
    this.fechaFin, 
    this.fechaInicio, 
    this.fechaRegistro, 
    this.observaciones, 
    this.id, 
    this.estatusDesc, 
    this.tipo, 
    this.motivo,
    this.horaFin,
    this.horaInicio
  });

  factory IncidenciaModel.fromJson(dynamic data){
    return new IncidenciaModel(
      concepto: data["Concepto"],      
      cantidad: data["Cantidad"],
      fechaInicio: data["FechaInicio"],
      fechaFin: data["FechaFin"],
      observaciones: data["Observaciones"],
      motivo: data["Motivo"],
      fechaRegistro: data["FechaRegistro"],
      estatus: data["Estatus"],
      estatusDesc: data["EstatusDesc"],
      tipo: data["Tipo"],
      id: data["Id"],
      horaFin: data["HoraFin"],
      horaInicio: data["HoraInicio"]
    );
  }
}

class IncidenciaPendienteModel extends IncidenciaModel{
  final int idEmpleado;
  final String nombre;

  IncidenciaPendienteModel({this.idEmpleado, this.nombre,
    String concepto,
    String cantidad,
    String fechaInicio,
    String fechaFin,
    String horaInicio,
    String horaFin,
    String observaciones,
    String fechaRegistro,
    String estatus,
    String estatusDesc,
    String tipo,
    int id,
  }):super(concepto: concepto
    , cantidad: cantidad
    , fechaInicio: fechaInicio
    , fechaFin: fechaFin
    , observaciones: observaciones
    , fechaRegistro: fechaRegistro
    , estatus: estatus
    , estatusDesc: estatusDesc
    , tipo: tipo
    , id: id
    , horaFin: horaFin
    , horaInicio: horaInicio 
  );

  factory IncidenciaPendienteModel.fromJson(dynamic data){
    return new IncidenciaPendienteModel(
      concepto: data["Concepto"],      
      cantidad: data["Cantidad"],
      fechaInicio: data["FechaInicio"],
      fechaFin: data["FechaFin"],
      observaciones: data["Observaciones"],
      fechaRegistro: data["FechaRegistro"],
      estatus: data["Estatus"],
      estatusDesc: data["EstatusDesc"],
      tipo: data["Tipo"],
      id: data["Id"],
      idEmpleado: data["Usuario"],
      nombre: data["Nombre"],
      horaFin: data["HoraFin"],
      horaInicio: data["HoraInicio"]
    );
  }
}

class IncidenciaValueModel{
  final String texto;
  final String valor;
  final int maxDias;
  final int capturarHoras;

  IncidenciaValueModel({this.capturarHoras, this.maxDias, this.texto, this.valor});

  factory IncidenciaValueModel.fromJson(dynamic data){
    return IncidenciaValueModel(
      capturarHoras: data["CapturarHoras"],
      maxDias: data["MaxDias"],
      texto: data["Descripcion"],
      valor: data["Id"]
    );
  }

  @override
  int get hashCode => valor.hashCode;

  @override
    bool operator ==(Object other) =>
      identical(this, other) ||
          other is IncidenciaValueModel &&
              runtimeType == other.runtimeType &&
              valor == other.valor;  
}