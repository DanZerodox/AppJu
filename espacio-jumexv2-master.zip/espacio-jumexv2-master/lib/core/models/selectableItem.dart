class SelectableItem<T>{
  final T item;
  bool isSelected;
  SelectableItem({this.item,this.isSelected= false});
}

class FlagItem<T>{
  final T item;
  int flag;
  FlagItem({this.item,this.flag= 0});
}
