
class UserReqModel{
  String userNumber;
  String password;
  String firebaseToken;
  int rememberme;

  UserReqModel({this.firebaseToken,this.password,this.userNumber,this.rememberme});
}