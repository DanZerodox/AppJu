
class YammerReqModel{
  final String titulo;
  final String repliedToId;

  const YammerReqModel({this.titulo,this.repliedToId});
}