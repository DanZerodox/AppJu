class SolicitudVacacionesReqModel
{
  final String fechaInicio;
  final String fechaFin;
  final String comentarios;

  SolicitudVacacionesReqModel({
    this.fechaInicio, 
    this.fechaFin,
    this.comentarios,
  });

  SolicitudVacacionesReqModel copyWith(
    {
      String fechaInicio,
      String fechaFin,
      String comentarios,
    }
  ){
    return SolicitudVacacionesReqModel(
      fechaInicio : this.fechaInicio ?? fechaInicio,
      fechaFin : this.fechaFin ?? fechaFin,
      comentarios : this.comentarios ?? comentarios,
    );
  }

  dynamic toJson(){
    return {
      "FechaInicio" : this.fechaInicio,
      "FechaFin": this.fechaFin,
      "Comentarios": this.comentarios,
    };
  }
}