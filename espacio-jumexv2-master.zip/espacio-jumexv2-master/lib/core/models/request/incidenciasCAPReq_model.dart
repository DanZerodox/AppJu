class IncidenciasCAPReqModel{
  final String fechaInicio;
  final String fechaFin;
  final String observaciones;
  final String email;
  final String incidencia;

  IncidenciasCAPReqModel({
    this.fechaInicio, 
    this.fechaFin,
    this.observaciones,
    this.email,
    this.incidencia
  });

  IncidenciasCAPReqModel copyWith(
    {
      String fechaInicio,
      String fechaFin,
      String observaciones,
      String email,
      String incidencia
    }
  ){
    return IncidenciasCAPReqModel(
      fechaInicio : this.fechaInicio ?? fechaInicio,
      fechaFin : this.fechaFin ?? fechaFin,
      observaciones : this.observaciones ?? observaciones,
      email: this.email ?? email,
      incidencia: this.incidencia ?? incidencia
    );
  }

  dynamic toJson(){
    return {
      "fechaInicial" : this.fechaInicio,
      "fechaFinal": this.fechaFin,
      "mensaje": this.observaciones,
      "email": this.email,
      "incidencia": this.incidencia,
    };
  }
}