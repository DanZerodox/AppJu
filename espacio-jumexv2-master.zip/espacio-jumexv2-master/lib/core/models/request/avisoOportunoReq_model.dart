
import 'package:espacio_jumex/core/models/request/yammerReq_model.dart';

class AvisoOportunoReqModel extends YammerReqModel{
  String titulo; 
  String codigoPais;
  String telefono;
  String correo;
  String descripcion;

  AvisoOportunoReqModel({this.titulo, this.telefono, this.correo, this.descripcion, this.codigoPais}): super(titulo: titulo);

  AvisoOportunoReqModel copyWith({
    String titulo,
    String telefono,
    String correo,
    String descripcion,
    String codigoPais,
  }){
    return AvisoOportunoReqModel(
      correo: correo ?? this.correo,
      descripcion: descripcion ?? this.descripcion,
      telefono: telefono ?? this.telefono,
      titulo: titulo ?? this.titulo,
      codigoPais:  codigoPais ?? this.codigoPais
    );
  }

  Map<String,String> toMap(){
    return {
      "Titulo": this.titulo,
      "Telefono": this.telefono,
      "Correo": this.correo,
      "Descripcion": this.descripcion,
      "CodigoPais": this.codigoPais
    };
  }
}