class IncidenciaReqModel{
  final List<String> fechas;
  final String horaInicio;
  final String horaFin;
  final String comentarios;
  final String tipo;

  IncidenciaReqModel({this.comentarios, this.fechas, this.horaFin, this.horaInicio, this.tipo});

  dynamic toJson(){
    return {
      "Fechas": this.fechas,
      "HoraFin": this.horaFin,
      "HoraInicio": this.horaInicio,
      "Comentarios": this.comentarios,
      "Tipo": this.tipo
    };
  }
}

class IncidenciaRechazoReqModel{
  final String motivo;
  final int id;
  final String tipo;

  IncidenciaRechazoReqModel({this.id, this.motivo, this.tipo});

  dynamic toJson() {
    return {
      "Motivo": motivo
    };
  }
}