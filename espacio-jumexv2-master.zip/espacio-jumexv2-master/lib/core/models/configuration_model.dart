import 'package:flutter/material.dart';

class Configuracion{

  static String cumpleaniosDesc = "CUMPLEAÑOS";
  static String cumpleaniosColaboradorDesc = "CUMPLEAÑOS_COLABORADOR";

  final Map<String,ConfigurationModel> _configuraciones;

  ConfigurationModel get cumpleanios => _configuraciones[cumpleaniosDesc];
  ConfigurationModel get cumpleaniosColaborador => _configuraciones[cumpleaniosColaboradorDesc];

  Configuracion({
    @required configuraciones
  }):_configuraciones = configuraciones;

  static Configuracion fromJson(dynamic data){
    final Map<String,ConfigurationModel> temp = new Map();
    for (var item in data??[]) {
      final config = ConfigurationModel.fromJson(item);
      temp[config.configuracion] = config;
    }
    return new Configuracion(
      configuraciones: temp
    );
  }

  void add(ConfigurationModel configurationModel){
    _configuraciones[configurationModel.configuracion]=configurationModel;
  }
}

class ConfigurationModel{
  final String configuracion;
  final DateTime lastUpdate;
  final int bitActivo;

  ConfigurationModel({
    this.configuracion,
    this.lastUpdate,
    this.bitActivo
  });

  static ConfigurationModel fromJson(dynamic data){
    return ConfigurationModel(
      configuracion: data["Configuracion"],
      lastUpdate: data["LastUpdate"] != null ? DateTime.parse(data["LastUpdate"]) : DateTime.now(),
      bitActivo: data["BitActivo"]
    );
  }

  ConfigurationModel copyWih({
    String configuracion,
    DateTime lastUpdate,
    int bitActivo
  }){
    return ConfigurationModel(
      configuracion: configuracion ?? this.configuracion,
      lastUpdate: lastUpdate ?? this.lastUpdate,
      bitActivo: bitActivo ?? this.bitActivo
    );
  }

  dynamic toMap(){
    return {
      "Configuracion": configuracion,
      "BitActivo": bitActivo,
      "LastUpdate": lastUpdate.toString()
    };
  }

  @override
  int get hashCode =>
      this.configuracion.hashCode;


  bool operator ==(Object other) =>
      identical(this, other) ||
          other is ConfigurationModel &&
              runtimeType == other.runtimeType &&
              configuracion == other.configuracion;
}