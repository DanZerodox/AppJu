class SolicitudCredencialModel{
  final String fechaSolicitud;
  final String motivo;
  final String estatus;
  final String fechaEntrega;

  SolicitudCredencialModel({
    this.estatus,
    this.fechaEntrega,
    this.fechaSolicitud,
    this.motivo
  });

  factory SolicitudCredencialModel.fromJson(dynamic data){
    return new SolicitudCredencialModel(
      estatus: data["Estatus"],
      fechaEntrega: data["FechaEntrega"],
      fechaSolicitud: data["FechaSolicitud"],
      motivo: data["Motivo"]
    );
  }
}