
import 'dart:io';
import 'package:path/path.dart' as path;
import 'package:espacio_jumex/core/contants/app_constants.dart';
import 'package:espacio_jumex/core/viewmodel/base_model.dart';
import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';

T nvl<T>(T val, T val2){
  return val == null || val.toString().trim().isEmpty ? val2 : val;
}

bool isNullOrEmpty(String value){
  return value == null || value.isEmpty;
}

double toDouble(TimeOfDay myTime) => myTime.hour + myTime.minute/60.0;

void showAlertPopup(BuildContext context,String title, String detail){
  void showDemoDialog<T>({BuildContext context, Widget child}) {
    showDialog<T>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) => child,
    );
  }

  return showDemoDialog<Null>(
    context: context,
    child: AlertDialog(
      title: Text(title),
      content: Text(detail),
      actions: [
        FlatButton(
          child: const Text('Cerrar'),
          onPressed: () {
            Navigator.pop(context);
          }
        ),
      ],
    )
  );
}

ProgressDialog progressDialogBuilder(BuildContext context,String mensaje){
  return ProgressDialog(context,isDismissible: false)
  ..style(
    message: mensaje,
    borderRadius: 10.0,
    backgroundColor: Colors.white,
    progressWidget: CircularProgressIndicator(),
    elevation: 10.0,
    insetAnimCurve: Curves.easeInOut,
    progressTextStyle: TextStyle( color: Colors.black, fontSize: 13.0, fontWeight: FontWeight.w400,fontFamily: "Lucida"),
    messageTextStyle: TextStyle( color: Colors.black, fontSize: 19.0, fontWeight: FontWeight.w600,fontFamily: "Lucida")
  );
}

void unathorized(BuildContext context,Status status, VoidCallback callback) async{
  if(status == Status.unauthorized){
    await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) => AlertDialog(
        title: Text("¡Atención!"),
        content: Text("Su sesión a terminado, favor de ingresar tus credenciales"),
        actions: [
          FlatButton(
            child: const Text('Cerrar'),
            onPressed: () {
              Navigator.pop(context,true);
            }
          ),
        ],
      ),
    );
    Navigator.of(context).pushNamedAndRemoveUntil(RoutePath.Login, (_)=>false);
  }
  else
    callback?.call();
}

Future<String> getFileNameWithExtension(File file)async{

    if(await file.exists()){
      //To get file name without extension
      //path.basenameWithoutExtension(file.path);
      
      //return file with file extension
      return path.basename(file.path);
    }else{
      return null;
    }
  }