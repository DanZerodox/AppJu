abstract class EspacioJumexAppException implements Exception{
  String cause;
  EspacioJumexAppException({String cause}):this.cause = cause;
}

class UnauthorizedException extends EspacioJumexAppException {
  UnauthorizedException(String cause):super(cause: cause);
}

class NotFoundException extends EspacioJumexAppException {
  NotFoundException(String cause):super(cause: cause);
}

class UnexpectedException extends EspacioJumexAppException {
  UnexpectedException(String cause):super(cause: cause);
}

class BadRequestException extends EspacioJumexAppException {
  BadRequestException(String cause):super(cause: cause);
}