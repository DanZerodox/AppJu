import 'package:espacio_jumex/core/infrastructure/customCacheManager.dart';
import 'package:espacio_jumex/core/models/accesos_model.dart';
import 'package:espacio_jumex/core/models/notificacion_model.dart';
import 'package:espacio_jumex/core/models/user_model.dart';
import 'package:espacio_jumex/core/services/espaciojumex_api.dart';
import 'package:espacio_jumex/core/services/firebaseMessaging_service.dart';
import 'package:espacio_jumex/core/services/nomina_service.dart';
import 'package:espacio_jumex/core/services/application_service.dart';
import 'package:espacio_jumex/core/services/resource_service.dart';
import 'package:espacio_jumex/core/services/uploader_service.dart';
import 'package:espacio_jumex/core/services/user_service.dart';
import 'package:espacio_jumex/core/services/localdb_service.dart';
import 'package:espacio_jumex/core/services/yammer_service.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';

class ProvidersSetup{
  final TargetPlatform _targetPlatform;

  const ProvidersSetup({@required TargetPlatform targetPlatform}): _targetPlatform = targetPlatform;

  List<SingleChildCloneableWidget> buildProviders(){
    return _providers();
  }

  List<SingleChildCloneableWidget > _providers() => [
    ..._independentServices(),
    ..._dependentServices(),
    ..._uiConsumableProviders()
  ];
  
  List<SingleChildCloneableWidget > _independentServices() => [
    Provider.value(value: EspacioJumexApi()),
    Provider.value(value: LocaldbService()),
    Provider.value(value: ApplicationService(targetPlatform: _targetPlatform)),
    Provider.value(value: FirebaseMessagingService(),),
  ];

  List<SingleChildCloneableWidget > _dependentServices() => [
    ProxyProvider3<EspacioJumexApi, ApplicationService, LocaldbService, UserService>(
      update: (context, api, appService, localdbService, service) => UserService(api: api, applicationService: appService, localdbService: localdbService), 
    ),
    ProxyProvider<EspacioJumexApi, NominaService>(
      update: (context, api, service) => NominaService(api: api), 
    ),
    ProxyProvider<LocaldbService, UploaderService>(
      update: (context, service, manager) => UploaderService(localdbService: service), 
    ),
    ProxyProvider2<EspacioJumexApi, UploaderService, YammerService>(
      update: (context, api,uploader, service) => YammerService(api: api, uploaderService: uploader), 
    ),
    ProxyProvider<EspacioJumexApi, ResourceService>(
      update: (context, api, service) => ResourceService(api: api),
    ),
    ProxyProvider<ApplicationService, CustomCacheManager>(
      update: (context, service, manager) => CustomCacheManager(applicationService: service), 
    )
  ];

  List<SingleChildCloneableWidget > _uiConsumableProviders() => [
    StreamProvider<UserModel>(create: (context) => Provider.of<UserService>(context, listen: false).user,),
    StreamProvider<AccesosModel>(create: (context) => Provider.of<UserService>(context, listen: false).accesos,),
    StreamProvider<UploadTask>(create: (context) => Provider.of<UploaderService>(context, listen: false).queue,),
    StreamProvider<NotificacionModel>(create: (context) => Provider.of<FirebaseMessagingService>(context, listen: false).messages,),
  ];
}
