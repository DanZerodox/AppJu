import 'dart:async';
import 'package:espacio_jumex/core/services/firebaseMessaging_service.dart';
import 'package:espacio_jumex/ui/shared/theme.dart';
import 'package:espacio_jumex/ui/views/espaciojumex.app.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

// This is our global ServiceLocator
GetIt locator = GetIt.instance;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // FlutterError.onError = (FlutterErrorDetails details) {
  //   if (kDebugMode) {
  //     FlutterError.dumpErrorToConsole(details);
  //   } else {
  //     Zone.current.handleUncaughtError(details.exception, details.stack);
  //   }
  // };

  runZonedGuarded<Future<Null>>(() async {
    locator.registerLazySingleton(() => NavigationService());

    runApp(EspacioJumexApp(
      title: 'Espacio Jumex',
      theme: companyThemeData,
      navigatorKey: locator<NavigationService>().navigatorKey,
    ));
  }, (error, stackTrace) async {
    FirebaseCrashlytics.instance.recordError(error, stackTrace);
  });
}
